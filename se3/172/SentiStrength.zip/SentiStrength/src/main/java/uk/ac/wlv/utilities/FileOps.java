package uk.ac.wlv.utilities;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * 提供一些对文件的操作
 * @author Mike Thelwall
 * @version 1.0.0
 */
public class FileOps {

   /**
    * 用于备份文件并删除原本文件
    * <p>将该文件所有的备份文件编号加1，再产生编号为1的新备份文件，去除原本文件
    * @param sFileName 文件名字符串
    * @param iMaxBackups 最大备份数
    * @return 操作成功则返回 true，原本文件不存在则失败返回 false
    */
   public static boolean backupFileAndDeleteOriginal(String sFileName, int iMaxBackups) {
      int iLastBackup;
      File f;
      /* 从max向下，找到存在的编号最大的bak文件，iLastBackup为该编号 */
      for(iLastBackup = iMaxBackups; iLastBackup >= 0; --iLastBackup) {
         f = new File(sFileName + iLastBackup + ".bak");
         if (f.exists()) {
            break;
         }
      }

      if (iLastBackup < 1) {
         /*
         * 不存在备份文件
         * 原文件不存在，返回false
         * 原文件存在，原文件重命名为 name + "1.bak"，返回true
         * */
         f = new File(sFileName);
         if (f.exists()) {
            f.renameTo(new File(sFileName + "1.bak"));
            return true;
         } else {
            return false;
         }
      } else {
         /* 存在备份文件 */
         /* 若编号最大的备份文件编号达到上限，删除该备份文件 */
         if (iLastBackup == iMaxBackups) {
            f = new File(sFileName + iLastBackup + ".bak");
            f.delete();
            --iLastBackup;
         }
         /* 每个备份文件编号加1 */
         for(int i = iLastBackup; i > 0; --i) {
            f = new File(sFileName + i + ".bak");
            f.renameTo(new File(sFileName + (i + 1) + ".bak"));
         }
         /* 原文件重命名为 name + "1.bak" */
         f = new File(sFileName);
         f.renameTo(new File(sFileName + "1.bak"));
         return true;
      }
   }

   /**
    * 获得一个文本文件的文本行数
    * @param sFileLocation 需计数的文件名（文件路径）
    * @return 文本文件的文本行数，如果出现文件不存在或IO异常等错误则返回-1
    */
   public static int i_CountLinesInTextFile(String sFileLocation) {
      int iLines = 0;

      try {
         BufferedReader rReader;
         for(rReader = new BufferedReader(new FileReader(sFileLocation)); rReader.ready(); ++iLines) {
            String sLine = rReader.readLine();
         }

         rReader.close();
         return iLines;
      } catch (FileNotFoundException var5) {
         var5.printStackTrace();
         return -1;
      } catch (IOException var6) {
         var6.printStackTrace();
         return -1;
      }
   }

   /**
    * 查找下一个可用的文件名，下一个可用文件名的格式是参数中的文件名添加编号0~1000
    * @param sFileNameStart 文件名前半部分字符串（文件主名或文件主名的主要部分）
    * @param sFileNameEnd 文件名后半部分字符串（包含拓展名）
    * @return 下一个可用的文件名，如果不存在则返回空字符串
    */
   public static String getNextAvailableFilename(String sFileNameStart, String sFileNameEnd) {
      for(int i = 0; i <= 1000; ++i) {
         String sFileName = sFileNameStart + i + sFileNameEnd;
         File f = new File(sFileName);
         if (!f.isFile()) {
            return sFileName;
         }
      }

      return "";
   }

   /**
    * 去除文件名中的拓展名部分
    * @param sFilename 完整文件名字符串
    * @return 不含拓展名的文件名字符串
    */
   public static String s_ChopFileNameExtension(String sFilename) {
      if (sFilename != null && sFilename != "") {
         int iLastDotPos = sFilename.lastIndexOf(".");
         if (iLastDotPos > 0) {
            sFilename = sFilename.substring(0, iLastDotPos);
         }
      }

      return sFilename;
   }
}
