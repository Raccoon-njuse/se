package uk.ac.wlv.utilities;

/**
 * 使用快排算法的排序工具，提供多个排序方法
 * @author Mike Thelwall
 * @version 1.0.0
 */
public class Sort {
   /**
    * 使用快排算法，将字符串数组sArray的[l, r]区间内字符串字典序排序
    * @param sArray 需排序的字符串数组
    * @param l 需排序闭区间的最左端位置
    * @param r 需排序闭区间的最右端位置
    */
   public static void quickSortStrings(String[] sArray, int l, int r) {
      String sMiddle = sArray[(l + r) / 2];
      int i = l;
      int j = r;

      while(i <= j) {
         while(sMiddle.compareTo(sArray[i]) > 0 && i < r) {
            ++i;
         }

         while(sMiddle.compareTo(sArray[j]) < 0 && j > l) {
            --j;
         }

         if (i < j) {
            String Y = sArray[i];
            sArray[i] = sArray[j];
            sArray[j] = Y;
         }

         if (i <= j) {
            ++i;
            --j;
         }
      }

      if (l < j) {
         quickSortStrings(sArray, l, j);
      }

      if (i < r) {
         quickSortStrings(sArray, i, r);
      }

   }

   /**
    * 使用快排算法，将整数数组iArray的[l, r]区间内整数升序排序
    * @param iArray 需排序的整数数组
    * @param l 需排序闭区间的最左端位置
    * @param r 需排序闭区间的最右端位置
    */
   public static void quickSortInt(int[] iArray, int l, int r) {
      int X = iArray[(l + r) / 2];
      int i = l;
      int j = r;

      while(i <= j) {
         while(iArray[i] < X && i < r) {
            ++i;
         }

         while(X < iArray[j] && j > l) {
            --j;
         }

         if (i <= j) {
            int Y = iArray[i];
            iArray[i] = iArray[j];
            iArray[j] = Y;
            ++i;
            --j;
         }
      }

      if (l < j) {
         quickSortInt(iArray, l, j);
      }

      if (i < r) {
         quickSortInt(iArray, i, r);
      }

   }

   /**
    * 使用快排算法，将浮点数数组fArray的[l, r]内浮点数升序排序，iArray2跟随它进行相同位置的元素移动操作
    * @param fArray 需排序的数组
    * @param iArray2 跟随fArray进行相同位置的元素移动操作的整数数组
    * @param l 需排序闭区间的最左端位置
    * @param r 需排序闭区间的最右端位置
    */
   public static void quickSortDoubleWithInt(double[] fArray, int[] iArray2, int l, int r) {
      double X = fArray[(l + r) / 2];
      int i = l;
      int j = r;

      while(i <= j) {
         while(fArray[i] < X && i < r) {
            ++i;
         }

         while(X < fArray[j] && j > l) {
            --j;
         }

         if (i <= j) {
            double fTemp = fArray[i];
            int iTemp = iArray2[i];
            fArray[i] = fArray[j];
            iArray2[i] = iArray2[j];
            fArray[j] = fTemp;
            iArray2[j] = iTemp;
            ++i;
            --j;
         }
      }

      if (l < j) {
         quickSortDoubleWithInt(fArray, iArray2, l, j);
      }

      if (i < r) {
         quickSortDoubleWithInt(fArray, iArray2, i, r);
      }

   }

   /**
    * 使用快排算法，将整数数组iArray的[l, r]内整数升序排序，iArray2跟随它进行相同位置的元素移动操作
    * @param iArray 需排序的数组
    * @param iArray2 跟随iArray进行相同位置的元素移动操作的整数数组
    * @param l 需排序闭区间的最左端位置
    * @param r 需排序闭区间的最右端位置
    */
   public static void quickSortIntWithInt(int[] iArray, int[] iArray2, int l, int r) {
      int X = iArray[(l + r) / 2];
      int i = l;
      int j = r;

      while(i <= j) {
         while(iArray[i] < X && i < r) {
            ++i;
         }

         while(X < iArray[j] && j > l) {
            --j;
         }

         if (i <= j) {
            int iTemp = iArray[i];
            int iTemp2 = iArray2[i];
            iArray[i] = iArray[j];
            iArray2[i] = iArray2[j];
            iArray[j] = iTemp;
            iArray2[j] = iTemp2;
            ++i;
            --j;
         }
      }

      if (l < j) {
         quickSortIntWithInt(iArray, iArray2, l, j);
      }

      if (i < r) {
         quickSortIntWithInt(iArray, iArray2, i, r);
      }

   }

   /**
    * 查找字符串在已排序字符串数组中的位置
    * <p>数组sArray已按字典序排序，在数组的[iLower, iUpper]区间查找字符串sText的位置，如果找不到则返回-1
    * @param sText 目标字符串
    * @param sArray 字符串数组
    * @param iLower 查找的闭区间的左端点
    * @param iUpper 查找的闭区间的右端点
    * @return 目标字符串sText在字符串数组sArray指定区间中的位置，如果数组中不存在sText则返回-1
    */
   public static int i_FindStringPositionInSortedArray(String sText, String[] sArray, int iLower, int iUpper) {
      boolean var4 = false;

      int iMiddle;
      while(iUpper - iLower > 2) {
         iMiddle = (iLower + iUpper) / 2;
         if (sText.compareTo(sArray[iMiddle]) < 0) {
            iUpper = iMiddle;
         } else {
            iLower = iMiddle;
         }
      }

      for(iMiddle = iLower; iMiddle <= iUpper; ++iMiddle) {
         if (sArray[iMiddle].compareTo(sText) == 0) {
            return iMiddle;
         }
      }

      return -1;
   }

   /**
    * 查找整数在已排序整数数组中的位置
    * <p>数组iArray已排序，在数组的[iLower, iUpper]区间查找整数iFind的位置，如果找不到则返回-1
    * @param iFind 目标整数
    * @param iArray 整数数组
    * @param iLower 查找的闭区间的左端点
    * @param iUpper 查找的闭区间的右端点
    * @return 目标整数在整数数组指定区间中的位置，如果数组中不存在iFind则返回-1
    */
   public static int i_FindIntPositionInSortedArray(int iFind, int[] iArray, int iLower, int iUpper) {
      boolean var4 = false;

      int iMiddle;
      while(iUpper - iLower > 2) {
         iMiddle = (iLower + iUpper) / 2;
         if (iFind < iArray[iMiddle]) {
            iUpper = iMiddle;
         } else {
            iLower = iMiddle;
         }
      }

      for(iMiddle = iLower; iMiddle <= iUpper; ++iMiddle) {
         if (iArray[iMiddle] == iFind) {
            return iMiddle;
         }
      }

      return -1;
   }

   /**
    * 查找字符串在已排序的字符串数组中的位置，字符串支持通配符的使用
    * <p>数组sArray已排序，在数组的[iLower, iUpper]区间查找字符串sText的位置，如果数组中没有元素能匹配sText则返回-1
    * @param sText 目标字符串
    * @param sArray 字符串数组
    * @param iLower 查找的闭区间的左端点
    * @param iUpper 查找的闭区间的右端点
    * @return 目标字符串在数组指定区间中的位置，如果数组中没有元素能匹配sText则返回-1
    */
   public static int i_FindStringPositionInSortedArrayWithWildcardsInArray(String sText, String[] sArray, int iLower, int iUpper) {
      int iOriginalLower = iLower;
      int iOriginalUpper = iUpper;

      int iMiddle;
      while(iUpper - iLower > 2) {
         iMiddle = (iLower + iUpper) / 2;
         if (sText.compareTo(sArray[iMiddle]) < 0) {
            iUpper = iMiddle;
         } else {
            iLower = iMiddle;
         }
      }

      for(iMiddle = iUpper; iMiddle >= iLower; --iMiddle) {
         if (sArray[iMiddle].compareTo(sText) == 0) {
            return iMiddle;
         }
      }

      // 这是干嘛呢哎呀
      if (iLower > iOriginalLower) {
         --iLower;
      }

      if (iLower > iOriginalLower) {
         --iLower;
      }

      if (iLower > iOriginalLower) {
         --iLower;
      }

      if (iUpper < iOriginalUpper) {
         ++iUpper;
      }

      int iTextLength = sText.length();

      for(iMiddle = iUpper; iMiddle >= iLower; --iMiddle) {
         int iLength = sArray[iMiddle].length();
         if (iLength > 1 &&
                 sArray[iMiddle].substring(iLength - 1, iLength).compareTo("*") == 0 &&
                 iTextLength >= iLength - 1 &&
                 sText.substring(0, iLength - 1).compareTo(sArray[iMiddle].substring(0, iLength - 1)) == 0) {
            return iMiddle;
         }
      }

      return -1;
   }

   /**
    * 使用快排算法，将字符串数组sArray的[l, r]内的字符串排序，iArray2跟随它进行相同位置的元素移动操作
    * @param sArray 需排序的数组
    * @param iArray 跟随sArray进行相同位置的元素移动操作的整数数组
    * @param l 需排序闭区间的最左端位置
    * @param r 需排序闭区间的最右端位置
    */
   public static void quickSortStringsWithInt(String[] sArray, int[] iArray, int l, int r) {
      String sMiddle = sArray[(l + r) / 2];
      int i = l;
      int j = r;

      while(i <= j) {
         while(sMiddle.compareTo(sArray[i]) > 0 && i < r) {
            ++i;
         }

         while(sMiddle.compareTo(sArray[j]) < 0 && j > l) {
            --j;
         }

         if (i < j) {
            String sTemp = sArray[i];
            int iTemp = iArray[i];
            sArray[i] = sArray[j];
            iArray[i] = iArray[j];
            sArray[j] = sTemp;
            iArray[j] = iTemp;
         }

         if (i <= j) {
            ++i;
            --j;
         }
      }

      if (l < j) {
         quickSortStringsWithInt(sArray, iArray, l, j);
      }

      if (i < r) {
         quickSortStringsWithInt(sArray, iArray, i, r);
      }

   }

   /**
    * 使用快排算法，将字符串数组sArray的[l, r]区间进行排序，sArray2跟随它进行相同位置的元素移动操作
    * @param sArray 需排序的数组
    * @param sArray2 跟随sArray进行相同位置的元素移动操作的字符串数组
    * @param l 需排序闭区间的最左端位置
    * @param r 需排序闭区间的最右端位置
    */
   public static void quickSortStringsWithStrings(String[] sArray, String[] sArray2, int l, int r) {
      String sMiddle = sArray[(l + r) / 2];
      int i = l;
      int j = r;

      while(i <= j) {
         while(sMiddle.compareTo(sArray[i]) > 0 && i < r) {
            ++i;
         }

         while(sMiddle.compareTo(sArray[j]) < 0 && j > l) {
            --j;
         }

         if (i < j) {
            String sTemp = sArray[i];
            String sTemp2 = sArray2[i];
            sArray[i] = sArray[j];
            sArray2[i] = sArray2[j];
            sArray[j] = sTemp;
            sArray2[j] = sTemp2;
         }

         if (i <= j) {
            ++i;
            --j;
         }
      }

      if (l < j) {
         quickSortStringsWithStrings(sArray, sArray2, l, j);
      }

      if (i < r) {
         quickSortStringsWithStrings(sArray, sArray2, i, r);
      }

   }

   /**
    * 生成随机顺序的数列，设iArray的长度为n，将整数1至n-1以随机顺序填入iArray的[1, n-1]位置
    * @param iArray 存放随机顺序数列的整数数组
    */
   public static void makeRandomOrderList(int[] iArray) {
      if (iArray != null) {
         int iArraySize = iArray.length;
         if (iArraySize >= 1) {
            double[] fRandArray = new double[iArraySize--];

            for(int i = 1; i <= iArraySize; ++i) {
               iArray[i] = i;
               fRandArray[i] = Math.random();
            }

            quickSortDoubleWithInt(fRandArray, iArray, 1, iArraySize);
         }
      }
   }

   /**
    * 使用快排算法对浮点数元素进行降序排序，用数组iIndexArray的[l, r]区间表示fArray中各元素排序后的位置<br>
    * fArray数组不变，iIndexArray[i]表示降序排列下fArray[i]应处于的位置索引
    * @param fArray 存放需排序的数据
    * @param iIndexArray 表示如果进行降序排序fArray各元素应处于的位置索引
    * @param l iIndexArray闭区间的最左端位置
    * @param r iIndexArray闭区间的最右端位置
    */
   public static void quickSortNumbersDescendingViaIndex(double[] fArray, int[] iIndexArray, int l, int r) {
      int i = l;
      int j = r;
      double fX = fArray[iIndexArray[(l + r) / 2]];

      while(i <= j) {
         while(fArray[iIndexArray[i]] > fX && i < r) {
            ++i;
         }

         while(fX > fArray[iIndexArray[j]] && j > l) {
            --j;
         }

         if (i <= j) {
            int iTemp = iIndexArray[i];
            iIndexArray[i] = iIndexArray[j];
            iIndexArray[j] = iTemp;
            ++i;
            --j;
         }
      }

      if (l < j) {
         quickSortNumbersDescendingViaIndex(fArray, iIndexArray, l, j);
      }

      if (i < r) {
         quickSortNumbersDescendingViaIndex(fArray, iIndexArray, i, r);
      }

   }
}
