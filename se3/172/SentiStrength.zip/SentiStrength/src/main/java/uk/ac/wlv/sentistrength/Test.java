// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 
// Source File Name:   Test.java

package uk.ac.wlv.sentistrength;

import java.io.PrintStream;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
/**

 * 这是一个用于测试ASCII编码的类。
 * @author Mike Thelwall
 * @version 1.0.0
 */
public class Test
{

    public Test()
    {
    }
    /**

     主函数，用于测试ASCII编码。

     @param args 传入的命令行参数
     */
    public static void main(String args[])
    {
        CharsetEncoder asciiEncoder = Charset.forName("US-ASCII").newEncoder();
        String test = "R\351al";
        System.out.println((new StringBuilder(String.valueOf(test))).append(" isPureAscii() : ").append(asciiEncoder.canEncode(test)).toString());
        // 遍历字符串中的每个字符，判断其是否为ASCII编码
        for(int i = 0; i < test.length(); i++)
            if(!asciiEncoder.canEncode(test.charAt(i)))
                System.out.println((new StringBuilder(String.valueOf(test.charAt(i)))).append(" isn't Ascii() : ").toString());

        test = "Real";
        System.out.println((new StringBuilder(String.valueOf(test))).append(" isPureAscii() : ").append(asciiEncoder.canEncode(test)).toString());
        test = "a\u2665c";
        System.out.println((new StringBuilder(String.valueOf(test))).append(" isPureAscii() : ").append(asciiEncoder.canEncode(test)).toString());
        for(int i = 0; i < test.length(); i++)
            if(!asciiEncoder.canEncode(test.charAt(i)))
                System.out.println((new StringBuilder(String.valueOf(test.charAt(i)))).append(" isn't Ascii() : ").toString());

        System.out.println((new StringBuilder("Encoded Word = ")).append(URLEncoder.encode(test)).toString());
    }
}
