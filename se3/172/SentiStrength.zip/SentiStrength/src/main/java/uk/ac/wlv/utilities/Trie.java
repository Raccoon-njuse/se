package uk.ac.wlv.utilities;

/**
 * 提供字典树相关功能和操作
 * @author Mike Thelwall
 * @version 1.0.0
 */
public class Trie {

   /**
    * 获取字符串在数组中的位置
    * <p>使用字典树，查找字符串sText在数组sArray中的位置（索引值）<br>
    *     如果该字符串不存在，根据参数bDontAddNewString决定是否在数组中加入该字符串
    * @param sText 目标字符串
    * @param sArray 字符串数组
    * @param iLessPointer 整数数组，存放每个字符串字典序的前一项字符串的索引值
    * @param iMorePointer 整数数组，存放每个字符串字典序的后一项字符串的索引值
    * @param iFirstElement 数组中第一个字符串的位置
    * @param iLastElement 数组中最后一个字符串的位置
    * @param bDontAddNewString true则不能向sArray添加新字符串，false则可以添加
    * @return 字符串在字典树中的位置，若最终字符串不存在则返回-1
    */
   public static int i_GetTriePositionForString(String sText, String[] sArray, int[] iLessPointer, int[] iMorePointer, int iFirstElement, int iLastElement, boolean bDontAddNewString) {
      int iTriePosition = 0;
      int iLastTriePosition = 0;
      if (iLastElement < iFirstElement) {
         sArray[iFirstElement] = sText;
         iLessPointer[iFirstElement] = -1;
         iMorePointer[iFirstElement] = -1;
         return iFirstElement;
      } else {
         iTriePosition = iFirstElement;
         // int iLastTriePosition;
         // 破防了 这都什么东西
         label33:
         do {
            do {
               iLastTriePosition = iTriePosition;
               // 字符串在更前面，则iTriePosition往前
               if (sText.compareTo(sArray[iTriePosition]) < 0) {
                  iTriePosition = iLessPointer[iTriePosition];
                  continue label33;
               }

               // 相当于==，找到位置，返回
               if (sText.compareTo(sArray[iTriePosition]) <= 0) {
                  return iTriePosition;
               }

               iTriePosition = iMorePointer[iTriePosition];
               // 往后找，直到末尾
            } while(iTriePosition != -1);

            // 不能加新字符串，直接结束
            if (bDontAddNewString) {
               return -1;
            }

            // 能加新字符串，加在数组末尾
            ++iLastElement;
            sArray[iLastElement] = sText;
            iLessPointer[iLastElement] = -1;
            iMorePointer[iLastElement] = -1;
            iMorePointer[iLastTriePosition] = iLastElement;
            return iLastElement;
         } while(iTriePosition != -1);

         if (bDontAddNewString) {
            return -1;
         } else {
            ++iLastElement;
            sArray[iLastElement] = sText;
            iLessPointer[iLastElement] = -1;
            iMorePointer[iLastElement] = -1;
            iLessPointer[iLastTriePosition] = iLastElement;
            return iLastElement;
         }
      }
   }

   /**
    * 旧版i_GetTriePositionForString方法
    * @deprecated
    * @param sText 目标字符串
    * @param sArray 字符串数组
    * @param iLessPointer 整数数组，存放每个字符串字典序的前一项字符串的索引值
    * @param iMorePointer 整数数组，存放每个字符串字典序的后一项字符串的索引值
    * @param iLastElement 数组中最后一个字符串的位置
    * @param bDontAddNewString true则不能向sArray添加新字符串，false则可以添加
    * @return 字符串在字典树中的位置，若最终字符串不存在则返回-1
    */
   public static int i_GetTriePositionForString_old(String sText, String[] sArray, int[] iLessPointer, int[] iMorePointer, int iLastElement, boolean bDontAddNewString) {
      int iTriePosition = 0;
      int iLastTriePosition = 0;
      if (iLastElement == 0) {
         iLastElement = 1;
         sArray[iLastElement] = sText;
         iLessPointer[iLastElement] = 0;
         iMorePointer[iLastElement] = 0;
         return 1;
      } else {
         iTriePosition = 1;

//         int iLastTriePosition;
         label33:
         do {
            do {
               iLastTriePosition = iTriePosition;
               if (sText.compareTo(sArray[iTriePosition]) < 0) {
                  iTriePosition = iLessPointer[iTriePosition];
                  continue label33;
               }

               if (sText.compareTo(sArray[iTriePosition]) <= 0) {
                  return iTriePosition;
               }

               iTriePosition = iMorePointer[iTriePosition];
            } while(iTriePosition != 0);

            if (bDontAddNewString) {
               return 0;
            }

            ++iLastElement;
            sArray[iLastElement] = sText;
            iLessPointer[iLastElement] = 0;
            iMorePointer[iLastElement] = 0;
            iMorePointer[iLastTriePosition] = iLastElement;
            return iLastElement;
         } while(iTriePosition != 0);

         if (bDontAddNewString) {
            return 0;
         } else {
            ++iLastElement;
            sArray[iLastElement] = sText;
            iLessPointer[iLastElement] = 0;
            iMorePointer[iLastElement] = 0;
            iLessPointer[iLastTriePosition] = iLastElement;
            return iLastElement;
         }
      }
   }

   /**
    * 找到字符串sText在数组sArray中的位置，如果不存在则根据bDontAddNewString决定是否向数组sArray中添加sText<br>
    * 如果最终字符串存在，则数组iCount中为该字符串的计数加1
    * @param sText 目标字符串
    * @param sArray 字符串数组
    * @param iCountArray 字符串计数数组
    * @param iLessPointer 整数数组，存放每个字符串字典序的前一项字符串的索引值
    * @param iMorePointer 整数数组，存放每个字符串字典序的后一项字符串的索引值
    * @param iFirstElement 数组中第一个字符串的位置
    * @param iLastElement 数组中最后一个字符串的位置
    * @param bDontAddNewString true则不能向sArray添加新字符串，false则可以添加
    * @param iCount 计数的增量，未使用
    * @return 字符串在字典树中的位置，若字符串不存在不添加该字符串则返回-1
    */
   public static int i_GetTriePositionForStringAndAddCount(String sText, String[] sArray, int[] iCountArray, int[] iLessPointer, int[] iMorePointer, int iFirstElement, int iLastElement, boolean bDontAddNewString, int iCount) {
      int iPos = i_GetTriePositionForString(sText, sArray, iLessPointer, iMorePointer, iFirstElement, iLastElement, bDontAddNewString);
      if (iPos >= 0) {
         iCountArray[iPos]++;
      }
      return iPos;
   }
}
