//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package uk.ac.wlv.sentistrength;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 *  ClassificationOptions类用于设置SentiStrength算法的参数
 *  @author Mike Thelwall
 *  @version 1.0.0
 */
public class ClassificationOptions {

    /**
     * 是否采用TensiStrength模式
     */
    public boolean bgTensiStrength = false;
    /**
     * 项目名称
     */
    public String sgProgramName = "SentiStrength";
    /**
     *   SentiStrength程序要测量的对象
     */
    public String sgProgramMeasuring = "sentiment";
    /**
     * 程序中代表正向、积极的是什么
     */
    public String sgProgramPos = "positive sentiment";
    /**
     * 程序中代表反向、消极的是什么
     */
    public String sgProgramNeg = "negative sentiment";
    /**
    是否采用scale模式
     */
    public boolean bgScaleMode = false;
    /**
    是否采用trinary模式
     */
    public boolean bgTrinaryMode = false;
    /**
    是否采用trinary模式的binary版本即是否采用binary模式
     */
    public boolean bgBinaryVersionOfTrinaryMode = false;
    public int igDefaultBinaryClassification = 1;
    /**
    情绪段落结合方法，即Max，Av,Tot三种
     */
    public int igEmotionParagraphCombineMethod = 0;
    final int igCombineMax = 0;
    final int igCombineAverage = 1;
    final int igCombineTotal = 2;
    /**
    情绪句子结合方法，即Max，Av,Tot三种
     */
    public int igEmotionSentenceCombineMethod = 0;
    /**
     * 消极情绪乘以的倍数
     */
    public float fgNegativeSentimentMultiplier = 1.5F;
    /**
    是否减少疑问句中的消极情绪
     */
    public boolean bgReduceNegativeEmotionInQuestionSentences = false;
    /**
    单词“miss”是否在计算时增加2点积极情绪
     */
    public boolean bgMissCountsAsPlus2 = true;
    /**
    是否采取除了句子情绪为消极情况下you和your为情绪得分加2的规则
     */
    public boolean bgYouOrYourIsPlus2UnlessSentenceNegative = false;
    /**
    是否采取在中立句子中感叹号在计算时情绪得分加2的规则
     */
    public boolean bgExclamationInNeutralSentenceCountsAsPlus2 = false;
    /**
    能改变句子情绪的最小标点符号以及感叹号的数量
     */
    public int igMinPunctuationWithExclamationToChangeSentenceSentiment = 0;
    /**
    是否使用习语查看表
     */
    public boolean bgUseIdiomLookupTable = true;
    /**
    是否使用对象评估表
     */
    public boolean bgUseObjectEvaluationTable = false;
    /**
    是否采取将中立态度算作积极情绪表示强调的规则
     */
    public boolean bgCountNeutralEmotionsAsPositiveForEmphasis1 = true;
    /**
    用来解释中立强调的情绪，大于0时解释为积极情绪，小于0解释为消极情绪
     */
    public int igMoodToInterpretNeutralEmphasis = 1;
    /**
    是否允许多个积极性的词语增加积极情绪
     */
    public boolean bgAllowMultiplePositiveWordsToIncreasePositiveEmotion = true;
    /**
    是否允许多个消极性的词语增加消极情绪
     */
    public boolean bgAllowMultipleNegativeWordsToIncreaseNegativeEmotion = true;
    /**
    是否忽略消极成分后的增强词语
     */
    public boolean bgIgnoreBoosterWordsAfterNegatives = true;
    /**
    是否使用字典纠正拼写
     */
    public boolean bgCorrectSpellingsUsingDictionary = true;
    /**
    是否纠正有额外重复的字母这样的拼写错误
     */
    public boolean bgCorrectExtraLetterSpellingErrors = true;
    /**
    非法的出现在单词中间两次的字母集合
     */
    public String sgIllegalDoubleLettersInWordMiddle = "ahijkquvxyz";
    /**
    非法的出现在单词结尾两次的字母集合
     */
    public String sgIllegalDoubleLettersAtWordEnd = "achijkmnpqruvwxyz";
    /**
    多个重复字母是否能增强情绪
     */
    public boolean bgMultipleLettersBoostSentiment = true;
    /**
    增强词语能否改变情绪
     */
    public boolean bgBoosterWordsChangeEmotion = true;
    /**
    是否总是在省略符"'"处分割单词
     */
    public boolean bgAlwaysSplitWordsAtApostrophes = false;
    /**
    是否允许情绪词前出现表示否定意义的词语比如not
     */
    public boolean bgNegatingWordsOccurBeforeSentiment = true;
    /**
    情绪词前用于否定的单词的最大数量
     */
    public int igMaxWordsBeforeSentimentToNegate = 0;
    /**
    是否允许情绪词后出现表示否定意义的词语
     */
    public boolean bgNegatingWordsOccurAfterSentiment = false;
    /**
    情绪词后用于否定的单词的最大数量
     */
    public int igMaxWordsAfterSentimentToNegate = 0;
    /**
    是否允许否定积极文本从而改变情绪
     */
    public boolean bgNegatingPositiveFlipsEmotion = true;
    /**
    是否允许否定消极文本从而使情绪变为中立
     */
    public boolean bgNegatingNegativeNeutralisesEmotion = true;
    /**
    是否允许否定词语来改变情绪
     */
    public boolean bgNegatingWordsFlipEmotion = false;
    /**
    否定词语改变情绪时要乘以的强度
     */
    public float fgStrengthMultiplierForNegatedWords = 0.5F;
    /**
    是否纠正有重复字母的拼写
     */
    public boolean bgCorrectSpellingsWithRepeatedLetter = true;
    /**
    是否使用表情符号
     */
    public boolean bgUseEmoticons = true;
    /**
    有增强情绪作用的term是否要大写
     */
    public boolean bgCapitalsBoostTermSentiment = false;
    /**
    要增强情绪重复字母的最小重复次数
     */
    public int igMinRepeatedLettersForBoost = 2;
    /**
    存放情绪关键词的数组
     */
    public String[] sgSentimentKeyWords = null;
    /**
    是否忽略没有关键词的句子
     */
    public boolean bgIgnoreSentencesWithoutKeywords = false;
    /**
    关键词前要包括的单词数量
     */
    public int igWordsToIncludeBeforeKeyword = 4;
    /**
    关键词后要包括的单词数量
     */
    public int igWordsToIncludeAfterKeyword = 4;
    /**
    是否解释分类即增加解释信息
     */
    public boolean bgExplainClassification = false;
    /**
    是否重复文本即是否输出待解析的文本
     */
    public boolean bgEchoText = false;
    /**
    是否强制使用UTF8编码
     */
    public boolean bgForceUTF8 = false;
    /**
    是否使用词形还原即是否使用lemamatiser
     */
    public boolean bgUseLemmatisation = false;
    /**
    引用讽刺所需的句子最小积极情绪得分
     */
    public int igMinSentencePosForQuotesIrony = 10;
    /**
    标点符号表示讽刺所需的句子最小积极情绪得分
     */
    public int igMinSentencePosForPunctuationIrony = 10;
    /**
    term表示讽刺所需的句子最小积极情绪得分
     */
    public int igMinSentencePosForTermsIrony = 10;
    /**
    构造函数
     */
    public ClassificationOptions() {
    }

    /**

     解析情感关键词列表
     @param sKeywordList 包含多个关键词的字符串，以逗号分隔
     */
    public void parseKeywordList(String sKeywordList) {
        // 将关键词列表字符串按逗号拆分为字符串数组并存储在 sgSentimentKeyWords 变量中
        this.sgSentimentKeyWords = sKeywordList.split(",");
        // 将忽略不含情感关键词的句子标志设置为 true
        this.bgIgnoreSentencesWithoutKeywords = true;
    }
    /**

     输出情感分类选项到BufferedWriter中。

     @param wWriter BufferedWriter对象，用于写入选项。

     @param iMinImprovement 最小改进量。

     @param bUseTotalDifference 是否使用总差异。

     @param iMultiOptimisations 优化次数。

     @return boolean值，表示写入是否成功。
     */
    public boolean printClassificationOptions(BufferedWriter wWriter, int iMinImprovement, boolean bUseTotalDifference, int iMultiOptimisations) {
        try {
            if (this.igEmotionParagraphCombineMethod == 0) {
                wWriter.write("Max");
            } else if (this.igEmotionParagraphCombineMethod == 1) {
                wWriter.write("Av");
            } else {
                wWriter.write("Tot");
            }

            if (this.igEmotionSentenceCombineMethod == 0) {
                wWriter.write("\tMax");
            } else if (this.igEmotionSentenceCombineMethod == 1) {
                wWriter.write("\tAv");
            } else {
                wWriter.write("\tTot");
            }

            if (bUseTotalDifference) {
                wWriter.write("\tTotDiff");
            } else {
                wWriter.write("\tExactCount");
            }

            wWriter.write("\t" + iMultiOptimisations + "\t" + this.bgReduceNegativeEmotionInQuestionSentences + "\t" + this.bgMissCountsAsPlus2 + "\t" + this.bgYouOrYourIsPlus2UnlessSentenceNegative + "\t" + this.bgExclamationInNeutralSentenceCountsAsPlus2 + "\t" + this.bgUseIdiomLookupTable + "\t" + this.igMoodToInterpretNeutralEmphasis + "\t" + this.bgAllowMultiplePositiveWordsToIncreasePositiveEmotion + "\t" + this.bgAllowMultipleNegativeWordsToIncreaseNegativeEmotion + "\t" + this.bgIgnoreBoosterWordsAfterNegatives + "\t" + this.bgMultipleLettersBoostSentiment + "\t" + this.bgBoosterWordsChangeEmotion + "\t" + this.bgNegatingWordsFlipEmotion + "\t" + this.bgNegatingPositiveFlipsEmotion + "\t" + this.bgNegatingNegativeNeutralisesEmotion + "\t" + this.bgCorrectSpellingsWithRepeatedLetter + "\t" + this.bgUseEmoticons + "\t" + this.bgCapitalsBoostTermSentiment + "\t" + this.igMinRepeatedLettersForBoost + "\t" + this.igMaxWordsBeforeSentimentToNegate + "\t" + iMinImprovement);
            return true;
        } catch (IOException var6) {
            var6.printStackTrace();
            return false;
        }
    }
    /**

     将空白的分类选项打印到给定的缓冲区写入器中。
     @param wWriter 缓冲区写入器
     @return 如果成功将空白分类选项打印到缓冲区写入器中，则返回 true，否则返回 false。
     */
    public boolean printBlankClassificationOptions(BufferedWriter wWriter) {
        try {
            wWriter.write("~");
            wWriter.write("\t~");
            wWriter.write("\tBaselineMajorityClass");
            wWriter.write("\t~\t~\t~\t~\t~\t~\t~\t~\t~\t~\t~\t~\t~\t~\t~\t~\t~\t~\t~\t~\t~");
            return true;
        } catch (IOException var3) {
            var3.printStackTrace();
            return false;
        }
    }

    /**
     * 打印分类参数的头部
     * @param wWriter 输出对应的writer
     * @return 是否成功
     */
    public boolean printClassificationOptionsHeadings(BufferedWriter wWriter) {
        try {
            wWriter.write("EmotionParagraphCombineMethod\tEmotionSentenceCombineMethod\tDifferenceCalculationMethodForTermWeightAdjustments\tMultiOptimisations\tReduceNegativeEmotionInQuestionSentences\tMissCountsAsPlus2\tYouOrYourIsPlus2UnlessSentenceNegative\tExclamationCountsAsPlus2\tUseIdiomLookupTable\tMoodToInterpretNeutralEmphasis\tAllowMultiplePositiveWordsToIncreasePositiveEmotion\tAllowMultipleNegativeWordsToIncreaseNegativeEmotion\tIgnoreBoosterWordsAfterNegatives\tMultipleLettersBoostSentiment\tBoosterWordsChangeEmotion\tNegatingWordsFlipEmotion\tNegatingPositiveFlipsEmotion\tNegatingNegativeNeutralisesEmotion\tCorrectSpellingsWithRepeatedLetter\tUseEmoticons\tCapitalsBoostTermSentiment\tMinRepeatedLettersForBoost\tWordsBeforeSentimentToNegate\tMinImprovement");
            return true;
        } catch (IOException var3) {
            var3.printStackTrace();
            return false;
        }
    }
    /**

     从指定文件读取分类选项并设置对应的值。

     @param sFilename 用于读取分类选项的文件名。

     @return 如果成功读取并设置分类选项，则返回 true，否则返回 false。
     */
    public boolean setClassificationOptions(String sFilename) {
        try {
            BufferedReader rReader = new BufferedReader(new FileReader(sFilename));

            while(rReader.ready()) {
                String sLine = rReader.readLine();
                int iTabPos = sLine.indexOf("\t");
                if (iTabPos > 0) {
                    String[] sData = sLine.split("\t");
                    if (sData[0] == "EmotionParagraphCombineMethod") {
                        if (sData[1].indexOf("Max") >= 0) {
                            this.igEmotionParagraphCombineMethod = 0;
                        }

                        if (sData[1].indexOf("Av") >= 0) {
                            this.igEmotionParagraphCombineMethod = 1;
                        }

                        if (sData[1].indexOf("Tot") >= 0) {
                            this.igEmotionParagraphCombineMethod = 2;
                        }
                    } else if (sData[0] == "EmotionSentenceCombineMethod") {
                        if (sData[1].indexOf("Max") >= 0) {
                            this.igEmotionSentenceCombineMethod = 0;
                        }

                        if (sData[1].indexOf("Av") >= 0) {
                            this.igEmotionSentenceCombineMethod = 1;
                        }

                        if (sData[1].indexOf("Tot") >= 0) {
                            this.igEmotionSentenceCombineMethod = 2;
                        }
                    } else if (sData[0] == "IgnoreNegativeEmotionInQuestionSentences") {
                        this.bgReduceNegativeEmotionInQuestionSentences = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "MissCountsAsPlus2") {
                        this.bgMissCountsAsPlus2 = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "YouOrYourIsPlus2UnlessSentenceNegative") {
                        this.bgYouOrYourIsPlus2UnlessSentenceNegative = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "ExclamationCountsAsPlus2") {
                        this.bgExclamationInNeutralSentenceCountsAsPlus2 = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "UseIdiomLookupTable") {
                        this.bgUseIdiomLookupTable = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "Mood") {
                        this.igMoodToInterpretNeutralEmphasis = Integer.parseInt(sData[1]);
                    } else if (sData[0] == "AllowMultiplePositiveWordsToIncreasePositiveEmotion") {
                        this.bgAllowMultiplePositiveWordsToIncreasePositiveEmotion = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "AllowMultipleNegativeWordsToIncreaseNegativeEmotion") {
                        this.bgAllowMultipleNegativeWordsToIncreaseNegativeEmotion = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "IgnoreBoosterWordsAfterNegatives") {
                        this.bgIgnoreBoosterWordsAfterNegatives = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "MultipleLettersBoostSentiment") {
                        this.bgMultipleLettersBoostSentiment = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "BoosterWordsChangeEmotion") {
                        this.bgBoosterWordsChangeEmotion = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "NegatingWordsFlipEmotion") {
                        this.bgNegatingWordsFlipEmotion = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "NegatingWordsFlipEmotion") {
                        this.bgNegatingPositiveFlipsEmotion = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "NegatingWordsFlipEmotion") {
                        this.bgNegatingNegativeNeutralisesEmotion = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "CorrectSpellingsWithRepeatedLetter") {
                        this.bgCorrectSpellingsWithRepeatedLetter = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "UseEmoticons") {
                        this.bgUseEmoticons = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "CapitalsAreSentimentBoosters") {
                        this.bgCapitalsBoostTermSentiment = Boolean.parseBoolean(sData[1]);
                    } else if (sData[0] == "MinRepeatedLettersForBoost") {
                        this.igMinRepeatedLettersForBoost = Integer.parseInt(sData[1]);
                    } else if (sData[0] == "WordsBeforeSentimentToNegate") {
                        this.igMaxWordsBeforeSentimentToNegate = Integer.parseInt(sData[1]);
                    } else if (sData[0] == "Trinary") {
                        this.bgTrinaryMode = true;
                    } else if (sData[0] == "Binary") {
                        this.bgTrinaryMode = true;
                        this.bgBinaryVersionOfTrinaryMode = true;
                    } else {
                        if (sData[0] != "Scale") {
                            rReader.close();
                            return false;
                        }

                        this.bgScaleMode = true;
                    }
                }
            }

            rReader.close();
            return true;
        } catch (FileNotFoundException var7) {
            var7.printStackTrace();
            return false;
        } catch (IOException var8) {
            var8.printStackTrace();
            return false;
        }
    }
    /**

     根据传入的参数设置程序的名称和测量方式等信息。
     @param bTensiStrength 程序的类型，true表示TensiStrength，false表示SentiStrength。
     */
    public void nameProgram(boolean bTensiStrength) {
        // bgTensiStrength表示程序类型的布尔值
        // sgProgramName表示程序名称的字符串
        // sgProgramMeasuring表示程序测量方式的字符串
        // sgProgramPos表示程序正面情感的字符串
        // sgProgramNeg表示程序负面情感的字符串
        this.bgTensiStrength = bTensiStrength;
        if (bTensiStrength) {
            this.sgProgramName = "TensiStrength";
            this.sgProgramMeasuring = "stress and relaxation";
            this.sgProgramPos = "relaxation";
            this.sgProgramNeg = "stress";
        } else {
            this.sgProgramName = "SentiStrength";
            this.sgProgramMeasuring = "sentiment";
            this.sgProgramPos = "positive sentiment";
            this.sgProgramNeg = "negative sentiment";
        }

    }
}
