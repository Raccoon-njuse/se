// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst
// Source File Name:   TextParsingOptions.java

package uk.ac.wlv.sentistrength;


/**

 * TextParsingOptions 类是一个用于设置文本分析选项的类，可以设置包括标点符号、ngram 大小、是否使用翻译、是否添加强调代码等选项。
 * @author Mike Thelwall
 * @version 1.0.0
 */
public class TextParsingOptions
{

    /** 是否包括标点符号 */
    public boolean bgIncludePunctuation;
    /**  ngram大小 */
    public int igNgramSize;
    /** 是否使用翻译 */
    public boolean bgUseTranslations;
    /** 是否添加强调代码 */
    public boolean bgAddEmphasisCode;

    /**

     构造函数：创建 TextParsingOptions 对象并初始化默认选项
     */
    public TextParsingOptions()
    {
        // 设置默认选项
        bgIncludePunctuation = true;
        igNgramSize = 1;
        bgUseTranslations = true;
        bgAddEmphasisCode = false;
    }
}
