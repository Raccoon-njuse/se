package uk.ac.wlv.wkaclass;
import java.io.BufferedReader;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import uk.ac.wlv.sentistrength.ClassificationOptions;
import uk.ac.wlv.sentistrength.ClassificationResources;
import uk.ac.wlv.utilities.FileOps;
import uk.ac.wlv.utilities.Sort;
import uk.ac.wlv.utilities.StringIndex;
import uk.ac.wlv.sentistrength.Paragraph;
import uk.ac.wlv.sentistrength.TextParsingOptions;

/**
 * Arff类
 * <p>包含了对arff文件操作的各种方法</p>
 * @author Mike Thelwall
 * @version 1.0.0
 */
public class Arff {
   /*
   以下五个成员变量未被使用，推测它们代表不同的类型
    */
   public static final int igArffNone = 0;
   public static final int igArffBinary = 1;
   public static final int igArffTrinary = 2;
   public static final int igArffScale = 3;
   public static final int igArffPosNeg = 4;
   /*
   是否以扼要的形式保存arff文件
    */
   public static boolean bgSaveArffAsCondensed = true;

   /**
    * 根据输入的参数进行不同的操作：分类、合并标注和未标注的文件、根据标注文件将未标注文件转化为arff文件、将arff文件转化为文本文件
    * @param args 各种参数
    */
   public void main(String[] args) {
      boolean[] bArgumentRecognised = new boolean[args.length];
      String sUnlabelledTextFile = "";
      String sLabelledTextFile = "";
      String sArffFileIn = "";
      String sTextFileOut = "";
      String sClassifier = "smo";
      int iNGrams = 3;
      int iMaxFeatures = 0;
      int iClassType = 4;
      int iClassFor0 = 0;
      int iMinFeatureFrequency = 1;
      boolean bCompleteProcessing = false;
      overallHelp();

      int i;
      for(i = 0; i < args.length; ++i) {
         bArgumentRecognised[i] = false;
      }

      for(i = 0; i < args.length; ++i) {
         if (args[i].equalsIgnoreCase("arff")) {
            bArgumentRecognised[i] = true;
         }

         if (args[i].equalsIgnoreCase("complete")) {
            bCompleteProcessing = true;
            bArgumentRecognised[i] = true;
         }

         if (args[i].equalsIgnoreCase("scale")) {
            iClassType = 3;
            bArgumentRecognised[i] = true;
         }

         if (args[i].equalsIgnoreCase("binary")) {
            iClassType = 1;
            bArgumentRecognised[i] = true;
         }

         if (args[i].equalsIgnoreCase("trinary")) {
            iClassType = 2;
            bArgumentRecognised[i] = true;
         }

         if (args[i].equalsIgnoreCase("posneg")) {
            iClassType = 4;
            bArgumentRecognised[i] = true;
         }

         if (i < args.length - 1) {
            if (args[i].equalsIgnoreCase("unlabelledText")) {
               sUnlabelledTextFile = args[i + 1];
               bArgumentRecognised[i] = true;
               bArgumentRecognised[i + 1] = true;
            }

            if (args[i].equalsIgnoreCase("labelledText")) {
               sLabelledTextFile = args[i + 1];
               bArgumentRecognised[i] = true;
               bArgumentRecognised[i + 1] = true;
            }

            if (args[i].equalsIgnoreCase("arffFileIn")) {
               sArffFileIn = args[i + 1];
               bArgumentRecognised[i] = true;
               bArgumentRecognised[i + 1] = true;
            }

            if (args[i].equalsIgnoreCase("textFileOut")) {
               sTextFileOut = args[i + 1];
               bArgumentRecognised[i] = true;
               bArgumentRecognised[i + 1] = true;
            }

            if (args[i].equalsIgnoreCase("nGrams")) {
               iNGrams = Integer.parseInt(args[i + 1]);
               bArgumentRecognised[i] = true;
               bArgumentRecognised[i + 1] = true;
            }

            if (args[i].equalsIgnoreCase("maxFeatures")) {
               iMaxFeatures = Integer.parseInt(args[i + 1]);
               bArgumentRecognised[i] = true;
               bArgumentRecognised[i + 1] = true;
            }

            if (args[i].equalsIgnoreCase("classifier")) {
               sClassifier = args[i + 1];
               bArgumentRecognised[i] = true;
               bArgumentRecognised[i + 1] = true;
            }

            if (args[i].equalsIgnoreCase("zeros")) {
               iClassFor0 = Integer.parseInt(args[i + 1]);
               bArgumentRecognised[i] = true;
               bArgumentRecognised[i + 1] = true;
            }

            if (args[i].equalsIgnoreCase("minFeatureFreq")) {
               iMinFeatureFrequency = Integer.parseInt(args[i + 1]);
               bArgumentRecognised[i] = true;
               bArgumentRecognised[i + 1] = true;
            }
         }
      }

      for(i = 0; i < args.length; ++i) {
         if (!bArgumentRecognised[i]) {
            System.out.println("Unrecognised Arff command - wrong spelling or case?: " + args[i]);
            return;
         }
      }

      if (bCompleteProcessing) {
         if (sUnlabelledTextFile.length() == 0) {
            System.out.println("An unlabelled text file must be specified [complete]");
            return;
         }

         if (sLabelledTextFile.length() == 0) {
            System.out.println("A labelled text file must be specified [complete]");
            return;
         }

         System.out.println("Complete processing starting...");
         System.out.println();
         System.out.println("Convert unlabelled texts " + sUnlabelledTextFile + " to Arff based on labelled text file " + sLabelledTextFile);
         System.out.println("Options: classtype " + iClassType + " Ngrams: 1-" + iNGrams + " max features: " + iMaxFeatures + " min freq for features: " + iMinFeatureFrequency);
         System.out.println(" Classtype: None=0, Binary=1, Trinary=2, Scale=3, PosNeg=4. max features = 0 => use all features (100 per 1k is optimal)");
         String[] sLabelledUnlabelled = convertUnlabelledTextFileToArffBasedOnLabelledTextFile(sLabelledTextFile, iClassType, iNGrams, iMinFeatureFrequency, iMaxFeatures, sUnlabelledTextFile);
         String sClassifiedUnlabelledArff;
         String sClassifiedUnlabelledTextFile;
         String sMergedTextFile;
         if (iClassType == 4) {
            System.out.println("predictArffClass " + sLabelledUnlabelled[0] + " training for " + sLabelledUnlabelled[2]);
            System.out.println();
            sClassifiedUnlabelledArff = PredictClass.predictArffClass(sLabelledUnlabelled[0], sClassifier, sLabelledUnlabelled[2], iClassFor0);
            sClassifiedUnlabelledTextFile = FileOps.s_ChopFileNameExtension(sClassifiedUnlabelledArff) + "_Nout.txt";
            System.out.println("convertArffToText " + sClassifiedUnlabelledArff + " -> " + sClassifiedUnlabelledTextFile);
            System.out.println();
            convertArffToText(sClassifiedUnlabelledArff, sClassifiedUnlabelledTextFile);
            sMergedTextFile = FileOps.s_ChopFileNameExtension(sClassifiedUnlabelledTextFile) + "_Nmerged.txt";
            System.out.println("mergeLabelledAndUnlabelledTextFiles " + sClassifiedUnlabelledTextFile + ", " + sUnlabelledTextFile + " -> " + sMergedTextFile);
            mergeLabelledAndUnlabelledTextFiles(sClassifiedUnlabelledTextFile, sUnlabelledTextFile, sMergedTextFile);
            System.out.println("predictArffClass " + sLabelledUnlabelled[1] + " training for " + sLabelledUnlabelled[3]);
            System.out.println();
            sClassifiedUnlabelledArff = PredictClass.predictArffClass(sLabelledUnlabelled[1], sClassifier, sLabelledUnlabelled[3], iClassFor0);
            sClassifiedUnlabelledTextFile = FileOps.s_ChopFileNameExtension(sClassifiedUnlabelledArff) + "_Pout.txt";
            System.out.println("convertArffToText " + sClassifiedUnlabelledArff + " -> " + sClassifiedUnlabelledTextFile);
            System.out.println();
            convertArffToText(sClassifiedUnlabelledArff, sClassifiedUnlabelledTextFile);
            sMergedTextFile = FileOps.s_ChopFileNameExtension(sClassifiedUnlabelledTextFile) + "_Pmerged.txt";
            System.out.println("mergeLabelledAndUnlabelledTextFiles " + sClassifiedUnlabelledTextFile + ", " + sUnlabelledTextFile + " -> " + sMergedTextFile);
            mergeLabelledAndUnlabelledTextFiles(sClassifiedUnlabelledTextFile, sUnlabelledTextFile, sMergedTextFile);
         } else {
            System.out.println("predictArffClass " + sLabelledUnlabelled[0] + " training for " + sLabelledUnlabelled[1]);
            System.out.println();
            sClassifiedUnlabelledArff = PredictClass.predictArffClass(sLabelledUnlabelled[0], sClassifier, sLabelledUnlabelled[1], iClassFor0);
            sClassifiedUnlabelledTextFile = FileOps.s_ChopFileNameExtension(sClassifiedUnlabelledArff) + "_out.txt";
            System.out.println("convertArffToText " + sClassifiedUnlabelledArff + " -> " + sClassifiedUnlabelledTextFile);
            System.out.println();
            convertArffToText(sClassifiedUnlabelledArff, sClassifiedUnlabelledTextFile);
            sMergedTextFile = FileOps.s_ChopFileNameExtension(sClassifiedUnlabelledTextFile) + "_merged.txt";
            System.out.println("mergeLabelledAndUnlabelledTextFiles " + sClassifiedUnlabelledTextFile + ", " + sUnlabelledTextFile + " -> " + sMergedTextFile);
            mergeLabelledAndUnlabelledTextFiles(sClassifiedUnlabelledTextFile, sUnlabelledTextFile, sMergedTextFile);
         }
      } else if (sUnlabelledTextFile.length() > 0 && sLabelledTextFile.length() > 0 && sTextFileOut.length() > 0) {
         System.out.println("mergeLabelledAndUnlabelledTextFiles " + sLabelledTextFile + ", " + sUnlabelledTextFile + ", " + sTextFileOut);
         mergeLabelledAndUnlabelledTextFiles(sLabelledTextFile, sUnlabelledTextFile, sTextFileOut);
      } else if (sLabelledTextFile.length() > 0 && sUnlabelledTextFile.length() > 0) {
         System.out.println("convertUnlabelledTextFileToArffBasedOnLabelledTextFile " + sLabelledTextFile + ", " + sUnlabelledTextFile);
         convertUnlabelledTextFileToArffBasedOnLabelledTextFile(sLabelledTextFile, iClassType, iNGrams, iMinFeatureFrequency, iMaxFeatures, sUnlabelledTextFile);
      } else if (sArffFileIn.length() > 0 && sTextFileOut.length() > 0) {
         System.out.println("convertArffToText " + sArffFileIn + ", " + sTextFileOut);
         convertArffToText(sArffFileIn, sTextFileOut);
      } else {
         System.out.println("Not enough parameters entered to run a process from the arff submenu. Must enter one of the following:");
         System.out.println(" complete - and parameters, to make classify unclassified text with ML");
         System.out.println(" labelledText, unlabelledText and textFileOut - merges labelled and unlabelled files");
         System.out.println(" labelledText, unlabelledText - converts unlabelled to ARFF based on labelled");
         System.out.println(" arffFileIn, textFileOut - converts ARFF to plain text");
      }

      System.out.println("[arff] finished");
   }

   /**
    * 根据标注过的文本文件将未标注的文本文件转为arff文件
    * @param sLabelledTextFile 标注过的文本文件的文件名
    * @param iClassType 初始时根据参数binary、posneg等确定的类型
    * @param iNGrams NGrams
    * @param iMinFeatureFrequency MinFeatureFrequency
    * @param iMaxFeatures 最大特征数量
    * @param sUnlabelledTextFile 未标记的文本文件的文件名
    * @return 包含提取过特征的标注过的arff文件文件名和根据标注过的arff文件得到的未标注文件的arff文件文件名的数组
    */
   private static String[] convertUnlabelledTextFileToArffBasedOnLabelledTextFile(String sLabelledTextFile, int iClassType, int iNGrams, int iMinFeatureFrequency, int iMaxFeatures, String sUnlabelledTextFile) {
      TextParsingOptions textParsingOptions = new TextParsingOptions();
      ClassificationOptions classOptions = new ClassificationOptions();
      textParsingOptions.igNgramSize = iNGrams;
      ClassificationResources resources = new ClassificationResources();
      resources.sgSentiStrengthFolder = "c:/SentStrength_Data/";
      resources.initialise(classOptions);
      String[] sLabelledArffFiles = convertSentimentTextToArffMultiple(sLabelledTextFile, true, textParsingOptions, classOptions, resources, iClassType, iMinFeatureFrequency, "");

      int i;
      for(i = 0; i < 99 && sLabelledArffFiles[i] != null && !sLabelledArffFiles[i].equals(""); ++i) {
      }

      int iLabelledArffFileCount = i;
      String[] sLabelledArffFilesReduced;
      if (iMaxFeatures > 0) {
         sLabelledArffFilesReduced = new String[sLabelledArffFiles.length];

         for(i = 0; i < iLabelledArffFileCount; ++i) {
            sLabelledArffFilesReduced[i] = FileOps.s_ChopFileNameExtension(sLabelledArffFiles[i]) + " " + iMaxFeatures + ".arff";
            makeArffWithTopNAttributes(sLabelledArffFiles[i], iMaxFeatures, sLabelledArffFilesReduced[i]);
         }

         sLabelledArffFiles = sLabelledArffFilesReduced;
      }

      sLabelledArffFilesReduced = convertSentimentTextToArffMultiple(sUnlabelledTextFile, true, textParsingOptions, classOptions, resources, iClassType, 1, sLabelledArffFiles[i - 1]);
      String[] sResults;
      if (iClassType == 4) {
         sResults = new String[]{sLabelledArffFiles[iLabelledArffFileCount - 1], sLabelledArffFiles[iLabelledArffFileCount - 2], sLabelledArffFilesReduced[iLabelledArffFileCount - 1], sLabelledArffFilesReduced[iLabelledArffFileCount - 2]};
      } else {
         sResults = new String[]{sLabelledArffFiles[iLabelledArffFileCount - 1], sLabelledArffFilesReduced[iLabelledArffFileCount - 1]};
      }

      return sResults;
   }

   /**
    * 辅助函数，输出信息
    */
   private static void overallHelp() {
      System.out.println("--------------------------------------------------------------------------");
      System.out.println("- Text processing and ML prediction commands - arff to trigger this menu -");
      System.out.println("--------------------------------------------------------------------------");
      System.out.println("NB There is no command to convert labelled text to ARFF");
      System.out.println("A) Convert unlabelled textfile to ARFF using features in labelled textfile");
      System.out.println("unlabelledText [filename]");
      System.out.println("labelledText [filename]");
      System.out.println(" nGrams [3] 3 means all 1-3grams");
      System.out.println(" maxFeatures [0] 0=no feature reduction");
      System.out.println(" minFeatureFreq [1] ignore less frequent features");
      System.out.println(" scale binary trinary posneg(default)");
      System.out.println(" zeros [class] - class if 0 predicted. Default 0");
      System.out.println("B) Convert Arff to labelled text file");
      System.out.println("arffFileIn [filename] convert to textfile");
      System.out.println("textFileOut [filename] target textfile");
      System.out.println("C) Merge Unlabelled and labelled text files");
      System.out.println("unlabelledText [filename]");
      System.out.println("labelledText [filename]");
      System.out.println("textFileOut [filename]");
      System.out.println("D) Do all above");
      System.out.println("complete - input labelled, unlabelled, output classified text");
      System.out.println(" classifier [smo] classifier name for complete (slog, smoreg, ada, dec, libsvm, j48, mlp, jrip, bayes, liblin");
      System.out.println("*run this via command line in parallel with wkaMachineLearning");
      System.out.println("*ALL DATA must have header row, unless specified otherwise");
      System.out.println("-----------------------------------------------------------------------------");
   }

   /**
    * 将情绪文本转化为arff文本
    * @param sSentiTextFileIn 输入的情绪文本名
    * @param sArffFileOut 输出的arff文件文件名
    * @param bHeaderLine 是否有头信息
    * @param textParsingOptions 转化的具体参数
    * @param classOptions 分类的具体参数
    * @param resources 分类的资源，包括用于判断情绪的各种表单
    * @param iSentimentType main函数中根据参数类型binary、trinary等判断得到的类型
    * @param iMinFeatureFrequency main函数中根据args中给的参数确定的 MinFeatureFrequency
    * @param arffStringIndex arff的StringIndex
    * @return true
    */
   public static boolean convertSentimentTextToArff(String sSentiTextFileIn, String sArffFileOut, boolean bHeaderLine, TextParsingOptions textParsingOptions, ClassificationOptions classOptions, ClassificationResources resources, int iSentimentType, int iMinFeatureFrequency, StringIndex arffStringIndex) {
      if (arffStringIndex != null) {
         buildIndexFromTextFile(sSentiTextFileIn, bHeaderLine, textParsingOptions, classOptions, resources, iSentimentType, arffStringIndex, true);
         writeArffFromIndex(sSentiTextFileIn, arffStringIndex, bHeaderLine, textParsingOptions, classOptions, resources, iSentimentType, iMinFeatureFrequency, sArffFileOut, true);
      } else {
         StringIndex stringIndex = new StringIndex();
         stringIndex.initialise(0, true, false);
         buildIndexFromTextFile(sSentiTextFileIn, bHeaderLine, textParsingOptions, classOptions, resources, iSentimentType, stringIndex, false);
         writeArffFromIndex(sSentiTextFileIn, stringIndex, bHeaderLine, textParsingOptions, classOptions, resources, iSentimentType, iMinFeatureFrequency, sArffFileOut, false);
      }

      return true;
   }

   /**
    * 根据文本文件的stringIndex对象写arff文件
    * @param sSentiTextFileIn 输入的情绪文本文件的文件名
    * @param stringIndex 文本文件的stringIndex对象
    * @param bHeaderLine 是否包含头部
    * @param textParsingOptions 文件转化的一些参数
    * @param classOptions 分类的一些参数
    * @param resources 对情绪文本分析使用的一些表单
    * @param iSentimentType 情绪文本类型
    * @param iMinFeatureFrequency 最小特征频率
    * @param sArffFileOut 输出的arff文件的文件名
    * @param bArffIndex 参数中stringIndex对象是否是新建的
    * @return 是否成功
    */
   private static boolean writeArffFromIndex(String sSentiTextFileIn, StringIndex stringIndex, boolean bHeaderLine, TextParsingOptions textParsingOptions, ClassificationOptions classOptions, ClassificationResources resources, int iSentimentType, int iMinFeatureFrequency, String sArffFileOut, boolean bArffIndex) {
      String[] sData = null;
      boolean[] bIndexEntryUsed = new boolean[stringIndex.getLastWordID() + 2];
      boolean bOnlyCountNgramsUsed = false;

      try {
         BufferedWriter wWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(sArffFileOut), "UTF8"));
         writeArffHeadersFromIndex(sSentiTextFileIn, stringIndex, iSentimentType, textParsingOptions.igNgramSize, iMinFeatureFrequency, bArffIndex, bIndexEntryUsed, wWriter);
         BufferedReader rReader = new BufferedReader(new InputStreamReader(new FileInputStream(sSentiTextFileIn), "UTF8"));
         String sLine;
         if (bHeaderLine && rReader.ready()) {
            sLine = rReader.readLine();
         }

         while(true) {
            do {
               if (!rReader.ready()) {
                  rReader.close();
                  wWriter.close();
                  return true;
               }

               sLine = rReader.readLine();
            } while(sLine.length() <= 0);

            boolean iNgramCount = false;
            stringIndex.setAllCountsToZero();
            Paragraph para = new Paragraph();
            if (iSentimentType == 4) {
               sData = sLine.split("\t");
               if (sData.length > 2) {
                  para.setParagraph(sData[2], resources, classOptions);
               }

               if (sData.length == 1 && sLine.length() > 0) {
                  para.setParagraph(sLine, resources, classOptions);
               }
            } else if (iSentimentType == 0) {
               para.setParagraph(sLine, (ClassificationResources)null, (ClassificationOptions)null);
            } else {
               sData = sLine.split("\t");
               if (sData.length > 1) {
                  para.setParagraph(sData[1], resources, classOptions);
               }

               if (sData.length == 1 && sLine.length() > 0) {
                  para.setParagraph(sLine, resources, classOptions);
               }
            }

            int iNgramCount1 = para.addToStringIndex(stringIndex, textParsingOptions, true, bArffIndex);
            if (bOnlyCountNgramsUsed) {
               iNgramCount1 = 0;
            }

            int iClassOffset = 0;
            if (iSentimentType == 4) {
               iClassOffset = 2;
               if (sData.length > 2) {
                  if (sData[1].length() > 1 && sData[1].substring(0, 1).equals("-")) {
                     sData[1] = sData[1].substring(1);
                  }

                  if (bgSaveArffAsCondensed) {
                     wWriter.write("{0 " + sData[0].trim() + ",1 " + sData[1].trim() + ",");
                  } else {
                     wWriter.write(sData[0].trim() + "," + sData[1].trim() + ",");
                  }
               } else if (bgSaveArffAsCondensed) {
                  wWriter.write("{0 1,1 1,");
               } else {
                  wWriter.write("1,1,");
               }
            } else if (iSentimentType != 0) {
               iClassOffset = 1;
               if (sData.length > 1) {
                  if (bgSaveArffAsCondensed) {
                     wWriter.write("{0 " + sData[0].trim() + ",");
                  } else {
                     wWriter.write(sData[0].trim() + ",");
                  }
               } else if (bgSaveArffAsCondensed) {
                  wWriter.write("{0 1,");
               } else {
                  wWriter.write("1,");
               }
            } else if (bgSaveArffAsCondensed) {
               wWriter.write("{");
            }

            int iAttUsed = -1;

            for(int w = 0; w <= stringIndex.getLastWordID(); ++w) {
               if (bIndexEntryUsed[w]) {
                  ++iAttUsed;
                  if (bgSaveArffAsCondensed) {
                     if (stringIndex.getCount(w) != 0) {
                        wWriter.write(Integer.toString(iAttUsed + iClassOffset) + " " + stringIndex.getCount(w) + ",");
                     }
                  } else {
                     wWriter.write(stringIndex.getCount(w) + ",");
                  }
               }

               if (bOnlyCountNgramsUsed) {
                  iNgramCount1 += stringIndex.getCount(w);
               }
            }

            if (bgSaveArffAsCondensed) {
               ++iAttUsed;
               wWriter.write(Integer.toString(iAttUsed + iClassOffset) + " " + iNgramCount1 + "}\n");
            } else {
               wWriter.write(iNgramCount1 + "\n");
            }
         }
      } catch (IOException var21) {
         System.out.println("Could not open file for writing or write to file: " + sArffFileOut);
         var21.printStackTrace();
         return false;
      }
   }

   /**
    * 将标注过的文本文件和未标注的文本文件合并
    * @param sLabelledTextFileIn 输入的标注过的文本文件文件名
    * @param sUnlabelledTextFileIn 输入的未标注的文本文件文件名
    * @param sTextFileOut 输出的文本文件文件名
    */
   private static void mergeLabelledAndUnlabelledTextFiles(String sLabelledTextFileIn, String sUnlabelledTextFileIn, String sTextFileOut) {
      try {
         BufferedReader rLabelled = new BufferedReader(new InputStreamReader(new FileInputStream(sLabelledTextFileIn), "UTF8"));
         BufferedReader rUnlabelled = new BufferedReader(new InputStreamReader(new FileInputStream(sUnlabelledTextFileIn), "UTF8"));
         BufferedWriter wWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(sTextFileOut)));

         while(rLabelled.ready() && rUnlabelled.ready()) {
            String sLineL = rLabelled.readLine();
            String[] sDataL = sLineL.split("\t");
            String sLineU = rUnlabelled.readLine();
            if (sDataL.length > 1) {
               wWriter.write(sDataL[0] + "\t" + sLineU + "\t" + sDataL[1] + "\n");
            } else if (sDataL.length == 1) {
               wWriter.write("0\t" + sLineU + "\t" + sDataL[0] + "\n");
            } else {
               System.out.println("short labelled line [mergeLabelledAndUnlabelledTextFiles]\n" + sLineL);
            }
         }

         rLabelled.close();
         rUnlabelled.close();
         wWriter.close();
      } catch (Exception var9) {
         System.out.println("Error [mergeLabelledAndUnlabelledTextFiles]");
         var9.printStackTrace();
      }

   }

   /**
    * 根据stringIndex对象写入arff文件的头部
    * @param sSourceFile 源文件即传入的情绪文本文件的文件名
    * @param stringIndex 文本文件的stringIndex对象
    * @param iSentimentType 给定的情绪文本类型
    * @param iNgram Ngram
    * @param iMinFeatureFrequency 给定的MinFeatureFrequency
    * @param bArffIndex stringIndex对象是否为新建的stringIndex对象
    * @param bArffIndexEntryUsed arffIndex的entry是否被使用过
    * @param wWriter 输出文件对应的writer
    * @return 是否成功
    */
   private static boolean writeArffHeadersFromIndex(String sSourceFile, StringIndex stringIndex, int iSentimentType, int iNgram, int iMinFeatureFrequency, boolean bArffIndex, boolean[] bArffIndexEntryUsed, BufferedWriter wWriter) {
      String sIndexWord = "";

      try {
         wWriter.write("%Arff file from Arff.java\n");
         DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
         Date date = new Date();
         wWriter.write("%Date: " + dateFormat.format(date) + "\n");
         wWriter.write("%filename: " + sSourceFile + "\n");
         wWriter.write("@relation AllTerms\n");
         if (iSentimentType == 4) {
            wWriter.write("@attribute Pos {1,2,3,4,5}\n");
            wWriter.write("@attribute Neg {1,2,3,4,5}\n");
         } else if (iSentimentType == 1) {
            wWriter.write("@attribute Binary {-1,1}\n");
         } else if (iSentimentType == 2) {
            wWriter.write("@attribute Trinary {-1,0,1}\n");
         } else if (iSentimentType == 3) {
            wWriter.write("@attribute Scale {-4,-3,-2,-1,0,1,2,3,4}\n");
         }

         for(int w = 0; w <= stringIndex.getLastWordID(); ++w) {
            if (bArffIndex) {
               sIndexWord = stringIndex.getString(w);
               if (i_CharsInString(sIndexWord, "+".charAt(0)) < iNgram && stringIndex.getCount(w) >= iMinFeatureFrequency) {
                  bArffIndexEntryUsed[w] = true;
                  if (sIndexWord.indexOf("Q_") != 0 && sIndexWord.indexOf("R_") != 0) {
                     wWriter.write("@attribute " + sIndexWord + " numeric\n");
                  } else {
                     wWriter.write("@attribute " + stringIndex.getComment(w) + " numeric\n");
                  }
               } else {
                  bArffIndexEntryUsed[w] = false;
               }
            } else if (i_CharsInString(stringIndex.getString(w), " ".charAt(0)) < iNgram && stringIndex.getCount(w) >= iMinFeatureFrequency) {
               bArffIndexEntryUsed[w] = true;
               wWriter.write("@attribute " + arffSafeWordEncode(stringIndex.getString(w), true) + " numeric\n");
            } else {
               bArffIndexEntryUsed[w] = false;
            }
         }

         wWriter.write("@attribute Ngram_" + iNgram + "count numeric\n");
         wWriter.write("@data\n");
         return true;
      } catch (IOException var12) {
         System.out.println("Could not write ARFF headers to file [writeArffHeadersFromIndex]");
         var12.printStackTrace();
         return false;
      }
   }

   /**
    * 计算指定char在指定字符串中的数量
    * @param sText 给定的字符串
    * @param sChar 给定的字符
    * @return 计算得到的数量
    */
   private static int i_CharsInString(String sText, char sChar) {
      int iCount = 0;

      for(int i = 0; i < sText.length(); ++i) {
         try {
            if (sText.charAt(i) == sChar) {
               ++iCount;
            }
         } catch (Exception var5) {
            System.out.println("i_CharsInString error with text [" + sText + "] at position i = " + i);
            System.out.println(var5.getMessage());
         }
      }

      return iCount;
   }

   /**
    * 对arff中的字符串编码加密
    * @param sWord 要加密的字符串
    * @param bCodeNumbersForQuestionMarksNotUsed 未使用
    * @return 编码加密后的字符串
    */
   public static String arffSafeWordEncode(String sWord, boolean bCodeNumbersForQuestionMarksNotUsed) {
      String sEncodedWord = "";

      try {
         sEncodedWord = URLEncoder.encode(sWord, "UTF-8");
      } catch (UnsupportedEncodingException var4) {
         System.out.print("Fatal UnsupportedEncodingException UTF-8");
         var4.printStackTrace();
      }

      if (sEncodedWord.equals(sWord)) {
         return "U_" + sWord;
      } else {
         if (sEncodedWord.indexOf("%") >= 0) {
            sEncodedWord = sEncodedWord.replace("%", "_pc");
         }

         if (sEncodedWord.indexOf("}") >= 0) {
            sEncodedWord = sEncodedWord.replace("}", "_brak");
         }

         return "E_" + sEncodedWord;
      }
   }

   /**
    * 根据文本文件创建对应的stringIndex对象
    * @param sSentiTextFileIn 输入的情绪文本文件文件名
    * @param bHeaderLine 是否有头部
    * @param textParsingOptions 文本转化的一些参数
    * @param classOptions 分类的一些参数
    * @param resources 用于分析情绪文本的一系列表单
    * @param iSentimentType 起初有参数binary、trinary决定的文本类型
    * @param stringIndex 用于存储结果的stringIndex对象
    * @param bArffIndex 传入的stringIndex对象是否不为null
    * @return 是否成功
    */
   private static boolean buildIndexFromTextFile(String sSentiTextFileIn, boolean bHeaderLine, TextParsingOptions textParsingOptions, ClassificationOptions classOptions, ClassificationResources resources, int iSentimentType, StringIndex stringIndex, boolean bArffIndex) {
      File f = new File(sSentiTextFileIn);
      if (!f.exists()) {
         System.out.println("Could not find the vocab file: " + sSentiTextFileIn);
         return false;
      } else {
         try {
            BufferedReader rReader = new BufferedReader(new InputStreamReader(new FileInputStream(sSentiTextFileIn), "UTF8"));
            String sLine;
            if (bHeaderLine && rReader.ready()) {
               sLine = rReader.readLine();
            }

            while(rReader.ready()) {
               sLine = rReader.readLine();
               if (sLine.length() > 0) {
                  Paragraph para = new Paragraph();
                  String[] sData;
                  if (iSentimentType == 4) {
                     sData = sLine.split("\t");
                     if (sData.length > 2) {
                        para.setParagraph(sData[2], resources, classOptions);
                     }

                     if (sData.length == 1 && sLine.length() > 0) {
                        para.setParagraph(sLine, resources, classOptions);
                     }
                  } else if (iSentimentType == 0) {
                     para.setParagraph(sLine, (ClassificationResources)null, (ClassificationOptions)null);
                  } else {
                     sData = sLine.split("\t");
                     if (sData.length > 1) {
                        para.setParagraph(sData[1], resources, classOptions);
                     }

                     if (sData.length == 1 && sLine.length() > 0) {
                        para.setParagraph(sLine, resources, classOptions);
                     }
                  }

                  para.addToStringIndex(stringIndex, textParsingOptions, true, bArffIndex);
               }
            }

            rReader.close();
            return true;
         } catch (IOException var14) {
            System.out.println("Could not open file for reading or read from file: " + sSentiTextFileIn);
            var14.printStackTrace();
            return false;
         }
      }
   }

   /**
    * 根据Arff文件创建StringIndex对象并返回
    * @param sArffFileIn 输入的arff文件文件名
    * @return StringIndex对象 如果有异常则会返回null
    */
   private static StringIndex buildIndexFromArff(String sArffFileIn) {
      File f = new File(sArffFileIn);
      if (!f.exists()) {
         System.out.println("Could not find the ARFF file: " + sArffFileIn);
         return null;
      } else {
         StringIndex stringIndex = new StringIndex();
         stringIndex.initialise(0, true, true);
         int iPos =0;
         int iStringLastOld =0;
         int var8 = 898989;

         try {
            BufferedReader rReader = new BufferedReader(new InputStreamReader(new FileInputStream(sArffFileIn)));

            while(rReader.ready()) {
               String sLine = rReader.readLine();
               if (sLine.indexOf("@data") >= 0) {
                  break;
               }

               if (sLine.length() > 0) {
                  String[] sData = sLine.split(" ");
                  if (sData.length == 3 && sData[0].equals("@attribute") && sData[2].equals("numeric") && sData[1].length() > 2 && sData[1].indexOf("Ngram") < 0) {
                     int iStringLastOld1 = stringIndex.getLastWordID();
                     if (sData[1].substring(1).equals("Q")) {
                        iPos = sData[1].indexOf("_");
                        if (iPos > 0) {
                           stringIndex.addString(sData[1].substring(iPos), false);
                           if (iStringLastOld1 != stringIndex.getLastWordID()) {
                              stringIndex.addComment(iStringLastOld1 + 1, sLine);
                           }
                        } else {
                           System.out.println("Invalid Q index entry: " + sLine + " in " + sArffFileIn);
                        }
                     } else {
                        stringIndex.addString(sData[1], false);
                     }

                     for(; iStringLastOld1 == stringIndex.getLastWordID(); System.out.println("Invalid or duplicate index entry: " + sLine + " in " + sArffFileIn)) {
                        stringIndex.addString("R_" + var8++, false);
                        if (iStringLastOld1 != stringIndex.getLastWordID()) {
                           stringIndex.addComment(iStringLastOld1 + 1, sLine);
                        }
                     }
                  }
               }
            }

            rReader.close();
            return stringIndex;
         } catch (IOException var10) {
            System.out.println("Couldn't open/read from: " + sArffFileIn);
            var10.printStackTrace();
            return null;
         }
      }
   }

   /**
    * 合并两个arff文件
    * @param sArffFile1 第一个arff文件的文件名
    * @param sArffFile2 第二个arff文件的文件名
    * @param bVerbose 是否采用详细模式 打印出重复的属性行
    * @param sMergedArffFile 要合并到的arff文件的文件名
    * @return 是否合并成功
    */
   public static boolean combineTwoARFFs(String sArffFile1, String sArffFile2, boolean bVerbose, String sMergedArffFile) {
      File f = new File(sArffFile1);
      if (!f.exists()) {
         System.out.println("Couldn't find Arff file: " + sArffFile1);
         return false;
      } else {
         f = new File(sArffFile2);
         if (!f.exists()) {
            System.out.println("Couldn't find Arff file: " + sArffFile2);
            return false;
         } else {
            int[] iAttributeArray = new int[1];

            try {
               BufferedReader rReader1 = new BufferedReader(new InputStreamReader(new FileInputStream(sArffFile1)));
               BufferedReader rReader2 = new BufferedReader(new InputStreamReader(new FileInputStream(sArffFile2)));
               BufferedWriter wWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(sMergedArffFile)));
               printArffHeader(rReader1, wWriter, false);
               printArffHeader(rReader2, wWriter, true);
               String[] sAttributes1 = loadArffAttributes(rReader1, iAttributeArray);
               int iAttributes1Count = iAttributeArray[0];
               String[] sAttributes2 = loadArffAttributes(rReader2, iAttributeArray);
               int iAttributes2Count = iAttributeArray[0];
               boolean[] bDuplicate2 = printNonDuplicateAttributes(sAttributes1, iAttributes1Count, sAttributes2, iAttributes2Count, bVerbose, wWriter);
               printDataWithoutDuplicates(rReader1, rReader2, bDuplicate2, iAttributes1Count, iAttributes2Count, wWriter);
               rReader1.close();
               rReader2.close();
               wWriter.close();
               return true;
            } catch (IOException var14) {
               System.out.println("I/O error with input or output file, e.g.,: " + sArffFile1);
               var14.printStackTrace();
               return false;
            }
         }
      }
   }

   /**
    * 删除指定的列并将剩下的列中的第一列移到最后
    * @param sArffFileIn 输入的arff文件的文件名
    * @param iColToDelete 要删除的列号
    * @param sArffFileOut 得到的新的arff文件的文件名
    * @return 是否成功
    */
   public static boolean deleteColAndMoveRemainingFirstColToEnd(String sArffFileIn, int iColToDelete, String sArffFileOut) {
      File f = new File(sArffFileIn);
      if (!f.exists()) {
         System.out.println("Could not find Arff file: " + sArffFileIn);
         return false;
      } else {
         String sArffTemp = sArffFileIn + ".temp";
         f = new File(sArffTemp);
         if (f.exists()) {
            f.delete();
         }

         deleteColumnFromArff(sArffFileIn, iColToDelete, sArffTemp);
         moveColumnToEndOfArff(sArffTemp, 1, sArffFileOut);
         f = new File(sArffTemp);
         if (f.exists()) {
            f.delete();
         }

         return true;
      }
   }

   /**
    * 将输入的arff文件中要移动的列移动到最后形成一个新的arff文件
    * @param sArffFileIn 输入的arff文件的文件名
    * @param iColToMove 要移动的列号
    * @param sArffFileOut 得到的新的arff文件的文件名
    * @return 是否成功
    */
   public static boolean moveColumnToEndOfArff(String sArffFileIn, int iColToMove, String sArffFileOut) {
      File f = new File(sArffFileIn);
      if (!f.exists()) {
         System.out.println("Could not find Arff file: " + sArffFileIn);
         return false;
      } else {
         String[] sAttributes = null;
         int[] iAttArr = new int[1];

         try {
            BufferedReader srArff = new BufferedReader(new InputStreamReader(new FileInputStream(sArffFileIn)));
            BufferedWriter swNew = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(sArffFileOut)));
            printArffHeader(srArff, swNew, true);
            sAttributes = loadArffAttributes(srArff, iAttArr);
            int iAttributesCount = iAttArr[0];
            boolean[] bDelete = new boolean[iAttributesCount + 1];

            for(int i = 0; i <= iAttributesCount; ++i) {
               bDelete[i] = false;
            }

            bDelete[iColToMove] = true;
            printSelectedAttributes(sAttributes, iAttributesCount, bDelete, swNew, false);
            swNew.write(sAttributes[iColToMove] + "\n");
            printSelectedData(srArff, bDelete, iAttributesCount, swNew, true, false);
            swNew.close();
            srArff.close();
            return true;
         } catch (IOException var11) {
            System.out.println("File i/o error [moveColumnToEndOfArff]" + sArffFileIn + " or " + sArffFileOut);
            var11.printStackTrace();
            return false;
         }
      }
   }

   /**
    * 将iNgram加入到文件名中并将文件拓展名改为.arff
    * @param sSentiTextFileIn 输入的情绪文本的文件名
    * @param iNgram Ngram的值
    * @return 得到的加入Ngram后的arff文件名
    */
   public static String ngramFileName(String sSentiTextFileIn, int iNgram) {
      return FileOps.s_ChopFileNameExtension(sSentiTextFileIn) + "_" + iNgram + ".arff";
   }

   /**
    * Ngram大于1时，将iNgram加入到文件名中并将文件拓展名改为.arff
    * @param sSentiTextFileIn 输入的情绪文本的文件名输入的情绪文本的文件名
    * @param iNgram Ngram的值
    * @return 得到的加入Ngram后的arff文件名
    */
   public static String oneToNgramFileName(String sSentiTextFileIn, int iNgram) {
      return FileOps.s_ChopFileNameExtension(sSentiTextFileIn) + "_1-" + iNgram + ".arff";
   }

   /**
    * 如果是pos的就返回后缀为pos.arff的arff文件名反之则返回后缀为neg.arff的arff文件名
    * @param sSentiTextFileIn 输入的情绪文本的文件名
    * @param iNgram iNgram的值
    * @param bPos 是否pos
    * @return 修改后的arff文件名
    */
   public static String ngramFileNamePosNeg(String sSentiTextFileIn, int iNgram, boolean bPos) {
      return bPos ? FileOps.s_ChopFileNameExtension(sSentiTextFileIn) + "_" + iNgram + "pos.arff" : FileOps.s_ChopFileNameExtension(sSentiTextFileIn) + "_" + iNgram + "neg.arff";
   }

   /**
    * Ngram大于1时，使用的ngramFileNamePosNeg方法
    * @param sSentiTextFileIn 输入的情绪文本的文件名
    * @param iNgram iNgram的值
    * @param bPos 是否pos
    * @return 修改后的arff文件名
    */
   public static String oneToNgramFileNamePosNeg(String sSentiTextFileIn, int iNgram, boolean bPos) {
      return bPos ? FileOps.s_ChopFileNameExtension(sSentiTextFileIn) + "_1-" + iNgram + "pos.arff" : FileOps.s_ChopFileNameExtension(sSentiTextFileIn) + "_1-" + iNgram + "neg.arff";
   }

   /**
    * 将情绪文本文件转化为多个arff文件
    * @param sSentiTextFileIn 输入的情绪文本文件的文件名
    * @param bHeaderLine 是否写入头部
    * @param textParsingOptions 文本转化的一些参数
    * @param classOptions 分类的一些参数
    * @param resources 用到的一些表单
    * @param iSentimentType 由参数binary、trinary等确定的类型
    * @param iMinFeatureFrequency 由初始参数确定的MinFeatureFrequency
    * @param sArffFileForPermittedFeaturesList 允许的特征列表对应的arff文件名
    * @return 得到的arff文件的文件名的数组
    */
   public static String[] convertSentimentTextToArffMultiple(String sSentiTextFileIn, boolean bHeaderLine, TextParsingOptions textParsingOptions, ClassificationOptions classOptions, ClassificationResources resources, int iSentimentType, int iMinFeatureFrequency, String sArffFileForPermittedFeaturesList) {
      File f = new File(sSentiTextFileIn);
      if (!f.exists()) {
         System.out.println("Could not find sentiment file: " + sSentiTextFileIn);
         return null;
      } else {
         StringIndex arffStringIndex = null;
         if (!sArffFileForPermittedFeaturesList.equals("")) {
            arffStringIndex = buildIndexFromArff(sArffFileForPermittedFeaturesList);
         }

         int iNgramMax = textParsingOptions.igNgramSize;
         String sLastCombinedOutFile = "";

         int iNgram;
         String sOutFile;
         for(iNgram = 1; iNgram <= iNgramMax; ++iNgram) {
            textParsingOptions.igNgramSize = iNgram;
            sOutFile = ngramFileName(sSentiTextFileIn, iNgram);
            f = new File(sOutFile);
            if (f.exists()) {
               f.delete();
            }

            convertSentimentTextToArff(sSentiTextFileIn, sOutFile, bHeaderLine, textParsingOptions, classOptions, resources, iSentimentType, iMinFeatureFrequency, arffStringIndex);
            if (iNgram > 1) {
               String sNewCombinedOutFile = oneToNgramFileName(sSentiTextFileIn, iNgram);
               f = new File(sNewCombinedOutFile);
               if (f.exists()) {
                  f.delete();
               }

               combineTwoARFFs(sLastCombinedOutFile, sOutFile, false, sNewCombinedOutFile);
               sLastCombinedOutFile = sNewCombinedOutFile;
            } else {
               sLastCombinedOutFile = sOutFile;//第一次合并结果就是sOutFile
            }
         }

         int iOutfileLast = -1;
         String[] sFinalOutFile = new String[100];
         if (iSentimentType == 4) {//类型是posneg
            for(iNgram = 1; iNgram <= iNgramMax; ++iNgram) {
               sOutFile = ngramFileName(sSentiTextFileIn, iNgram);
               ++iOutfileLast;
               sFinalOutFile[iOutfileLast] = ngramFileNamePosNeg(sSentiTextFileIn, iNgram, true);
               deleteColAndMoveRemainingFirstColToEnd(sOutFile, 2, sFinalOutFile[iOutfileLast]);
               ++iOutfileLast;
               sFinalOutFile[iOutfileLast] = ngramFileNamePosNeg(sSentiTextFileIn, iNgram, false);
               deleteColAndMoveRemainingFirstColToEnd(sOutFile, 1, sFinalOutFile[iOutfileLast]);
               f = new File(sOutFile);
               f.delete();
               if (iNgram > 1) {
                  sOutFile = oneToNgramFileName(sSentiTextFileIn, iNgram);
                  ++iOutfileLast;
                  sFinalOutFile[iOutfileLast] = oneToNgramFileNamePosNeg(sSentiTextFileIn, iNgram, true);
                  deleteColAndMoveRemainingFirstColToEnd(sOutFile, 2, sFinalOutFile[iOutfileLast]);
                  ++iOutfileLast;
                  sFinalOutFile[iOutfileLast] = oneToNgramFileNamePosNeg(sSentiTextFileIn, iNgram, false);
                  deleteColAndMoveRemainingFirstColToEnd(sOutFile, 1, sFinalOutFile[iOutfileLast]);
                  f = new File(sOutFile);
                  f.delete();
               }
            }
         } else if (iSentimentType == 1 || iSentimentType == 2 || iSentimentType == 3) {
            for(iNgram = 1; iNgram <= iNgramMax; ++iNgram) {
               ++iOutfileLast;
               sFinalOutFile[iOutfileLast] = ngramFileName(sSentiTextFileIn, iNgram);
               File g = new File(sFinalOutFile[iOutfileLast] + ".temp");
               f = new File(sFinalOutFile[iOutfileLast]);
               f.renameTo(g);
               moveColumnToEndOfArff(sFinalOutFile[iOutfileLast] + ".temp", 1, sFinalOutFile[iOutfileLast]);
               g.delete();
               if (iNgram > 1) {
                  ++iOutfileLast;
                  sFinalOutFile[iOutfileLast] = oneToNgramFileName(sSentiTextFileIn, iNgram);
                  g = new File(sFinalOutFile[iOutfileLast] + ".temp");
                  f = new File(sFinalOutFile[iOutfileLast]);
                  f.renameTo(g);
                  moveColumnToEndOfArff(sFinalOutFile[iOutfileLast] + ".temp", 1, sFinalOutFile[iOutfileLast]);
                  g.delete();
               }
            }
         }

         return sFinalOutFile;
      }
   }

   /**
    * 将输入的arff文件中要求删除的列删除后得到一个新的arff文件
    * @param sArffFile 输入的arff文件的文件名
    * @param iColToRemove 要删除的列号
    * @param sNewArffFile 新的arff文件的文件名
    * @return 是否成功
    */
   public static boolean deleteColumnFromArff(String sArffFile, int iColToRemove, String sNewArffFile) {
      File f = new File(sArffFile);
      if (!f.exists()) {
         System.out.println("Could not find Arff file: " + sArffFile);
         return false;
      } else {
         String[] sAttributes = null;
         int iAttributesCount =0;
         int[] iAttArr = new int[1];

         try {
            BufferedReader rArff = new BufferedReader(new InputStreamReader(new FileInputStream(sArffFile)));
            BufferedWriter wNew = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(sNewArffFile)));
            printArffHeader(rArff, wNew, true);
            sAttributes = loadArffAttributes(rArff, iAttArr);
            iAttributesCount = iAttArr[0];
            boolean[] bDelete = new boolean[iAttributesCount + 1];

            for(int i = 0; i <= iAttributesCount; ++i) {
               bDelete[i] = false;
            }

            bDelete[iColToRemove] = true;
            printSelectedAttributes(sAttributes, iAttributesCount, bDelete, wNew, false);
            printSelectedData(rArff, bDelete, iAttributesCount, wNew, false, true);
            wNew.close();
            rArff.close();
            return true;
         } catch (IOException var11) {
            System.out.println("I/O error with input or output file, e.g.,: " + sArffFile);
            var11.printStackTrace();
            return false;
         }
      }
   }

   /**
    * 根据输入的bDelete数组将不需要删除的属性行写入新的arff文件中
    * @param sAttributes 原本的属性行数组
    * @param iAttributesCount 属性行数组的长度
    * @param bDelete 每个元素代表属性行中该行是否需要删除的boolean数组
    * @param swNew 删除要求的属性行后新的arff文件对应的writer
    * @param bVerbose 是否要打印出删除的属性行
    * @return 是否成功
    */
   private static boolean printSelectedAttributes(String[] sAttributes, int iAttributesCount, boolean[] bDelete, BufferedWriter swNew, boolean bVerbose) {
      int iDelCount = 0;
      String sDelList = "";

      try {
         if (sAttributes[0] != null) {
            swNew.write(sAttributes[0] + "\n");
         }

         for(int i = 1; i <= iAttributesCount; ++i) {
            if (!bDelete[i]) {
               swNew.write(sAttributes[i] + "\n");
            } else {
               ++iDelCount;
               if (bVerbose) {
                  sDelList = sDelList + sAttributes[i];
               }
            }
         }

         if (bVerbose) {
            System.out.println(iDelCount + " deleted out of " + iAttributesCount + "\n" + sDelList);
         }

         return true;
      } catch (IOException var9) {
         System.out.println("Error writing [printSelectedAttributes]");
         var9.printStackTrace();
         return false;
      }
   }

   /**
    * 把输入的arff文件中需要的数据写入要求的arff文件中
    * @param srArff 输入的arff文件对应的reader
    * @param bDeleteCol 标志每一个属性是否需要删除的boolean数组
    * @param iAttributeCount 属性的个数
    * @param swOutput 输出的arff文件对应的writer
    * @param bPrintDeletedColsAtEnd 是否要把删除的列写在最后
    * @param bVerbose 是否要输出被删除的列
    * @return 是否成功
    */
   private static boolean printSelectedData(BufferedReader srArff, boolean[] bDeleteCol, int iAttributeCount, BufferedWriter swOutput, boolean bPrintDeletedColsAtEnd, boolean bVerbose) {
      int[] iAttID = new int[iAttributeCount + 1];
      int[] iData = new int[iAttributeCount + 1];
      int iPairs = 1;
      int iCount = 0;
      int iLastPrintedAttribute = 0;
      int[] iNewAttributeID = new int[iAttributeCount + 1];
      int iAttUsed = 0;

      int iCol;
      for(iCol = 1; iCol <= iAttributeCount; ++iCol) {
         if (!bDeleteCol[iCol]) {
            iLastPrintedAttribute = iCol;
            iNewAttributeID[iCol - 1] = iAttUsed++;
         }
      }

      for(iCol = 1; iCol <= iAttributeCount; ++iCol) {
         if (bDeleteCol[iCol]) {
            iNewAttributeID[iCol - 1] = iAttUsed++;//要删除的属性的列放在最后
         }
      }

      try {
         swOutput.write("@data\n");

         label105:
         while(true) {
            while(true) {
               String sLine;
               do {
                  if (!srArff.ready()) {
                     break label105;
                  }

                  sLine = srArff.readLine();
                  ++iCount;
               } while(sLine.length() <= 0);

               String[] sData;
               if (bgSaveArffAsCondensed) {
                  iPairs = -1;
                  sData = sLine.substring(1, sLine.length() - 1).split(",");

                  for(int iPair = 0; iPair < sData.length; ++iPair) {
                     if (sData[iPair].length() > 2) {
                        String[] sIDVal = sData[iPair].trim().split(" ");
                        int iSourceID = Integer.parseInt(sIDVal[0]);
                        if (bPrintDeletedColsAtEnd || !bDeleteCol[iSourceID + 1]) {
                           ++iPairs;
                           iAttID[iPairs] = iNewAttributeID[iSourceID];

                           try {
                              iData[iPairs] = Integer.parseInt(sIDVal[1]);
                           } catch (Exception var21) {
                              iData[iPairs] = 0;
                           }
                        }
                     }
                  }

                  printCondensedData(swOutput, iAttID, iData, iPairs);
               } else {
                  String sDeletedCols = "";
                  sData = sLine.split(",");

                  for(iCol = 1; iCol < iLastPrintedAttribute; ++iCol) {
                     if (!bDeleteCol[iCol]) {
                        swOutput.write(sData[iCol - 1] + ",");
                     } else {
                        sDeletedCols = sDeletedCols + sData[iCol - 1] + ",";
                     }
                  }

                  if (!bPrintDeletedColsAtEnd) {
                     swOutput.write(sData[iLastPrintedAttribute - 1] + "\n");
                  } else {
                     for(iCol = iLastPrintedAttribute; iCol <= iAttributeCount; ++iCol) {
                        if (bDeleteCol[iCol]) {
                           sDeletedCols = sDeletedCols + sData[iCol - 1] + ",";
                        }
                     }

                     if (sDeletedCols.length() > 0) {
                        swOutput.write(sData[iLastPrintedAttribute - 1] + "," + sDeletedCols.substring(0, sDeletedCols.length() - 1) + "\n");
                     } else {
                        swOutput.write(sData[iLastPrintedAttribute - 1] + "\n");
                     }
                  }
               }
            }
         }
      } catch (IOException var22) {
         System.out.println("I/O error with input or output file [printSelectedData]");
         var22.printStackTrace();
         return false;
      }

      if (bVerbose) {
         System.out.println(iCount + " lines of data saved");
      }

      return true;
   }

   /**
    * 将被删除的数据写入arff文件的最后
    * @param swArff arff文件对应的writer
    * @param iAtt 每一个要写的属性的列数的数组
    * @param iData 每一个要写的数据的数组
    * @param iLastPair 一共多少列
    */
   private static void printCondensedData(BufferedWriter swArff, int[] iAtt, int[] iData, int iLastPair) {
      Sort.quickSortIntWithInt(iAtt, iData, 0, iLastPair);

      try {
         swArff.write("{");
         if (iLastPair > -1) {
            swArff.write(iAtt[0] + " " + iData[0]);
         }

         for(int iPair = 1; iPair <= iLastPair; ++iPair) {
            swArff.write("," + iAtt[iPair] + " " + iData[iPair]);
         }

         swArff.write("}\n");
      } catch (IOException var5) {
         var5.printStackTrace();
      }

   }

   /**
    * 将两个arff文件中的@data段即数据段写入要合并到的arff文件中并且去除掉第二个arff文件中与第一个arff文件中重复的列
    * @param rArff1 第一个arff文件对应的reader
    * @param rArff2 第二个arff文件对应的reader
    * @param bDuplicate2 printNonDuplicateAttributes方法返回的包含第二个arff文件中每个属性行是否在第一个arff文件中属性行有重复的boolean数组
    * @param iAttributes1Count 第一个arff文件中属性行数
    * @param iAttributes2Count 第二个arff文件中属性行数
    * @param wMerged 要合并到的arff文件对应的writer
    */
   private static void printDataWithoutDuplicates(BufferedReader rArff1, BufferedReader rArff2, boolean[] bDuplicate2, int iAttributes1Count, int iAttributes2Count, BufferedWriter wMerged) {
      int iAttUsed = 0;
      int[] iAttribute2ID = new int[iAttributes2Count + 1];//第二个属性数组每个不与第一个属性文件中属性重复的属性对应列号

      int iCol;
      for(iCol = 1; iCol <= iAttributes2Count; ++iCol) {
         if (!bDuplicate2[iCol]) {
            iAttribute2ID[iCol] = iAttUsed++ + iAttributes1Count;//+iAttributes1Count是因为第二个属性数组的属性跟在第一个属性数组的后面
         }
      }

      try {
         wMerged.write("@data\n");

         while(true) {
            while(true) {
               String sLine1;
               String sLine2;
               do {
                  if (!rArff1.ready() || !rArff2.ready()) {
                     return;
                  }

                  sLine1 = rArff1.readLine();
                  sLine2 = rArff2.readLine();
               } while(sLine2.equals(""));

               String[] sData2;
               if (bgSaveArffAsCondensed) {
                  wMerged.write(sLine1.substring(0, sLine1.length() - 1));
                  iAttUsed=0;
                  sData2 = sLine2.substring(1, sLine2.length() - 1).split(",");

                  for(int iPair = 0; iPair < sData2.length; ++iPair) {
                     try {
                        String[] sIDValue = sData2[iPair].trim().split(" ");
                        iCol = Integer.parseInt(sIDValue[0]) + 1;
                        if (!bDuplicate2[iCol]) {
                           wMerged.write(", " + iAttribute2ID[iCol] + " " + sIDValue[1]);
                        }
                     } catch (Exception var15) {
                        System.out.println("Error processing ID value pair " + sData2[iPair] + " [printDataWithoutDuplicates]");
                        var15.printStackTrace();
                     }
                  }

                  wMerged.write("}\n");
               } else {
                  wMerged.write(sLine1);
                  sData2 = sLine2.split(",");

                  for(iCol = 1; iCol <= iAttributes2Count; ++iCol) {
                     if (!bDuplicate2[iCol]) {
                        wMerged.write("," + sData2[iCol - 1]);
                     }
                  }

                  wMerged.write("\n");
               }
            }
         }
      } catch (IOException var16) {
         System.out.println("Error writing to file [printDataWithoutDuplicates]");
         var16.printStackTrace();
      }
   }

   /**
    * 将输入的两个属性行字符串数组中的属性行写入wMerged对应的文件中，两个属性行字符串数组中重复的属性行只写入一次
    * @param sAttributes1 第一个属性行字符串数组
    * @param iAttributes1Count 第一个属性行字符串数组的长度
    * @param sAttributes2 第二个属性行字符串数组
    * @param iAttributes2Count 第二个属性行字符串数组的长度
    * @param bVerbose 是否要记录下重复的属性行
    * @param wMerged 要写入的文件对应的writer
    * @return 一个boolean数组，长度为第二个字符串数组的长度，每一个元素表示第二个属性行字符串数组中该行是否与第一个属性行数组中的某一行重复
    */
   private static boolean[] printNonDuplicateAttributes(String[] sAttributes1, int iAttributes1Count, String[] sAttributes2, int iAttributes2Count, boolean bVerbose, BufferedWriter wMerged) {
      int iDupCount = 0;
      String sDuplicateList = "";
      boolean[] bDuplicate2 = new boolean[iAttributes2Count + 1];

      try {
         int i;
         for(i = 1; i <= iAttributes1Count; ++i) {
            wMerged.write(sAttributes1[i] + "\n");
         }

         for(int j = 1; j <= iAttributes2Count; ++j) {
            for(i = 1; i <= iAttributes1Count; ++i) {
               if (sAttributes2[j].equals(sAttributes1[i])) {
                  if (bVerbose) {
                     sDuplicateList = sDuplicateList + sAttributes1[i] + " | ";
                  }

                  bDuplicate2[j] = true;
                  ++iDupCount;
                  break;
               }
            }

            if (!bDuplicate2[j]) {
               wMerged.write(sAttributes2[j] + "\n");
            }
         }
      } catch (IOException var12) {
         System.out.println("Error writing to file file [printNonDuplicateAttributes]");
         var12.printStackTrace();
      }

      if (bVerbose) {
         System.out.println(iDupCount + " duplicates found out of " + iAttributes1Count + "\n" + sDuplicateList);
      }

      return bDuplicate2;
   }

   /**
    * 将输入的arff文件的头部写入到输出的arff文件中
    * @param rArffIn 输入的arff文件对应的reader
    * @param wArffOut 输出的arff文件名对应的reader
    * @param bPrintRelation 是否打印@relation字段
    * @return 写入输出文件的行数
    */
   private static int printArffHeader(BufferedReader rArffIn, BufferedWriter wArffOut, boolean bPrintRelation) {
      int iLineCount = 0;
      String sLine = "";

      try {
         if (rArffIn.ready()) {
            sLine = rArffIn.readLine();
         }

         while(rArffIn.ready() && sLine.indexOf("@relation ") != 0) {
            wArffOut.write(sLine + "\n");
            ++iLineCount;
            sLine = rArffIn.readLine();
         }

         if (bPrintRelation) {
            wArffOut.write(sLine + "\n");
         }
      } catch (IOException var6) {
         var6.printStackTrace();
      }

      return iLineCount;
   }

   /**
    * 加载输入入的arff文件中的属性行
    * @param rArffIn 输入的arff文件对应的reader
    * @param iAttributeCountArr 用于记录属性行行数的大小为1的数组
    * @return 存储有每个属性行的字符串数组
    */
   private static String[] loadArffAttributes(BufferedReader rArffIn, int[] iAttributeCountArr) {
      String sLine = "";
      int iMaxAttributes = 10000;
      int iAttributesCount = 0;
      String[] sAttributes = new String[iMaxAttributes];

      try {
         if (rArffIn.ready()) {
            sLine = rArffIn.readLine();
         }

         for(; rArffIn.ready() && sLine.indexOf("@data") != 0; sLine = rArffIn.readLine()) {
            if (!sLine.equals("") && !sLine.substring(0, 1).equals("%")) {
               if (sLine.indexOf("@relation ") == 0) {
                  sAttributes[0] = sLine;
               } else {
                  ++iAttributesCount;
                  if (iAttributesCount == iMaxAttributes - 1) {
                     sAttributes = increaseArraySize(sAttributes, iMaxAttributes, 2 * iMaxAttributes);
                     iMaxAttributes *= 2;
                  }

                  sAttributes[iAttributesCount] = sLine;
               }
            }
         }
      } catch (IOException var7) {
         var7.printStackTrace();
      }

      iAttributeCountArr[0] = iAttributesCount;
      return sAttributes;
   }

   private static String[] increaseArraySize(String[] sArray, int iCurrentArraySize, int iNewArraySize) {
      if (iNewArraySize <= iCurrentArraySize) {
         return sArray;
      } else {
         String[] sArrayTemp = new String[iNewArraySize];
         System.arraycopy(sArray, 0, sArrayTemp, 0, iCurrentArraySize);
         return sArrayTemp;
      }
   }

   /**
    * 选取指定个数的信息增益值大的属性
    * @param fColIG 每个属性的信息增益
    * @param iAttributeCount 属性数
    * @param iFeaturesToSelect 要选取的特征数
    * @param bUseCol 每个属性是否被选用
    */
   private static void selectTopNAttributes(double[] fColIG, int iAttributeCount, int iFeaturesToSelect, boolean[] bUseCol) {
      int[] iIndex = new int[iAttributeCount + 1];

      int i;
      for(i = 1; i <= iAttributeCount; ++i) {
         iIndex[i] = i;
         bUseCol[i] = false;
      }

      Sort.quickSortNumbersDescendingViaIndex(fColIG, iIndex, 1, iAttributeCount);
      bUseCol[iAttributeCount] = true;
      bUseCol[0] = true;
      if (iFeaturesToSelect > 0) {
         bUseCol[iIndex[1]] = true;
         --iFeaturesToSelect;

         for(i = 2; i <= iAttributeCount && iFeaturesToSelect >= 1; ++i) {
            bUseCol[iIndex[i]] = true;
            --iFeaturesToSelect;
         }
      }

   }

   /**
    * 将每个属性的信息增益值写入指定的输出文件中
    * @param fColIG 每个属性的信息增益值
    * @param sAttributes 属性行的字符串数组
    * @param iAttributeCount 属性个数
    * @param sIGListOut 输出文件的文件名
    */
   private static void printInformationGainValues(double[] fColIG, String[] sAttributes, int iAttributeCount, String sIGListOut) {
      DecimalFormat df = new DecimalFormat("#.######");
      int[] iIndex = new int[iAttributeCount + 1];

      int iCol;
      for(iCol = 1; iCol <= iAttributeCount; iIndex[iCol] = iCol++) {
      }

      Sort.quickSortNumbersDescendingViaIndex(fColIG, iIndex, 1, iAttributeCount);

      try {
         BufferedWriter wWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(sIGListOut)));

         for(iCol = 1; iCol <= iAttributeCount; ++iCol) {
            wWriter.write(sAttributes[iIndex[iCol]] + " " + df.format(fColIG[iIndex[iCol]]) + "\r\n");
         }

         wWriter.close();
      } catch (IOException var8) {
         var8.printStackTrace();
      }

   }

   /**
    * 计算数据的信息增益
    * @param iData 存放数据的二维数组
    * @param iAttributeCount 属性数
    * @param iDataCount 数据的行数
    * @param fColIG 存放每一列的信息增益
    */
   private static void calculateInformationGainOfData(int[][] iData, int iAttributeCount, int iDataCount, double[] fColIG) {
      int iClassAttribute = iAttributeCount;
      int[] iAttributeValue = new int[1001];
      int iFirstClass = findFirstClassInData(iData, iDataCount, iAttributeCount);
      int iLastClass = findLastClassInData(iData, iDataCount, iAttributeCount);
      int[] iClass = new int[iLastClass + 1];
      double fOverallEntropy = calculateClassesAndEntropyOfData(iData, iAttributeCount, iDataCount, iClass, iFirstClass, iLastClass);
      int[] iAttributeValueClassCount = new int[iLastClass + 1];

      for(int iCol = 1; iCol < iAttributeCount; ++iCol) {
         int iAttributeValueCount = 0;

         int iRow;
         int i;
         for(iRow = 1; iRow <= iDataCount; ++iRow) {
            boolean bFound = false;

            for(i = 1; i <= iAttributeValueCount; ++i) {
               if (iAttributeValue[i] == iData[iCol][iRow]) {
                  bFound = true;
                  break;
               }
            }

            if (!bFound) {
               ++iAttributeValueCount;
               iAttributeValue[iAttributeValueCount] = iData[iCol][iRow];
            }
         }

         double fAttributeEntropySum = 0.0D;

         for(i = 1; i <= iAttributeValueCount; ++i) {
            int iAttributeValueFreq = 0;

            int j;
            for(j = iFirstClass; j <= iLastClass; ++j) {
               iAttributeValueClassCount[j] = 0;
            }

            for(iRow = 1; iRow <= iDataCount; ++iRow) {
               if (iAttributeValue[i] == iData[iCol][iRow]) {
                  ++iAttributeValueClassCount[iData[iClassAttribute][iRow]];
                  ++iAttributeValueFreq;
               }
            }

            double fAttributeEntropy = 0.0D;

            for(j = iFirstClass; j <= iLastClass; ++j) {
               double p = (double)iAttributeValueClassCount[j] / (double)iAttributeValueFreq;
               if (p > 0.0D) {
                  fAttributeEntropy -= p * Math.log(p) / Math.log(2.0D);
               }
            }

            fAttributeEntropySum += fAttributeEntropy * (double)iAttributeValueFreq / (double)iDataCount;
         }

         fColIG[iCol] = fOverallEntropy - fAttributeEntropySum;
      }

   }

   /**
    * 根据数据计算类和信息熵
    * @param iData 存放数据的二维数组
    * @param iAttributeCount 属性的行数
    * @param iDataCount 数据的行数
    * @param iClass 传入的大小为iLastClass+1的数组
    * @param iFirstClass firstClass的值
    * @param iLastClass lastClass的值
    * @return 总体信息熵
    */
   private static double calculateClassesAndEntropyOfData(int[][] iData, int iAttributeCount, int iDataCount, int[] iClass, int iFirstClass, int iLastClass) {
      double fOverallEntropy = 0.0D;

      int i;
      for(i = 1; i <= iDataCount; ++i) {
         ++iClass[iData[iAttributeCount][i]];
      }

      for(i = iFirstClass; i <= iLastClass; ++i) {
         double p = (double)iClass[i] / (double)iDataCount;
         if (p > 0.0D) {
            fOverallEntropy -= p * Math.log(p) / Math.log(2.0D);
         }
      }

      return fOverallEntropy;
   }

   /**
    * 找到数据数组iData的第iAttributeCount行中最小的值
    * @param iData 存数据的数组
    * @param iDataCount 数据的行数
    * @param iAttributeCount 属性的行数
    * @return 数据数组iData的第iAttributeCount行中最小的值
    */
   private static int findFirstClassInData(int[][] iData, int iDataCount, int iAttributeCount) {
      int iFirstClass = 999999;

      for(int i = 1; i <= iDataCount; ++i) {
         if (iData[iAttributeCount][i] < iFirstClass) {
            iFirstClass = iData[iAttributeCount][i];
         }
      }

      return iFirstClass;
   }

   /**
    * 找到数据数组iData的第iAttributeCount行中最大的值
    * @param iData 存数据的二维数组
    * @param iDataCount 数据的行数
    * @param iAttributeCount 属性的行数
    * @return 数据数组iData的第iAttributeCount行中最大的值
    */
   private static int findLastClassInData(int[][] iData, int iDataCount, int iAttributeCount) {
      int iLastClass = 0;

      for(int i = 1; i <= iDataCount; ++i) {
         if (iData[iAttributeCount][i] > iLastClass) {
            iLastClass = iData[iAttributeCount][i];
         }
      }

      return iLastClass;
   }

   /**
    * 将多个输入的arff文件转化为对应的文本文件
    * @param sArffIn 输入的arff文件文件名的数组
    * @param iArffInCount arff文件的数量
    * @param sTextOut 输出的文本文件文件名的数组
    */
   public static void convertArffToTextMultiple(String[] sArffIn, int iArffInCount, String[] sTextOut) {
      for(int i = 0; i < iArffInCount; ++i) {
         sTextOut[i] = FileOps.s_ChopFileNameExtension(sArffIn[i]) + " out.txt";
         convertArffToText(sArffIn[i], sTextOut[i]);
      }

   }

   /**
    * 将arff文件转化为文本文件
    * @param sArffIn 输入的arff文件文件名
    * @param sTextOut 输出的文本文件文件名
    */
   public static void convertArffToText(String sArffIn, String sTextOut) {
      int[] iAttData = countAttributesAndDataInArff(sArffIn);
      int iAttributeCount = iAttData[0];
      int iDataCount = iAttData[1];
      int[][] iData = new int[iAttributeCount + 1][iDataCount + 1];
      String[] sAttributes = new String[iAttributeCount + 1];
      readArffAttributesAndData(sArffIn, iAttributeCount, iDataCount, sAttributes, iData);
      writeArffAttributesAndDataToText(sAttributes, iData, iAttributeCount, iDataCount, sTextOut);
   }

   /**
    * 对多个输入的arff文件分别选取信息增益值较高的指定数量的属性生成对应的新的arff文件
    * @param sArffIn 输入的arff文件文件名的数组
    * @param iArffInCount 输入的arff文件的数量
    * @param iTopNAttributes 选取属性的数量
    * @param sArffOut 存储输出文件文件名的数组
    */
   public static void makeArffsWithTopNAttributes(String[] sArffIn, int iArffInCount, int iTopNAttributes, String[] sArffOut) {
      for(int i = 0; i < iArffInCount; ++i) {
         sArffOut[i] = FileOps.s_ChopFileNameExtension(sArffIn[i]) + " " + iTopNAttributes + ".arff";
         makeArffWithTopNAttributes(sArffIn[i], iTopNAttributes, sArffOut[i]);
      }

   }

   /**
    * 选取信息增益值较高的指定数量的属性生成arff文件
    * @param sArffIn 输入的arff文件的文件名
    * @param iTopNAttributes 选取的属性数量
    * @param sArffOut 输出文件的文件名
    */
   public static void makeArffWithTopNAttributes(String sArffIn, int iTopNAttributes, String sArffOut) {
      int[] iAttData = countAttributesAndDataInArff(sArffIn);
      int iAttributeCount = iAttData[0];
      int iDataCount = iAttData[1];

      try {
         System.out.println("AttributeSelection: Attributes " + iAttributeCount + " data " + iDataCount + " attribute x data " + Long.toString((long)(iAttributeCount + 1) * (long)(iAttributeCount + 1)));
         int[][] iData = new int[iAttributeCount + 1][iDataCount + 1];
         double[] fColIG = new double[iAttributeCount + 1];
         boolean[] bUseCol = new boolean[iAttributeCount + 1];
         String[] sAttributes = new String[iAttributeCount + 1];
         String sHeader = readArffAttributesAndData(sArffIn, iAttributeCount, iDataCount, sAttributes, iData);
         calculateInformationGainOfData(iData, iAttributeCount, iDataCount, fColIG);
         selectTopNAttributes(fColIG, iAttributeCount, iTopNAttributes, bUseCol);
         printInformationGainValues(fColIG, sAttributes, iAttributeCount, sArffOut + "_IG.txt");
         writeArffAttributesAndData(sHeader, sAttributes, iData, iAttributeCount, iDataCount, bUseCol, sArffOut);
      } catch (Exception var11) {
         System.out.println("makeArffWithTopNAttributes error - probably insufficient to create attribute x data array");
         System.out.println("attribute " + iAttributeCount + " data " + iDataCount + " attribute x data " + Integer.toString((iAttributeCount + 1) * (iAttributeCount + 1)));
         var11.printStackTrace();
         System.exit(0);
      }

   }

   /**
    * 计算输入的arff文件中属性的行数和data的行数
    * @param sArffIn 输入的arff文件的文件名
    * @return 一个包含属性行数和data行数的大小为2的数组
    */
   private static int[] countAttributesAndDataInArff(String sArffIn) {
      int iAttCount = 0;
      int iDataCount = 0;

      try {
         BufferedReader rArff = new BufferedReader(new InputStreamReader(new FileInputStream(sArffIn)));
         String sLine = "";
         if (rArff.ready()) {
            sLine = rArff.readLine();
         }

         for(; rArff.ready() && sLine.indexOf("@data") != 0; sLine = rArff.readLine()) {
            if (sLine.length() > 0 && sLine.indexOf("@attribute ") == 0) {
               ++iAttCount;
            }
         }

         iDataCount = 0;

         while(rArff.ready()) {
            sLine = rArff.readLine();
            if (sLine.length() > 0) {
               ++iDataCount;
            }
         }

         rArff.close();
      } catch (Exception var5) {
         System.out.println("[countAttributesAndDataInArff]Error reading file " + sArffIn);
         var5.printStackTrace();
      }

      int[] iAttData = new int[]{iAttCount, iDataCount};
      return iAttData;
   }

   /**
    * 将输入的arff文件中的属性读入sAttributes，数据读入iData
    * @param sArffIn 输入的arff文件的文件名
    * @param iAttributeCount 属性的行数
    * @param iDataCount 数据的行数
    * @param sAttributes 存属性的字符串数组
    * @param iData 存数据的二维数组
    * @return 如果文件打不开或者有异常则返回arff文件的头部
    */
   private static String readArffAttributesAndData(String sArffIn, int iAttributeCount, int iDataCount, String[] sAttributes, int[][] iData) {
      String sHeader = "";
      String sLine = "";
      int iAtt = 0;
      boolean var10 = false;

      try {
         BufferedReader rArff = new BufferedReader(new InputStreamReader(new FileInputStream(sArffIn)));
         if (rArff.ready()) {
            sLine = rArff.readLine();
         }

         for(; rArff.ready() && sLine.indexOf("@data") != 0; sLine = rArff.readLine()) {
            if (sLine.length() > 0 && sLine.charAt(0) != "%".charAt(0)) {
               if (sLine.indexOf("@relation ") == 0) {
                  sAttributes[0] = sLine;
               } else {
                  ++iAtt;
                  sAttributes[iAtt] = sLine;
               }
            } else {
               sHeader = sHeader + sLine + "\n";
            }
         }

         iDataCount = 0;

         while(true) {
            String[] sData;
            do {
               while(true) {
                  do {
                     if (!rArff.ready()) {
                        rArff.close();
                        return sHeader;
                     }

                     sLine = rArff.readLine();
                  } while(sLine.length() <= 1);

                  ++iDataCount;
                  if (sLine.indexOf("{") >= 0) {
                     for(iAtt = 1; iAtt <= iAttributeCount; ++iAtt) {
                        iData[iAtt][iDataCount] = 0;
                     }
                     break;
                  }

                  sData = sLine.split(",");

                  for(iAtt = 1; iAtt <= iAttributeCount; ++iAtt) {
                     iData[iAtt][iDataCount] = Integer.parseInt(sData[iAtt - 1].trim());
                  }
               }
            } while(sLine.length() <= 4);

            sData = sLine.substring(1, sLine.length() - 1).split(",");

            for(int iPair = 0; iPair < sData.length; ++iPair) {
               String[] sIDValue = sData[iPair].trim().split(" ");
               iData[Integer.parseInt(sIDValue[0]) + 1][iDataCount] = Integer.parseInt(sIDValue[1]);
            }
         }
      } catch (Exception var12) {
         System.out.println("[readArffAttributesAndData]Error reading file " + sArffIn);
         var12.printStackTrace();
         return sHeader;
      }
   }

   /**
    * 将arff文件的要使用的属性以及对应数据写入指定输出文件
    * @param sHeader 头部
    * @param sAttribute 存储属性的数组
    * @param iData 存储数据的数组
    * @param iAttributeCount 属性数
    * @param iDataCount 数据数
    * @param bUseCol 每一列是否使用
    * @param sArffOut 指定的输出文件的文件名
    */
   private static void writeArffAttributesAndData(String sHeader, String[] sAttribute, int[][] iData, int iAttributeCount, int iDataCount, boolean[] bUseCol, String sArffOut) {
      try {
         BufferedWriter wWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(sArffOut)));
         wWriter.write(sHeader);

         int iCol;
         for(iCol = 0; iCol <= iAttributeCount; ++iCol) {
            if (bUseCol[iCol]) {
               wWriter.write(sAttribute[iCol] + "\n");
            }
         }

         wWriter.write("@data\n");

         for(int iDat = 1; iDat <= iDataCount; ++iDat) {
            if (bgSaveArffAsCondensed) {
               wWriter.write("{");
               int iColUsed = 0;

               for(iCol = 1; iCol < iAttributeCount; ++iCol) {
                  if (bUseCol[iCol]) {
                     ++iColUsed;
                     if (iData[iCol][iDat] > 0) {
                        wWriter.write(iColUsed - 1 + " " + iData[iCol][iDat] + ",");
                     }
                  }
               }

               wWriter.write(iColUsed + " " + iData[iAttributeCount][iDat] + "}\n");
            } else {
               for(iCol = 1; iCol < iAttributeCount; ++iCol) {
                  if (bUseCol[iCol]) {
                     wWriter.write(iData[iCol][iDat] + ",");
                  }
               }

               wWriter.write(iData[iAttributeCount][iDat] + "\n");
            }
         }

         wWriter.close();
      } catch (Exception var11) {
         System.out.println("[writeArffAttributesAndData]Error writing file " + sArffOut);
         var11.printStackTrace();
      }

   }

   /**
    * 将arff文件的属性和数据写入文本文件
    * @param sAttribute 存属性的数组
    * @param iData 存数据的数组
    * @param iAttributeCount 属性数
    * @param iDataCount 数据数量
    * @param sTextOut 输出的文本文件的文件名
    */
   private static void writeArffAttributesAndDataToText(String[] sAttribute, int[][] iData, int iAttributeCount, int iDataCount, String sTextOut) {
      int iCol;
      for(iCol = 1; iCol <= iAttributeCount; ++iCol) {
         String[] sData = sAttribute[iCol].split(" ");
         sAttribute[iCol] = sData[1];
         int iPos = sAttribute[iCol].indexOf("_");
         if (iPos > 0) {
            sAttribute[iCol] = sAttribute[iCol].substring(iPos + 1);
         }

         iPos = sAttribute[iCol].indexOf("_pc");
         if (iPos >= 0) {
            sAttribute[iCol] = sAttribute[iCol].replace("_pc", "%");
         }

         iPos = sAttribute[iCol].indexOf("%2C");
         if (iPos >= 0) {
            sAttribute[iCol] = sAttribute[iCol].replace("%2C", ",");
         }

         iPos = sAttribute[iCol].indexOf("%28");
         if (iPos >= 0) {
            sAttribute[iCol] = sAttribute[iCol].replace("%28", "(");
         }

         iPos = sAttribute[iCol].indexOf("%29");
         if (iPos >= 0) {
            sAttribute[iCol] = sAttribute[iCol].replace("%29", ")");
         }

         iPos = sAttribute[iCol].indexOf("%3F");
         if (iPos >= 0) {
            sAttribute[iCol] = sAttribute[iCol].replace("%3F", "?");
         }

         iPos = sAttribute[iCol].indexOf("%21");
         if (iPos >= 0) {
            sAttribute[iCol] = sAttribute[iCol].replace("%21", "!");
         }

         iPos = sAttribute[iCol].indexOf("%25");
         if (iPos >= 0) {
            sAttribute[iCol] = sAttribute[iCol].replace("%25", "%");
         }

         iPos = sAttribute[iCol].indexOf("%26");
         if (iPos >= 0) {
            sAttribute[iCol] = sAttribute[iCol].replace("%26", "&");
         }

         iPos = sAttribute[iCol].indexOf("%27");
         if (iPos >= 0) {
            sAttribute[iCol] = sAttribute[iCol].replace("%27", "'");
         }

         iPos = sAttribute[iCol].indexOf("%2F");
         if (iPos >= 0) {
            sAttribute[iCol] = sAttribute[iCol].replace("%2F", "/");
         }

         iPos = sAttribute[iCol].indexOf("%3A");
         if (iPos >= 0) {
            sAttribute[iCol] = sAttribute[iCol].replace("%3A", ":");
         }

         iPos = sAttribute[iCol].indexOf("%3B");
         if (iPos >= 0) {
            sAttribute[iCol] = sAttribute[iCol].replace("%3B", ";");
         }

         iPos = sAttribute[iCol].indexOf("+");
         if (iPos > 0) {
            sAttribute[iCol] = sAttribute[iCol].replace("+", "_");
         }
      }

      try {
         BufferedWriter wWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(sTextOut)));
         wWriter.write(sAttribute[iAttributeCount] + "\tText\n");

         for(int iDat = 1; iDat <= iDataCount; ++iDat) {
            wWriter.write(iData[iAttributeCount][iDat] + "\t");

            for(iCol = 1; iCol < iAttributeCount; ++iCol) {
               if (iData[iCol][iDat] > 1) {
                  wWriter.write(sAttribute[iCol] + "[" + iData[iCol][iDat] + "] ");
               } else if (iData[iCol][iDat] == 1) {
                  wWriter.write(sAttribute[iCol] + " ");
               }
            }

            wWriter.write("\r\n");
         }

         wWriter.close();
      } catch (Exception var10) {
         System.out.println("[writeArffAttributesAndDataToText]Error writing file " + sTextOut);
         var10.printStackTrace();
      }

   }
}
