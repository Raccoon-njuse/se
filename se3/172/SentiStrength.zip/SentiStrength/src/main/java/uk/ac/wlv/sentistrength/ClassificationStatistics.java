// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 
// Source File Name:   ClassificationStatistics.java

package uk.ac.wlv.sentistrength;

import java.io.PrintStream;

/**
 * ClassificationStatistics是一个用于计算分类任务相关统计量的类。
 *
 * @author Mike Thelwall
 * @version 1.0.0
 */
public class ClassificationStatistics
{

    /**
     * 分类统计数据
     */
    public ClassificationStatistics()
    {
    }

    /**

     计算两个数组之间的绝对值相关系数。

     @param iCorrect 一个int类型数组，代表真实分类结果。

     @param iPredicted 一个int类型数组，代表预测分类结果。

     @param iCount int类型，代表数据数量。

     @return double类型的绝对值相关系数。
     */
    public static double correlationAbs(int iCorrect[], int iPredicted[], int iCount)
    {
        double fMeanC = 0.0D;
        double fMeanP = 0.0D;
        double fProdCP = 0.0D;
        double fSumCSq = 0.0D;
        double fSumPSq = 0.0D;
        for(int iRow = 1; iRow <= iCount; iRow++)
        {
            fMeanC += Math.abs(iCorrect[iRow]);
            fMeanP += Math.abs(iPredicted[iRow]);
        }

        fMeanC /= iCount;
        fMeanP /= iCount;
        for(int iRow = 1; iRow <= iCount; iRow++)
        {
            fProdCP += ((double)Math.abs(iCorrect[iRow]) - fMeanC) * ((double)Math.abs(iPredicted[iRow]) - fMeanP);
            fSumPSq += Math.pow((double)Math.abs(iPredicted[iRow]) - fMeanP, 2D);
            fSumCSq += Math.pow((double)Math.abs(iCorrect[iRow]) - fMeanC, 2D);
        }

        return fProdCP / (Math.sqrt(fSumPSq) * Math.sqrt(fSumCSq));
    }

    /**

     计算两个数组之间的相关系数。

     @param iCorrect 一个int类型数组，代表真实分类结果。

     @param iPredicted 一个int类型数组，代表预测分类结果。

     @param iCount int类型，代表数据数量。

     @return double类型的相关系数。
     */
    public static double correlation(int iCorrect[], int iPredicted[], int iCount)
    {
        double fMeanC = 0.0D;
        double fMeanP = 0.0D;
        double fProdCP = 0.0D;
        double fSumCSq = 0.0D;
        double fSumPSq = 0.0D;
        for(int iRow = 1; iRow <= iCount; iRow++)
        {
            fMeanC += iCorrect[iRow];
            fMeanP += iPredicted[iRow];
        }

        fMeanC /= iCount;
        fMeanP /= iCount;
        for(int iRow = 1; iRow <= iCount; iRow++)
        {
            fProdCP += ((double)iCorrect[iRow] - fMeanC) * ((double)iPredicted[iRow] - fMeanP);
            fSumPSq += Math.pow((double)iPredicted[iRow] - fMeanP, 2D);
            fSumCSq += Math.pow((double)iCorrect[iRow] - fMeanC, 2D);
        }

        return fProdCP / (Math.sqrt(fSumPSq) * Math.sqrt(fSumCSq));
    }

    /**

     生成三元或二元混淆表

     @param iTrinaryEstimate 三元估计数组

     @param iTrinaryCorrect 三元正确值数组

     @param iDataCount 数据量

     @param estCorr 预测-正确矩阵
     */
    public static void TrinaryOrBinaryConfusionTable(int iTrinaryEstimate[], int iTrinaryCorrect[], int iDataCount, int estCorr[][])
    {
        for(int i = 0; i <= 2; i++)
        {
            for(int j = 0; j <= 2; j++)
                estCorr[i][j] = 0;

        }

        for(int i = 1; i <= iDataCount; i++)
            if(iTrinaryEstimate[i] > -2 && iTrinaryEstimate[i] < 2 && iTrinaryCorrect[i] > -2 && iTrinaryCorrect[i] < 2)
                estCorr[iTrinaryEstimate[i] + 1][iTrinaryCorrect[i] + 1]++;
            else
                System.out.println((new StringBuilder("Estimate or correct value ")).append(i).append(" out of range -1 to +1 (data count may be wrong): ").append(iTrinaryEstimate[i]).append(" ").append(iTrinaryCorrect[i]).toString());

    }

    /**

     计算两个数组之间的相关性

     @param iCorrect 包含正确值的数组

     @param iPredicted 包含预测值的数组

     @param bSelected 是否选择此数据点

     @param bInvert 是否反转选择

     @param iCount 数组的长度

     @return 返回两个数组之间的绝对相关性
     */
    public static double correlationAbs(int iCorrect[], int iPredicted[], boolean bSelected[], boolean bInvert, int iCount)
    {
        double fMeanC = 0.0D;
        double fMeanP = 0.0D;
        double fProdCP = 0.0D;
        double fSumCSq = 0.0D;
        double fSumPSq = 0.0D;
        int iDataCount = 0;
        for(int iRow = 1; iRow <= iCount; iRow++)
            if(bSelected[iRow] && !bInvert || !bSelected[iRow] && bInvert)
            {
                fMeanC += Math.abs(iCorrect[iRow]);
                fMeanP += Math.abs(iPredicted[iRow]);
                iDataCount++;
            }

        fMeanC /= iDataCount;
        fMeanP /= iDataCount;
        for(int iRow = 1; iRow <= iCount; iRow++)
            if(bSelected[iRow] && !bInvert || !bSelected[iRow] && bInvert)
            {
                fProdCP += ((double)Math.abs(iCorrect[iRow]) - fMeanC) * ((double)Math.abs(iPredicted[iRow]) - fMeanP);
                fSumPSq += Math.pow((double)Math.abs(iPredicted[iRow]) - fMeanP, 2D);
                fSumCSq += Math.pow((double)Math.abs(iCorrect[iRow]) - fMeanC, 2D);
            }

        return fProdCP / (Math.sqrt(fSumPSq) * Math.sqrt(fSumCSq));
    }

    /**

     计算预测正确的个数

     @param iCorrect 包含正确值的数组

     @param iPredicted 包含预测值的数组

     @param iCount 数组的长度

     @param bChangeSignOfOneArray 是否改变一个数组的符号

     @return 返回预测正确的个数
     */
    public static int accuracy(int iCorrect[], int iPredicted[], int iCount, boolean bChangeSignOfOneArray)
    {
        int iCorrectCount = 0;
        if(bChangeSignOfOneArray)
        {
            for(int iRow = 1; iRow <= iCount; iRow++)
                if(iCorrect[iRow] == -iPredicted[iRow])
                    iCorrectCount++;

        } else
        {
            for(int iRow = 1; iRow <= iCount; iRow++)
                if(iCorrect[iRow] == iPredicted[iRow])
                    iCorrectCount++;

        }
        return iCorrectCount;
    }

    /**

     accuracy方法用于计算在指定条件下的正确预测次数

     @param iCorrect 包含正确值的数组

     @param iPredicted 包含预测值的数组

     @param bSelected 每一行是否被选中

     @param bInvert 是否反转选择的行

     @param iCount 数组中元素的个数

     @return 返回在给定条件下的正确预测次数
     */
    public static int accuracy(int iCorrect[], int iPredicted[], boolean bSelected[], boolean bInvert, int iCount)
    {
        int iCorrectCount = 0;
        for(int iRow = 1; iRow <= iCount; iRow++)
            if((bSelected[iRow] && !bInvert || !bSelected[iRow] && bInvert) && iCorrect[iRow] == iPredicted[iRow])
                iCorrectCount++;

        return iCorrectCount;
    }

    /**

     accuracyWithin1方法用于计算在指定条件下的正确预测次数，满足其他条件时，预测值与正确值之间的绝对值的差不超过1即算预测正确

     @param iCorrect 包含正确值的数组

     @param iPredicted 包含预测值的数组

     @param bSelected 每一行是否被选用

     @param bInvert 是否反转选择的行

     @param iCount 数组中元素的个数

     @return 返回在给定条件下的正确预测次数
     */
    public static int accuracyWithin1(int iCorrect[], int iPredicted[], boolean bSelected[], boolean bInvert, int iCount)
    {
        int iCorrectCount = 0;
        for(int iRow = 1; iRow <= iCount; iRow++)
            if((bSelected[iRow] && !bInvert || !bSelected[iRow] && bInvert) && Math.abs(iCorrect[iRow] - iPredicted[iRow]) <= 1)
                iCorrectCount++;

        return iCorrectCount;
    }

    /**

     accuracyWithin1方法用于计算在指定条件下的正确预测次数，其中满足其他条件时预测值与正确值之间的绝对值的差不超过1即算预测正确

     @param iCorrect 包含正确值的数组

     @param iPredicted 包含预测值的数组

     @param iCount 数组中元素的个数

     @param bChangeSignOfOneArray 是否更改其中一个数组中的元素的符号

     @return 返回在给定条件下的正确预测次数
     */
    public static int accuracyWithin1(int iCorrect[], int iPredicted[], int iCount, boolean bChangeSignOfOneArray)
    {
        int iCorrectCount = 0;
        if(bChangeSignOfOneArray)
        {
            for(int iRow = 1; iRow <= iCount; iRow++)
                if(Math.abs(iCorrect[iRow] + iPredicted[iRow]) <= 1)
                    iCorrectCount++;

        } else
        {
            for(int iRow = 1; iRow <= iCount; iRow++)
                if(Math.abs(iCorrect[iRow] - iPredicted[iRow]) <= 1)
                    iCorrectCount++;

        }
        return iCorrectCount;
    }

    /**

     计算绝对平均误差百分比误差，不除以正确值

     @param iCorrect 一个包含正确值的整数数组

     @param iPredicted 一个包含预测值的整数数组

     @param bSelected 一个布尔值数组，用于选择哪些值进行计算

     @param bInvert 布尔值，用于决定是否反转选择

     @param iCount 数组的大小

     @return 绝对平均百分比误差
     */
    public static double absoluteMeanPercentageErrorNoDivision(int iCorrect[], int iPredicted[], boolean bSelected[], boolean bInvert, int iCount)
    {
        int iDataCount = 0;
        double fAMeanPE = 0.0D;
        for(int iRow = 1; iRow <= iCount; iRow++)
            if(bSelected[iRow] && !bInvert || !bSelected[iRow] && bInvert)
            {
                fAMeanPE += Math.abs(iPredicted[iRow] - iCorrect[iRow]);
                iDataCount++;
            }

        return fAMeanPE / (double)iDataCount;
    }

    /**

     计算绝对平均百分比误差，除以正确值

     @param iCorrect 一个包含正确值的整数数组

     @param iPredicted 一个包含预测值的整数数组

     @param bSelected 一个布尔值数组，用于选择哪些值进行计算

     @param bInvert 布尔值，用于决定是否反转选择

     @param iCount 数组的大小

     @return 绝对平均百分比误差
     */
    public static double absoluteMeanPercentageError(int iCorrect[], int iPredicted[], boolean bSelected[], boolean bInvert, int iCount)
    {
        int iDataCount = 0;
        double fAMeanPE = 0.0D;
        for(int iRow = 1; iRow <= iCount; iRow++)
            if(bSelected[iRow] && !bInvert || !bSelected[iRow] && bInvert)
            {
                fAMeanPE += Math.abs((double)(iPredicted[iRow] - iCorrect[iRow]) / (double)iCorrect[iRow]);
                iDataCount++;
            }

        return fAMeanPE / (double)iDataCount;
    }

    /**

     计算绝对平均百分比误差，不除以正确值
     @param iCorrect 一个包含正确值的整数数组
     @param iPredicted 一个包含预测值的整数数组
     @param iCount 数组的大小
     @param bChangeSignOfOneArray 是否更改数组的符号，即是预测值加正确值还是预测值减正确值
     @return 绝对平均百分比误差
     */
    public static double absoluteMeanPercentageErrorNoDivision(int iCorrect[], int iPredicted[], int iCount, boolean bChangeSignOfOneArray)
    {
        double fAMeanPE = 0.0D;
        if(bChangeSignOfOneArray)
        {
            for(int iRow = 1; iRow <= iCount; iRow++)
                fAMeanPE += Math.abs(iPredicted[iRow] + iCorrect[iRow]);

        } else
        {
            for(int iRow = 1; iRow <= iCount; iRow++)
                fAMeanPE += Math.abs(iPredicted[iRow] - iCorrect[iRow]);

        }
        return fAMeanPE / (double)iCount;
    }

    /**

     计算基线准确率多数类别的比例

     @param iCorrect 正确类别数组

     @param iCount 数组大小

     @return 最大类比例
     */
    public static double baselineAccuracyMajorityClassProportion(int iCorrect[], int iCount)
    {
        if(iCount == 0)
            return 0.0D;
        int iClassCount[] = new int[100];
        int iMinClass = iCorrect[1];
        int iMaxClass = iCorrect[1];
        for(int i = 2; i <= iCount; i++)
        {
            if(iCorrect[i] < iMinClass)
                iMinClass = iCorrect[i];
            if(iCorrect[i] > iMaxClass)
                iMaxClass = iCorrect[i];
        }

        if(iMaxClass - iMinClass >= 100)
            return 0.0D;
        for(int i = 0; i <= iMaxClass - iMinClass; i++)
            iClassCount[i] = 0;

        for(int i = 1; i <= iCount; i++)
            iClassCount[iCorrect[i] - iMinClass]++;

        int iMaxClassCount = 0;
        for(int i = 0; i <= iMaxClass - iMinClass; i++)
            if(iClassCount[i] > iMaxClassCount)
                iMaxClassCount = iClassCount[i];

        return (double)iMaxClassCount / (double)iCount;
    }

    /**

     根据基线精度预测最大类

     @param iCorrect 正确类别数组

     @param iPredict 预测类别数组

     @param iCount 数组大小

     @param bChangeSign 是否改变符号
     */
    public static void baselineAccuracyMakeLargestClassPrediction(int iCorrect[], int iPredict[], int iCount, boolean bChangeSign)
    {
        if(iCount == 0)
            return;
        int iClassCount[] = new int[100];
        int iMinClass = iCorrect[1];
        int iMaxClass = iCorrect[1];
        for(int i = 2; i <= iCount; i++)
        {
            if(iCorrect[i] < iMinClass)
                iMinClass = iCorrect[i];
            if(iCorrect[i] > iMaxClass)
                iMaxClass = iCorrect[i];
        }

        if(iMaxClass - iMinClass >= 100)
            return;
        for(int i = 0; i <= iMaxClass - iMinClass; i++)
            iClassCount[i] = 0;

        for(int i = 1; i <= iCount; i++)
            iClassCount[iCorrect[i] - iMinClass]++;

        int iMaxClassCount = 0;
        int iLargestClass = 0;
        for(int i = 0; i <= iMaxClass - iMinClass; i++)
            if(iClassCount[i] > iMaxClassCount)
            {
                iMaxClassCount = iClassCount[i];
                iLargestClass = i + iMinClass;
            }

        if(bChangeSign)
        {
            for(int i = 1; i <= iCount; i++)
                iPredict[i] = -iLargestClass;

        } else
        {
            for(int i = 1; i <= iCount; i++)
                iPredict[i] = iLargestClass;

        }
    }

    /**

     计算绝对平均百分比误差

     @param iCorrect 正确值的数组

     @param iPredicted 预测值的数组

     @param iCount 数组长度

     @param bChangeSignOfOneArray 是否改变其中一个数组的符号

     @return 绝对平均百分比误差
     */
    public static double absoluteMeanPercentageError(int iCorrect[], int iPredicted[], int iCount, boolean bChangeSignOfOneArray)
{
    double fAMeanPE = 0.0D;
    if(bChangeSignOfOneArray)
    {
        for(int iRow = 1; iRow <= iCount; iRow++)
            fAMeanPE += Math.abs((double)(iPredicted[iRow] + iCorrect[iRow]) / (double)iCorrect[iRow]);

    } else
    {
        for(int iRow = 1; iRow <= iCount; iRow++)
            fAMeanPE += Math.abs((double)(iPredicted[iRow] - iCorrect[iRow]) / (double)iCorrect[iRow]);

    }
    return fAMeanPE / (double)iCount;
}
}
