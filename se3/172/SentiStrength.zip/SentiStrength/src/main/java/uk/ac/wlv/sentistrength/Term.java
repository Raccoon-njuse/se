package uk.ac.wlv.sentistrength;

/**
 * Term是文本中的元素，类型包括单词、标点符号或表情符号
 * @author Mike Thelwall
 * @version 1.0.0
 */
public class Term {
   /**
    * 代表单词类型的常量
    */
   private final int igContentTypeWord = 1;
   /**
    * 代表标点符号类型的常量
    */
   private final int igContentTypePunctuation = 2;
   /**
    * 代表表情符号类型的常量
    */
   private final int igContentTypeEmoticon = 3;
   /**
    * 该Term对象内容类型，值为1则是单词，2则是标点符号，3则是表情符号
    */
   private int igContentType = 0;
   /**
    * 原始单词
    */
   private String sgOriginalWord = "";
   /**
    * 小写形式的单词
    */
   private String sgLCaseWord = "";
   /**
    * 翻译后的单词
    */
   private String sgTranslatedWord = "";
   /**
    * 单词强调，字符串类型
    */
   private String sgWordEmphasis = "";
   /**
    * 是否为否定含义单词
    */
   private boolean bgNegatingWord = false;
   /**
    * 有无完成单词是否为否定含义的判断
    */
   private boolean bgNegatingWordCalculated = false;
   /**
    * 单词的情绪ID
    */
   private int igWordSentimentID = 0;
   /**
    * 是否完成了单词的情绪ID的计算
    */
   private boolean bgWordSentimentIDCalculated = false;
   /**
    * 是否名词正确
    */
   private boolean bgProperNoun = false;
   /**
    * 是否完成名词正确与否的判断
    */
   private boolean bgProperNounCalculated = false;
   /**
    * 标点符号，字符串类型
    */
   private String sgPunctuation = "";
   /**
    * 标点符号强调，字符串类型
    */
   private String sgPunctuationEmphasis = "";
   /**
    * 表情符号，字符串类型
    */
   private String sgEmoticon = "";
   /**
    * 表情符号强度，整数类型
    */
   int igEmoticonStrength = 0;
   /**
    * 加强（booster）单词分数
    */
   private int igBoosterWordScore = 999;
   /**
    * 分级资源，包含了多种类型的词语列表、符号列表等的全部信息，提供查询功能
    */
   private ClassificationResources resources;
   /**
    * 分级选项
    */
   private ClassificationOptions options;
   /**
    * 文本是否全部大写
    */
   private boolean bgAllCapitals = false;
   /**
    * 有无完成单词是否为全部大写的判断
    */
   private boolean bgAllCaptialsCalculated = false;
   /**
    * 是否已经覆写情绪分数
    */
   private boolean bgOverrideSentimentScore = false;
   /**
    * 覆写的情绪分数
    */
   private int igOverrideSentimentScore = 0;

   /**
    * 提取文本中下一个单词/标点符号/表情符号，将提取出来的单词/标点符号/表情符号的信息进行提取并填入Term相应属性
    * @param sWordAndPunctuation 用于提取下一项的文本
    * @param classResources 分类资源，包含了多种类型的词语列表、符号列表等的全部信息，提供查询功能
    * @param classOptions 分类选项
    * @return 返回-1表示提取的下一项是表情符号，否则返回下一个单词/标点符号的结束字符在sWordAndPunctuation中的位置
    */
   public int extractNextWordOrPunctuationOrEmoticon(String sWordAndPunctuation, ClassificationResources classResources, ClassificationOptions classOptions) {
      int iWordCharOrAppostrophe = 1;
      int iPunctuation =1;
      int iPos = 0;
      int iLastCharType = 0;
      String sChar = "";
      this.resources = classResources;
      this.options = classOptions;
      int iTextLength = sWordAndPunctuation.length();
      if (this.codeEmoticon(sWordAndPunctuation)) {
         return -1;
      }
      else {
         for(; iPos < iTextLength; ++iPos) {
            sChar = sWordAndPunctuation.substring(iPos, iPos + 1);
            if (!Character.isLetterOrDigit(sWordAndPunctuation.charAt(iPos))
                    && (this.options.bgAlwaysSplitWordsAtApostrophes
                    || !sChar.equals("'") || iPos <= 0 || iPos >= iTextLength - 1
                    || !Character.isLetter(sWordAndPunctuation.charAt(iPos + 1)))
                    && !sChar.equals("$") && !sChar.equals("£")
                    && !sChar.equals("@") && !sChar.equals("_")) {
               if (iLastCharType == 1) {
                  this.codeWord(sWordAndPunctuation.substring(0, iPos));
                  return iPos;
               }

               iLastCharType = 2;
            }
            else {
               if (iLastCharType == 2) {
                  this.codePunctuation(sWordAndPunctuation.substring(0, iPos));
                  return iPos;
               }

               iLastCharType = 1;
            }
         }

         switch(iLastCharType) {
         case 1:
            this.codeWord(sWordAndPunctuation);
            break;
         case 2:
            this.codePunctuation(sWordAndPunctuation);
         }

         return -1;
      }
   }

   /**
    * 对文本打标签，获取HTML或XML标签形式的文本内容<br>
    * 单词格式：&lt;w equiv=&quot;translatedWord&quot; em=&quot;wordEmphasis&quot;&gt;OriginalWord&lt;/w&gt; <br>
    * 标点格式：&lt;p equiv=&quot;punctuation&quot; em=&quot;punctuationEmphasis&quot;&gt;punctuation + punctuationEmphasis&lt;/p&gt; <br>
    * 表情符号格式：&lt;e em=&quot;+&quot;&gt;emoticon&lt;/e&gt;
    * @return 标签语句
    */
   public String getTag() {
      switch(this.igContentType) {
      case 1:
         if (this.sgWordEmphasis != "") {
            // <w equiv="translatedWord" em="wordEmphasis">originalWord</w>
            return "<w equiv=\"" + this.sgTranslatedWord + "\" em=\"" + this.sgWordEmphasis + "\">" + this.sgOriginalWord + "</w>";
         }

         return "<w>" + this.sgOriginalWord + "</w>";
      case 2:
         if (this.sgPunctuationEmphasis != "") {
            // <p equiv="punctuation" em="punctuationEmphasis">punctuation + punctuationEmphasis</p>
            return "<p equiv=\"" + this.sgPunctuation + "\" em=\"" + this.sgPunctuationEmphasis + "\">" + this.sgPunctuation + this.sgPunctuationEmphasis + "</p>";
         }

         return "<p>" + this.sgPunctuation + "</p>";
      case 3:
         // <e em="+">emoticon</e>
         if (this.igEmoticonStrength == 0) {
            return "<e>" + this.sgEmoticon + "</e>";
         } else {
            if (this.igEmoticonStrength == 1) {
               return "<e em=\"+\">" + this.sgEmoticon + "</e>";
            }

            return "<e em=\"-\">" + this.sgEmoticon + "</e>";
         }
      default:
         return "";
      }
   }

   /**
    * 获取情绪ID
    * @return 情绪ID
    */
   public int getSentimentID() {
      if (!this.bgWordSentimentIDCalculated) {
         this.igWordSentimentID = this.resources.sentimentWords.getSentimentID(this.sgTranslatedWord.toLowerCase());
         this.bgWordSentimentIDCalculated = true;
      }

      return this.igWordSentimentID;
   }

   /**
    * 覆写情绪分数值
    * @param iSentiment 新情绪分数值
    */
   public void setSentimentOverrideValue(int iSentiment) {
      this.bgOverrideSentimentScore = true;
      this.igOverrideSentimentScore = iSentiment;
   }

   /**
    * 获取情绪分数值，如果未计算该值则先进行计算
    * @return 情绪分数值
    */
   public int getSentimentValue() {
      if (this.bgOverrideSentimentScore) {
         return this.igOverrideSentimentScore;
      } else {
         return this.getSentimentID() < 1 ? 0 : this.resources.sentimentWords.getSentiment(this.igWordSentimentID);
      }
   }

   /**
    * 获取单词强调长度
    * @return 单词强调长度
    */
   public int getWordEmphasisLength() {
      return this.sgWordEmphasis.length();
   }

   /**
    * 获取单词强调
    * @return 单词强调
    */
   public String getWordEmphasis() {
      return this.sgWordEmphasis;
   }

   /**
    * 判断是否包含强调
    * @return true表示有单词强调或标点符号强调，false表示无强调
    */
   public boolean containsEmphasis() {
      if (this.igContentType == 1) {
         return this.sgWordEmphasis.length() > 1;
      } else if (this.igContentType == 2) {
         return this.sgPunctuationEmphasis.length() > 1;
      } else {
         return false;
      }
   }

   /**
    * 获取翻译后的单词
    * @return 翻译后的单词字符串
    */
   public String getTranslatedWord() {
      return this.sgTranslatedWord;
   }

   /**
    * 获取翻译后的内容，如果内容类型是标点符号或表情符号则不翻译
    * @return 翻译后的内容字符串
    */
   public String getTranslation() {
      if (this.igContentType == 1) {
         return this.sgTranslatedWord;
      } else if (this.igContentType == 2) {
         return this.sgPunctuation;
      } else {
         return this.igContentType == 3 ? this.sgEmoticon : "";
      }
   }

   /**
    * 获取加强（booster）单词分数
    * @return 加强（booster）单词分数
    */
   public int getBoosterWordScore() {
      if (this.igBoosterWordScore == 999) {
         this.setBoosterWordScore();
      }

      return this.igBoosterWordScore;
   }

   /**
    * 查询原始单词是否全部大写
    * @return 原始单词是否全部大写
    */
   public boolean isAllCapitals() {
      if (!this.bgAllCaptialsCalculated) {
         if (this.sgOriginalWord == this.sgOriginalWord.toUpperCase()) {
            this.bgAllCapitals = true;
         } else {
            this.bgAllCapitals = false;
         }

         this.bgAllCaptialsCalculated = true;
      }

      return this.bgAllCapitals;
   }

   /**
    * 计算并设置加强单词分数值
    */
   public void setBoosterWordScore() {
      this.igBoosterWordScore = this.resources.boosterWords.getBoosterStrength(this.sgTranslatedWord);
   }

   /**
    * 判断是否包含标点符号sPunctuation
    * @param sPunctuation 标点符号字符串
    * @return 该Term内容是否包含标点符号sPunctuation
    */
   public boolean punctuationContains(String sPunctuation) {
      if (this.igContentType != 2) {
         return false;
      } else if (this.sgPunctuation.indexOf(sPunctuation) > -1) {
         return true;
      } else {
         return this.sgPunctuationEmphasis != "" && this.sgPunctuationEmphasis.indexOf(sPunctuation) > -1;
      }
   }

   /**
    * 获取标点符号强调部分的长度
    * @return 标点符号强调部分的长度
    */
   public int getPunctuationEmphasisLength() {
      return this.sgPunctuationEmphasis.length();
   }

   /**
    * 获取表情符号强度
    * @return 表情符号强度
    */
   public int getEmoticonSentimentStrength() {
      return this.igEmoticonStrength;
   }

   /**
    * 获取表情符号
    * @return 表情符号字符串
    */
   public String getEmoticon() {
      return this.sgEmoticon;
   }

   /**
    * 获取翻译过的标点符号
    * @return 标点符号字符串
    */
   public String getTranslatedPunctuation() {
      return this.sgPunctuation;
   }

   /**
    * Term内容是否为单词类型
    * @return 类型是单词则返回true，否则返回false
    */
   public boolean isWord() {
      return this.igContentType == 1;
   }

   /**
    * Term内容是否为标点符号类型
    * @return 类型是标点符号则返回true，否则返回false
    */
   public boolean isPunctuation() {
      return this.igContentType == 2;
   }

   /**
    * 判断名词是否书写正确，即首字母大写并且其余字母小写
    * @return true表示名词正确，false表示名词不正确或内容类型不是单词
    */
   public boolean isProperNoun() {
      if (this.igContentType != 1) {
         return false;
      } else {
         if (!this.bgProperNounCalculated) {
            if (this.sgOriginalWord.length() > 1) {
               String sFirstLetter = this.sgOriginalWord.substring(0, 1);
               if (!sFirstLetter.toLowerCase().equals(sFirstLetter.toUpperCase()) && !this.sgOriginalWord.substring(0, 2).toUpperCase().equals("I'")) {
                  String sWordRemainder = this.sgOriginalWord.substring(1);
                  if (sFirstLetter.equals(sFirstLetter.toUpperCase()) && sWordRemainder.equals(sWordRemainder.toLowerCase())) {
                     this.bgProperNoun = true;
                  }
               }
            }

            this.bgProperNounCalculated = true;
         }

         return this.bgProperNoun;
      }
   }

   /**
    * 内容是否为表情符号类型
    * @return 类型是表情符号则返回true，否则返回false
    */
   public boolean isEmoticon() {
      return this.igContentType == 3;
   }

   /**
    * 获取Term文本内容，文本内容经过翻译并全部小写
    * @return 经过翻译的小写的文本内容
    */
   public String getText() {
      if (this.igContentType == 1) {
         return this.sgTranslatedWord.toLowerCase();
      } else if (this.igContentType == 2) {
         return this.sgPunctuation;
      } else {
         return this.igContentType == 3 ? this.sgEmoticon : "";
      }
   }

   /**
    * 获取Term原始文本
    * @return 原始文本
    */
   public String getOriginalText() {
      if (this.igContentType == 1) {
         return this.sgOriginalWord;
      } else if (this.igContentType == 2) {
         return this.sgPunctuation + this.sgPunctuationEmphasis;
      } else {
         return this.igContentType == 3 ? this.sgEmoticon : "";
      }
   }

   /**
    * 本Term是否为否定单词
    * @return 是否为否定单词
    */
   public boolean isNegatingWord() {
      if (!this.bgNegatingWordCalculated) {
         if (this.sgLCaseWord.length() == 0) {
            this.sgLCaseWord = this.sgTranslatedWord.toLowerCase();
         }

         this.bgNegatingWord = this.resources.negatingWords.negatingWord(this.sgLCaseWord);
         this.bgNegatingWordCalculated = true;
      }

      return this.bgNegatingWord;
   }

   /**
    * 查询字符串是否匹配，即sText和本Term是否相同
    * @param sText 目标字符串
    * @param bConvertToLowerCase 是否将sText转化为小写
    * @return Term单词字符串和sText字符串是否相同
    */
   public boolean matchesString(String sText, boolean bConvertToLowerCase) {
      if (sText.length() != this.sgTranslatedWord.length()) {
         return false;
      } else {
         if (bConvertToLowerCase) {
            if (this.sgLCaseWord.length() == 0) {
               this.sgLCaseWord = this.sgTranslatedWord.toLowerCase();
            }

            if (sText.equals(this.sgLCaseWord)) {
               return true;
            }
         } else if (sText.equals(this.sgTranslatedWord)) {
            return true;
         }

         return false;
      }
   }

   /**
    * 查询字符串sTextWithWildcard和本Term是否匹配，支持字符串使用通配符
    * @param sTextWithWildcard 目标字符串
    * @param bConvertToLowerCase 是否将sText转化为小写
    * @return 结果是否匹配
    */
   public boolean matchesStringWithWildcard(String sTextWithWildcard, boolean bConvertToLowerCase) {
      int iStarPos = sTextWithWildcard.lastIndexOf("*");
      if (iStarPos >= 0 && iStarPos == sTextWithWildcard.length() - 1) {
         sTextWithWildcard = sTextWithWildcard.substring(0, iStarPos);
         if (bConvertToLowerCase) {
            if (this.sgLCaseWord.length() == 0) {
               this.sgLCaseWord = this.sgTranslatedWord.toLowerCase();
            }

            if (sTextWithWildcard.equals(this.sgLCaseWord)) {
               return true;
            }

            if (sTextWithWildcard.length() >= this.sgLCaseWord.length()) {
               return false;
            }

            if (sTextWithWildcard.equals(this.sgLCaseWord.substring(0, sTextWithWildcard.length()))) {
               return true;
            }
         } else {
            if (sTextWithWildcard.equals(this.sgTranslatedWord)) {
               return true;
            }

            if (sTextWithWildcard.length() >= this.sgTranslatedWord.length()) {
               return false;
            }

            if (sTextWithWildcard.equals(this.sgTranslatedWord.substring(0, sTextWithWildcard.length()))) {
               return true;
            }
         }

         return false;
      } else {
         return this.matchesString(sTextWithWildcard, bConvertToLowerCase);
      }
   }

   /**
    * 编码单词，将单词sWord及其信息填写入Term的相应属性
    * @param sWord 单词字符串
    */
   private void codeWord(String sWord) {
      String sWordNew = "";
      String sEm = "";
      if (this.options.bgCorrectExtraLetterSpellingErrors) {
         int iSameCount = 0;
         int iLastCopiedPos = 0;
         int iWordEnd = sWord.length() - 1;

         int iPos;
         for(iPos = 1; iPos <= iWordEnd; ++iPos) {
            if (sWord.substring(iPos, iPos + 1).compareToIgnoreCase(sWord.substring(iPos - 1, iPos)) == 0) {
               ++iSameCount;
            } else {
               if (iSameCount > 0 && this.options.sgIllegalDoubleLettersInWordMiddle.indexOf(sWord.substring(iPos - 1, iPos)) >= 0) {
                  ++iSameCount;
               }

               if (iSameCount > 1) {
                  if (sEm == "") {
                     sWordNew = sWord.substring(0, iPos - iSameCount + 1);
                     sEm = sWord.substring(iPos - iSameCount, iPos - 1);
                     iLastCopiedPos = iPos;
                  } else {
                     sWordNew = sWordNew + sWord.substring(iLastCopiedPos, iPos - iSameCount + 1);
                     sEm = sEm + sWord.substring(iPos - iSameCount, iPos - 1);
                     iLastCopiedPos = iPos;
                  }
               }

               iSameCount = 0;
            }
         }

         if (iSameCount > 0 && this.options.sgIllegalDoubleLettersAtWordEnd.indexOf(sWord.substring(iPos - 1, iPos)) >= 0) {
            ++iSameCount;
         }

         if (iSameCount > 1) {
            if (sEm == "") {
               sWordNew = sWord.substring(0, iPos - iSameCount + 1);
               sEm = sWord.substring(iPos - iSameCount + 1);
            } else {
               sWordNew = sWordNew + sWord.substring(iLastCopiedPos, iPos - iSameCount + 1);
               sEm = sEm + sWord.substring(iPos - iSameCount + 1);
            }
         } else if (sEm != "") {
            sWordNew = sWordNew + sWord.substring(iLastCopiedPos);
         }
      }

      if (sWordNew == "") {
         sWordNew = sWord;
      }

      this.igContentType = 1;
      this.sgOriginalWord = sWord;
      this.sgWordEmphasis = sEm;
      this.sgTranslatedWord = sWordNew;
      if (this.sgTranslatedWord.indexOf("@") < 0) {
         if (this.options.bgCorrectSpellingsUsingDictionary) {
            this.correctSpellingInTranslatedWord();
         }

         if (this.options.bgUseLemmatisation) {
            if (this.sgTranslatedWord.equals("")) {
               sWordNew = this.resources.lemmatiser.lemmatise(this.sgOriginalWord);
               if (!sWordNew.equals(this.sgOriginalWord)) {
                  this.sgTranslatedWord = sWordNew;
               }
            } else {
               this.sgTranslatedWord = this.resources.lemmatiser.lemmatise(this.sgTranslatedWord);
            }
         }
      }

   }

   /**
    * 纠正翻译后拼写不规范的单词（将sgTranslatedWord字段单词改为正确拼写形式）<br>
    * 消除字母重复情况，例如 hellooooo 纠正为 hello<br>
    * 将 "ha"*n 和 "he"*n 全部纠正为 "haha" 和 "hehe"
    */
   private void correctSpellingInTranslatedWord() {
      if (!this.resources.correctSpellings.correctSpelling(this.sgTranslatedWord.toLowerCase())) {
         int iLastChar = this.sgTranslatedWord.length() - 1;

         for(int iPos = 1; iPos <= iLastChar; ++iPos) {
            if (this.sgTranslatedWord.substring(iPos, iPos + 1).compareTo(this.sgTranslatedWord.substring(iPos - 1, iPos)) == 0) {
               // 当前字母和上一个字母相同
               String sReplaceWord = this.sgTranslatedWord.substring(0, iPos) + this.sgTranslatedWord.substring(iPos + 1);
               // 消除字母重复
               if (this.resources.correctSpellings.correctSpelling(sReplaceWord.toLowerCase())) {
                  this.sgWordEmphasis = this.sgWordEmphasis + this.sgTranslatedWord.substring(iPos, iPos + 1);
                  this.sgTranslatedWord = sReplaceWord;
                  return;
               }
            }
         }

         // haha……或hehe……
         if (iLastChar > 5) {
            if (this.sgTranslatedWord.indexOf("haha") > 0) {
               this.sgWordEmphasis = this.sgWordEmphasis + this.sgTranslatedWord.substring(3, this.sgTranslatedWord.indexOf("haha") + 2);
               this.sgTranslatedWord = "haha";
               return;
            }

            if (this.sgTranslatedWord.indexOf("hehe") > 0) {
               this.sgWordEmphasis = this.sgWordEmphasis + this.sgTranslatedWord.substring(3, this.sgTranslatedWord.indexOf("hehe") + 2);
               this.sgTranslatedWord = "hehe";
            }
         }
      }
   }

   /**
    * 解析表情符号，如果sPossibleEmoticon是表情符号，填写Term的表情符号、内容类型和表情符号强度
    * @param sPossibleEmoticon 可能是表情符号的字符串
    * @return 如果sPossibleEmoticon是表情符号则返回true，不是则返回false
    */
   private boolean codeEmoticon(String sPossibleEmoticon) {
      int iEmoticonStrength = this.resources.emoticons.getEmoticon(sPossibleEmoticon);
      // 返回强度，999则不是表情符号
      if (iEmoticonStrength != 999) {
         this.igContentType = 3;
         this.sgEmoticon = sPossibleEmoticon;
         this.igEmoticonStrength = iEmoticonStrength;
         return true;
      } else {
         return false;
      }
   }

   /**
    * 解析标点符号，根据sPunctuation填写Term的标点符号字、标点符号强调和内容类型
    * @param sPunctuation 标点符号字符串
    */
   private void codePunctuation(String sPunctuation) {
      if (sPunctuation.length() > 1) {
         this.sgPunctuation = sPunctuation.substring(0, 1);
         this.sgPunctuationEmphasis = sPunctuation.substring(1);
      } else {
         this.sgPunctuation = sPunctuation;
         this.sgPunctuationEmphasis = "";
      }

      this.igContentType = 2;
   }
}
