// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 
// Source File Name:   ClassificationResources.java

package uk.ac.wlv.sentistrength;

import java.io.File;


import java.io.PrintStream;
import uk.ac.wlv.utilities.FileOps;

// Referenced classes of package uk.ac.wlv.sentistrength:
//            EmoticonsList, CorrectSpellingsList, SentimentWords, NegatingWordList, 
//            QuestionWords, BoosterWordsList, IdiomList, EvaluativeTerms, 
//            IronyList, Lemmatiser, ClassificationOptions

/**
 * ClassificationResources类包含了情感分析过程中所需要的各种资源，如情感词列表、词形还原器等。
 *
 * @author Mike Thelwall
 * @version 1.0.0
 */
public class ClassificationResources
{

    /** 表情符号 */
    public EmoticonsList emoticons;
    /** 正确拼写 */
    public CorrectSpellingsList correctSpellings;
    /** 情绪词 */
    public SentimentWords sentimentWords;
    /** 否定词 */
    public NegatingWordList negatingWords;
    /** 疑问词 */
    public QuestionWords questionWords;
    /** 增强词 */
    public BoosterWordsList boosterWords;
    /** 成语列表 */
    public IdiomList idiomList;
    /** 评价词语 */
    public EvaluativeTerms evaluativeTerms;
    /** 具有讽刺意味的词汇列表 */
    public IronyList ironyList;
    /**

     词形还原器
     */
    public Lemmatiser lemmatiser;
    /**

     SentiStrength文件夹路径
     */
    public String sgSentiStrengthFolder;
    /** 情感词文件名1 */
    public String sgSentimentWordsFile;
    /** 情感词文件名2 */
    public String sgSentimentWordsFile2;
    /** 表情符号查找表 */
    public String sgEmoticonLookupTable;
    /** 正确拼写文件名1 */
    public String sgCorrectSpellingFileName;
    /** 拼写正确文件2 */
    public String sgCorrectSpellingFileName2;
    /** 俚语查找表 */
    public String sgSlangLookupTable;
    /** 否定单词列表文件 */
    public String sgNegatingWordListFile;
    /** 增强词列表文件 */
    public String sgBoosterListFile;
    /** 成语查找表文件 */
    public String sgIdiomLookupTableFile;
    /** 单词列表文件问题 */
    public String sgQuestionWordListFile;
    /** 讽刺单词列表文件 */
    public String sgIronyWordListFile;
    /** 额外文件 */
    public String sgAdditionalFile;
    /** 词根文件 */
    public String sgLemmaFile;

    /**

     构造函数，初始化各个资源。
     */
    public ClassificationResources()
    {
        emoticons = new EmoticonsList();
        correctSpellings = new CorrectSpellingsList();
        sentimentWords = new SentimentWords();
        negatingWords = new NegatingWordList();
        questionWords = new QuestionWords();
        boosterWords = new BoosterWordsList();
        idiomList = new IdiomList();
        evaluativeTerms = new EvaluativeTerms();
        ironyList = new IronyList();
        lemmatiser = new Lemmatiser();
        sgSentiStrengthFolder = System.getProperty("user.dir")+"/src/SentStrength_Data/";
        sgSentimentWordsFile = "EmotionLookupTable.txt";
        sgSentimentWordsFile2 = "SentimentLookupTable.txt";
        sgEmoticonLookupTable = "EmoticonLookupTable.txt";
        sgCorrectSpellingFileName = "Dictionary.txt";
        sgCorrectSpellingFileName2 = "EnglishWordList.txt";
        sgSlangLookupTable = "SlangLookupTable_NOT_USED.txt";
        sgNegatingWordListFile = "NegatingWordList.txt";
        sgBoosterListFile = "BoosterWordList.txt";
        sgIdiomLookupTableFile = "IdiomLookupTable.txt";
        sgQuestionWordListFile = "QuestionWords.txt";
        sgIronyWordListFile = "IronyTerms.txt";
        sgAdditionalFile = "";
        sgLemmaFile = "";
    }

    /**

     初始化情感分析模型，读取相关的文件和设置参数。

     @param options 分类选项

     @return 如果初始化成功返回 true，否则返回 false
     */
    public boolean initialise(ClassificationOptions options)
    {   
    	int iExtraLinesToReserve = 0;
        if(sgAdditionalFile.compareTo("") != 0)
        {
            iExtraLinesToReserve = FileOps.i_CountLinesInTextFile((new StringBuilder(String.valueOf(sgSentiStrengthFolder))).append(sgAdditionalFile).toString());
            if(iExtraLinesToReserve < 0)
            {
                System.out.println((new StringBuilder("No lines found in additional file! Ignoring ")).append(sgAdditionalFile).toString());
                return false;
            }
        }
        if(options.bgUseLemmatisation && !lemmatiser.initialise((new StringBuilder(String.valueOf(sgSentiStrengthFolder))).append(sgLemmaFile).toString(), false))
        {
            System.out.println((new StringBuilder("Can't load lemma file! ")).append(sgLemmaFile).toString());
            return false;
        }
        File f = new File((new StringBuilder(String.valueOf(sgSentiStrengthFolder))).append(sgSentimentWordsFile).toString());
        if(!f.exists() || f.isDirectory())
            sgSentimentWordsFile = sgSentimentWordsFile2;
        File f2 = new File((new StringBuilder(String.valueOf(sgSentiStrengthFolder))).append(sgCorrectSpellingFileName).toString());
        if(!f2.exists() || f2.isDirectory())
            sgCorrectSpellingFileName = sgCorrectSpellingFileName2;
        if(emoticons.initialise((new StringBuilder(String.valueOf(sgSentiStrengthFolder))).append(sgEmoticonLookupTable).toString(), options) && correctSpellings.initialise((new StringBuilder(String.valueOf(sgSentiStrengthFolder))).append(sgCorrectSpellingFileName).toString(), options) && sentimentWords.initialise((new StringBuilder(String.valueOf(sgSentiStrengthFolder))).append(sgSentimentWordsFile).toString(), options, iExtraLinesToReserve) && negatingWords.initialise((new StringBuilder(String.valueOf(sgSentiStrengthFolder))).append(sgNegatingWordListFile).toString(), options) && questionWords.initialise((new StringBuilder(String.valueOf(sgSentiStrengthFolder))).append(sgQuestionWordListFile).toString(), options) && ironyList.initialise((new StringBuilder(String.valueOf(sgSentiStrengthFolder))).append(sgIronyWordListFile).toString(), options) && boosterWords.initialise((new StringBuilder(String.valueOf(sgSentiStrengthFolder))).append(sgBoosterListFile).toString(), options, iExtraLinesToReserve) && idiomList.initialise((new StringBuilder(String.valueOf(sgSentiStrengthFolder))).append(sgIdiomLookupTableFile).toString(), options, iExtraLinesToReserve))
        {
            if(iExtraLinesToReserve > 0)
                return evaluativeTerms.initialise((new StringBuilder(String.valueOf(sgSentiStrengthFolder))).append(sgAdditionalFile).toString(), options, idiomList, sentimentWords);
            else
                return true;
        } else
        {
            return false;
        }
    }
}
