/**
 * @(#)HelpOld.java
 * <p>
 * Copyright 2001 Pavel Kouznetsov.<br>
 * Decompiled by Jad v1.5.8g.<br>
 * Decompiler options: packimports(3) fieldsfirst<br>
 * Source File Name:   SentiStrengthTestAppletOld.java<br>
 * Jad home page: http://www.kpdus.com/jad.html
 */

package uk.ac.wlv.utilities;

import java.applet.Applet;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Referenced classes of package uk.ac.wlv.utilities:
//            SentiStrengthOld

/**
 * 旧版SentiStrength测试应用
 * @author Mike Thelwall
 * @version 1.0.0
 * @see SentiStrengthOld
 */
public class SentiStrengthTestAppletOld extends Applet
    implements ActionListener
{

    private static final long serialVersionUID = 0x858280b1L;
    /**
     * 字体
     */
    Font fntTimesNewRoman;
    /**
     * 输入的文本
     */
    String sgEnteredText;
    /**
     * 文本域
     */
    TextField tfField;
    /**
     * 未使用
     */
    String sgWordList[];
    /**
     * SentiStrengthOld对象
     */
    SentiStrengthOld ss;
    /**
     * SentiStrengthOld对象当前是否可用
     */
    boolean bgSentiStrengthOK;

    /**
     * SentiStrengthTestAppletOld构造方法
     */
    public SentiStrengthTestAppletOld()
    {
        fntTimesNewRoman = new Font("TimesRoman", 1, 36);
        sgEnteredText = "";
        tfField = new TextField(12);
        bgSentiStrengthOK = false;
    }

    /**
     * 初始化应用图形化界面和SentiStrengthOld对象
     */
    public void init()
    {
        ss = new SentiStrengthOld();
        bgSentiStrengthOK = ss.initialise();
        setBackground(Color.lightGray);
        tfField.addActionListener(this);
        add(tfField);
    }

    /**
     * 绘制界面，显示文字内容
     * @param g Graphics对象
     */
    public void paint(Graphics g)
    {
        g.setFont(fntTimesNewRoman);
        if(bgSentiStrengthOK)
        {
            g.drawString("sentiStrength successfully initialised", 100, 75);
        } else
        {
            g.drawString("Error - can't initalise sentiStrength", 100, 75);
            g.drawString(ss.getErrorLog(), 100, 125);
        }
        if(sgEnteredText != "")
            if(sgEnteredText.indexOf("\\") >= 0)
            {
                if(ss.classifyAllTextInFile(sgEnteredText, (new StringBuilder(String.valueOf(sgEnteredText))).append("_output.txt").toString()))
                    g.drawString("No problem with text file classification", 10, 275);
                else
                    g.drawString("Text file classification failed", 10, 275);
            } else
            {
                ss.detectEmotionInText(sgEnteredText);
                g.drawString(ss.getOriginalText(), 10, 225);
                g.drawString("was tagged as:", 100, 275);
                g.drawString(ss.getTaggedText(), 10, 325);
                g.drawString((new StringBuilder("Positive sentiment of text: ")).append(ss.getPositiveClassification()).append(", negative: ").append(ss.getNegativeClassification()).toString(), 10, 375);
            }
    }

    /**
     * 回显动作
     * @param e ActionEvent对象
     */
    public void actionPerformed(ActionEvent e)
    {
        sgEnteredText = tfField.getText();
        repaint();
    }
}
