package uk.ac.wlv.sentistrength;

import java.util.Random;

import uk.ac.wlv.utilities.Sort;
import uk.ac.wlv.utilities.StringIndex;

/**
 * 文本中的段落，由Sentence组成的分析对象
 * @author Mike Thelwall
 * @version 1.0.0
 */
public class Paragraph {
   /**
    * 组成当前段落的语句数组
    */
   private Sentence[] sentence;
   /**
    * 语句数量
    */
   private int igSentenceCount = 0;
   /**
    * 情绪ID数组
    */
   private int[] igSentimentIDList;
   /**
    * 情绪ID数组的指针
    */
   private int igSentimentIDListCount = 0;
   /**
    * 情绪ID数组是否已生成
    */
   private boolean bSentimentIDListMade = false;
   /**
    * 积极情绪分数
    */
   private int igPositiveSentiment = 0;
   /**
    * 消极情绪分数
    */
   private int igNegativeSentiment = 0;
   /**
    * 三元分类下的情绪分数
    */
   private int igTrinarySentiment = 0;
   /**
    * 规模分类下的情绪分数
    */
   private int igScaleSentiment = 0;
   /**
    * 分类资源，包含了多种类型的词语列表、符号列表等的全部信息，提供查询功能
    */
   private ClassificationResources resources;
   /**
    * 分类选项
    */
   private ClassificationOptions options;
   /**
    * 生成随机数
    */
   private Random generator = new Random();
   /**
    * 情绪分类依据的描述语句
    */
   private String sgClassificationRationale = "";

   /**
    * 将段落加入两极分类模式下的索引
    * @param unusedTermsClassificationIndex 没用到的词语的类别索引
    * @param iCorrectPosClass 积极类别的正确数值
    * @param iEstPosClass 积极类别的错误数值
    * @param iCorrectNegClass 消极类别的正确数值
    * @param iEstNegClass 消极类别的错误数值
    */
   public void addParagraphToIndexWithPosNegValues(UnusedTermsClassificationIndex unusedTermsClassificationIndex, int iCorrectPosClass, int iEstPosClass, int iCorrectNegClass, int iEstNegClass) {
      for(int i = 1; i <= this.igSentenceCount; ++i) {
         this.sentence[i].addSentenceToIndex(unusedTermsClassificationIndex);
      }

      unusedTermsClassificationIndex.addNewIndexToMainIndexWithPosNegValues(iCorrectPosClass, iEstPosClass, iCorrectNegClass, iEstNegClass);
   }

   /**
    * 将段落加入规模分类模式下的索引
    * @param unusedTermsClassificationIndex 没用到的词语的类别索引
    * @param iCorrectScaleClass 规模分类的正确数值
    * @param iEstScaleClass 规模分类的预测值
    */
   public void addParagraphToIndexWithScaleValues(UnusedTermsClassificationIndex unusedTermsClassificationIndex, int iCorrectScaleClass, int iEstScaleClass) {
      for(int i = 1; i <= this.igSentenceCount; ++i) {
         this.sentence[i].addSentenceToIndex(unusedTermsClassificationIndex);
      }

      unusedTermsClassificationIndex.addNewIndexToMainIndexWithScaleValues(iCorrectScaleClass, iEstScaleClass);
   }

   /**
    * 将段落加入二元分类模式下的索引
    * @param unusedTermsClassificationIndex 没用到的词语的类别索引
    * @param iCorrectBinaryClass 二元分类的正确数值
    * @param iEstBinaryClass 二元分类的预测值
    */
   public void addParagraphToIndexWithBinaryValues(UnusedTermsClassificationIndex unusedTermsClassificationIndex, int iCorrectBinaryClass, int iEstBinaryClass) {
      for(int i = 1; i <= this.igSentenceCount; ++i) {
         this.sentence[i].addSentenceToIndex(unusedTermsClassificationIndex);
      }

      unusedTermsClassificationIndex.addNewIndexToMainIndexWithBinaryValues(iCorrectBinaryClass, iEstBinaryClass);
   }

   /**
    * 将段落加入字符串索引
    * @param stringIndex 字符串索引
    * @param textParsingOptions 文本分析选项
    * @param bRecordCount 是否已记录
    * @param bArffIndex 是否是arff索引
    * @return 加入索引的单词的数量
    */
   public int addToStringIndex(StringIndex stringIndex, TextParsingOptions textParsingOptions, boolean bRecordCount, boolean bArffIndex) {
      int iTermsChecked = 0;

      for(int i = 1; i <= this.igSentenceCount; ++i) {
         iTermsChecked += this.sentence[i].addToStringIndex(stringIndex, textParsingOptions, bRecordCount, bArffIndex);
      }

      return iTermsChecked;
   }

   /**
    * 将段落加入三元分类模式下的索引
    * @param unusedTermsClassificationIndex 没用到的词语的类别索引
    * @param iCorrectTrinaryClass 三元分类的正确数值
    * @param iEstTrinaryClass 三元分类的预测值
    */
   public void addParagraphToIndexWithTrinaryValues(UnusedTermsClassificationIndex unusedTermsClassificationIndex, int iCorrectTrinaryClass, int iEstTrinaryClass) {
      for(int i = 1; i <= this.igSentenceCount; ++i) {
         this.sentence[i].addSentenceToIndex(unusedTermsClassificationIndex);
      }

      unusedTermsClassificationIndex.addNewIndexToMainIndexWithTrinaryValues(iCorrectTrinaryClass, iEstTrinaryClass);
   }

   /**
    * 解析段落，生成段落对应的语句列表并存储在数组中
    * @param sParagraph 待解析的段落字符串
    * @param classResources 分类资源
    * @param newClassificationOptions 分类选项
    */
   public void setParagraph(String sParagraph, ClassificationResources classResources, ClassificationOptions newClassificationOptions) {
      this.resources = classResources;
      this.options = newClassificationOptions;
      if (sParagraph.indexOf("\"") >= 0) {
         sParagraph = sParagraph.replace("\"", "'");
      }

      int iSentenceEnds = 2;
      int iPos = 0;

      while(iPos >= 0 && iPos < sParagraph.length()) {
         iPos = sParagraph.indexOf("<br>", iPos);
         if (iPos >= 0) {
            iPos += 3;
            ++iSentenceEnds;
         }
      }

      iPos = 0;

      while(iPos >= 0 && iPos < sParagraph.length()) {
         iPos = sParagraph.indexOf(".", iPos);
         if (iPos >= 0) {
            ++iPos;
            ++iSentenceEnds;
         }
      }

      iPos = 0;

      while(iPos >= 0 && iPos < sParagraph.length()) {
         iPos = sParagraph.indexOf("!", iPos);
         if (iPos >= 0) {
            ++iPos;
            ++iSentenceEnds;
         }
      }

      iPos = 0;

      while(iPos >= 0 && iPos < sParagraph.length()) {
         iPos = sParagraph.indexOf("?", iPos);
         if (iPos >= 0) {
            ++iPos;
            ++iSentenceEnds;
         }
      }

      this.sentence = new Sentence[iSentenceEnds];
      this.igSentenceCount = 0;
      int iLastSentenceEnd = -1;
      boolean bPunctuationIndicatesSentenceEnd = false;
      int iNextBr = sParagraph.indexOf("<br>");
      String sNextSentence = "";

      for(iPos = 0; iPos < sParagraph.length(); ++iPos) {
         String sNextChar = sParagraph.substring(iPos, iPos + 1);
         if (iPos == sParagraph.length() - 1) {
            sNextSentence = sParagraph.substring(iLastSentenceEnd + 1);
         } else if (iPos == iNextBr) {
            sNextSentence = sParagraph.substring(iLastSentenceEnd + 1, iPos);
            iLastSentenceEnd = iPos + 3;
            iNextBr = sParagraph.indexOf("<br>", iNextBr + 2);
         } else if (this.b_IsSentenceEndPunctuation(sNextChar)) {
            bPunctuationIndicatesSentenceEnd = true;
         } else if (sNextChar.compareTo(" ") == 0) {
            if (bPunctuationIndicatesSentenceEnd) {
               sNextSentence = sParagraph.substring(iLastSentenceEnd + 1, iPos);
               iLastSentenceEnd = iPos;
            }
         } else if (this.b_IsAlphanumeric(sNextChar) && bPunctuationIndicatesSentenceEnd) {
            sNextSentence = sParagraph.substring(iLastSentenceEnd + 1, iPos);
            iLastSentenceEnd = iPos - 1;
         }

         if (sNextSentence != "") {
            ++this.igSentenceCount;
            this.sentence[this.igSentenceCount] = new Sentence();
            this.sentence[this.igSentenceCount].setSentence(sNextSentence, this.resources, this.options);
            sNextSentence = "";
            bPunctuationIndicatesSentenceEnd = false;
         }
      }

   }

   /**
    * 获取情绪ID列表
    * @return 情绪ID列表数组
    */
   public int[] getSentimentIDList() {
      if (!this.bSentimentIDListMade) {
         this.makeSentimentIDList();
      }

      return this.igSentimentIDList;
   }

   /**
    * 获取分类依据的描述语句
    * @return 分类依据描述的字符串
    */
   public String getClassificationRationale() {
      return this.sgClassificationRationale;
   }

   /**
    * 生成情绪ID数组
    */
   public void makeSentimentIDList() {
      boolean bIsDuplicate = false;
      this.igSentimentIDListCount = 0;

      int i;
      for(i = 1; i <= this.igSentenceCount; ++i) {
         if (this.sentence[i].getSentimentIDList() != null) {
            this.igSentimentIDListCount += this.sentence[i].getSentimentIDList().length;
         }
      }

      if (this.igSentimentIDListCount > 0) {
         this.igSentimentIDList = new int[this.igSentimentIDListCount + 1];
         this.igSentimentIDListCount = 0;

         for(i = 1; i <= this.igSentenceCount; ++i) {
            int[] sentenceIDList = this.sentence[i].getSentimentIDList();
            if (sentenceIDList != null) {
               for(int j = 1; j < sentenceIDList.length; ++j) {
                  if (sentenceIDList[j] != 0) {
                     bIsDuplicate = false;

                     for(int k = 1; k <= this.igSentimentIDListCount; ++k) {
                        if (sentenceIDList[j] == this.igSentimentIDList[k]) {
                           bIsDuplicate = true;
                           break;
                        }
                     }

                     if (!bIsDuplicate) {
                        this.igSentimentIDList[++this.igSentimentIDListCount] = sentenceIDList[j];
                     }
                  }
               }
            }
         }

         Sort.quickSortInt(this.igSentimentIDList, 1, this.igSentimentIDListCount);
      }

      this.bSentimentIDListMade = true;
   }

   /**
    * 获取将段落内容以HTML标签形式显示的代码，由Sentence部分的代码组合而成
    * @return 代码语句
    */
   public String getTaggedParagraph() {
      String sTagged = "";

      for(int i = 1; i <= this.igSentenceCount; ++i) {
         sTagged = sTagged + this.sentence[i].getTaggedSentence();
      }

      return sTagged;
   }

   /**
    * 获取翻译后的段落
    * @return 翻译后的段落字符串
    */
   public String getTranslatedParagraph() {
      String sTranslated = "";

      for(int i = 1; i <= this.igSentenceCount; ++i) {
         sTranslated = sTranslated + this.sentence[i].getTranslatedSentence();
      }

      return sTranslated;
   }

   /**
    * 重新计算段落的情绪分数
    */
   public void recalculateParagraphSentimentScores() {
      for(int iSentence = 1; iSentence <= this.igSentenceCount; ++iSentence) {
         this.sentence[iSentence].recalculateSentenceSentimentScore();
      }

      this.calculateParagraphSentimentScores();
   }

   /**
    * 重新为分类好的段落分类以便更改情绪分数
    * @param iSentimentWordID 情绪词语ID
    */
   public void reClassifyClassifiedParagraphForSentimentChange(int iSentimentWordID) {
      if (this.igNegativeSentiment == 0) {
         this.calculateParagraphSentimentScores();
      } else {
         if (!this.bSentimentIDListMade) {
            this.makeSentimentIDList();
         }

         if (this.igSentimentIDListCount != 0) {
            if (Sort.i_FindIntPositionInSortedArray(iSentimentWordID, this.igSentimentIDList, 1, this.igSentimentIDListCount) >= 0) {
               for(int iSentence = 1; iSentence <= this.igSentenceCount; ++iSentence) {
                  this.sentence[iSentence].reClassifyClassifiedSentenceForSentimentChange(iSentimentWordID);
               }

               this.calculateParagraphSentimentScores();
            }

         }
      }
   }

   /**
    * 获取段落积极情绪分数
    * @return 段落积极情绪分数值
    */
   public int getParagraphPositiveSentiment() {
      if (this.igPositiveSentiment == 0) {
         this.calculateParagraphSentimentScores();
      }

      return this.igPositiveSentiment;
   }

   /**
    * 获取段落消极情绪分数
    * @return 段落消极情绪分数值
    */
   public int getParagraphNegativeSentiment() {
      if (this.igNegativeSentiment == 0) {
         this.calculateParagraphSentimentScores();
      }

      return this.igNegativeSentiment;
   }

   /**
    * 获取段落三元分类下的情绪分数
    * @return 段落三元分类下的情绪分数
    */
   public int getParagraphTrinarySentiment() {
      if (this.igNegativeSentiment == 0) {
         this.calculateParagraphSentimentScores();
      }

      return this.igTrinarySentiment;
   }

   /**
    * 获取段落scale分类下的情绪分数
    * @return scale分类下的情绪分数
    */
   public int getParagraphScaleSentiment() {
      if (this.igNegativeSentiment == 0) {
         this.calculateParagraphSentimentScores();
      }

      return this.igScaleSentiment;
   }

   /**
    * 语句是否由标点符号结尾
    * @param sChar 要判断是否为标点符号的字符串
    * @return 是则返回true,否则返回false
    */
   private boolean b_IsSentenceEndPunctuation(String sChar) {
      return sChar.compareTo(".") == 0 || sChar.compareTo("!") == 0 || sChar.compareTo("?") == 0;
   }

   /**
    * 是否是数字或字母
    * @param sChar 要判断是否是数字或字母的字符串
    * @return 是则返回true,否则返回false
    */
   private boolean b_IsAlphanumeric(String sChar) {
      return sChar.compareToIgnoreCase("a") >= 0 && sChar.compareToIgnoreCase("z") <= 0 || sChar.compareTo("0") >= 0 && sChar.compareTo("9") <= 0 || sChar.compareTo("$") == 0 || sChar.compareTo("£") == 0 || sChar.compareTo("'") == 0;
   }

   /**
    * 计算段落的情绪分数
    */
   private void calculateParagraphSentimentScores() {
      this.igPositiveSentiment = 1;
      this.igNegativeSentiment = -1;
      this.igTrinarySentiment = 0;
      if (this.options.bgExplainClassification && this.sgClassificationRationale.length() > 0) {
         this.sgClassificationRationale = "";
      }

      int iPosTotal = 0;
      int iPosMax = 0;
      int iNegTotal = 0;
      int iNegMax = 0;
      int iPosTemp =0;
      int iNegTemp =0;
      int iSentencesUsed = 0;
      int wordNum =0;
      int sentiNum =0;
      if (this.igSentenceCount != 0) {
         int iNegTot;
         for(iNegTot = 1; iNegTot <= this.igSentenceCount; ++iNegTot) {
            iNegTemp = this.sentence[iNegTot].getSentenceNegativeSentiment();
            iPosTemp = this.sentence[iNegTot].getSentencePositiveSentiment();
            wordNum+=this.sentence[iNegTot].getIgTermCount();
            sentiNum+=this.sentence[iNegTot].getIgSentiCount();
            if (iNegTemp != 0 || iPosTemp != 0) {
               iNegTotal += iNegTemp;
               ++iSentencesUsed;
               if (iNegMax > iNegTemp) {
                  iNegMax = iNegTemp;
               }

               iPosTotal += iPosTemp;
               if (iPosMax < iPosTemp) {
                  iPosMax = iPosTemp;
               }
            }

            if (this.options.bgExplainClassification) {
               this.sgClassificationRationale = this.sgClassificationRationale + this.sentence[iNegTot].getClassificationRationale() + " ";
            }
         }
         
         int var10000;
         if (iNegTotal == 0) {
            var10000 = this.options.igEmotionParagraphCombineMethod;
            this.options.getClass();
            if (var10000 != 2) {
               this.igPositiveSentiment = 0;
               this.igNegativeSentiment = 0;
               this.igTrinarySentiment = this.binarySelectionTieBreaker();
               return;
            }
         }

         var10000 = this.options.igEmotionParagraphCombineMethod;
         this.options.getClass();
         if (var10000 == 1) {
            this.igPositiveSentiment = (int)((double)((float)iPosTotal / (float)iSentencesUsed) + 0.5D);
            this.igNegativeSentiment = (int)((double)((float)iNegTotal / (float)iSentencesUsed) - 0.5D);
            if (this.options.bgExplainClassification) {
               this.sgClassificationRationale = this.sgClassificationRationale + "[result = average (" + iPosTotal + " and " + iNegTotal + ") of " + iSentencesUsed + " sentences]";
            }
         } else {
            var10000 = this.options.igEmotionParagraphCombineMethod;
            this.options.getClass();
            if (var10000 == 2) {
               this.igPositiveSentiment = iPosTotal;
               this.igNegativeSentiment = iNegTotal;
               if (this.options.bgExplainClassification) {
                  this.sgClassificationRationale = this.sgClassificationRationale + "[result: total positive; total negative]";
               }
            } else {
               this.igPositiveSentiment = iPosMax;
               this.igNegativeSentiment = iNegMax;
               if (this.options.bgExplainClassification) {
                  this.sgClassificationRationale = this.sgClassificationRationale + "[result: max + and - of any sentence]";
               }
            }
         }

         var10000 = this.options.igEmotionParagraphCombineMethod;
         this.options.getClass();
         if (var10000 != 2) {
            if (this.igPositiveSentiment == 0) {
               this.igPositiveSentiment = 1;
            }

            if (this.igNegativeSentiment == 0) {
               this.igNegativeSentiment = -1;
            }
         }

         if (this.options.bgScaleMode) {
            this.igScaleSentiment = this.igPositiveSentiment + this.igNegativeSentiment;
            if (this.options.bgExplainClassification) {
               this.sgClassificationRationale = this.sgClassificationRationale + "[scale result = sum of pos and neg scores]";
            }

         } else {
            var10000 = this.options.igEmotionParagraphCombineMethod;
            this.options.getClass();
            if (var10000 == 2) {
               if (this.igPositiveSentiment == 0 && this.igNegativeSentiment == 0) {
                  if (this.options.bgBinaryVersionOfTrinaryMode) {
                     this.igTrinarySentiment = this.options.igDefaultBinaryClassification;
                     if (this.options.bgExplainClassification) {
                        this.sgClassificationRationale = this.sgClassificationRationale + "[binary result set to default value]";
                     }
                  } else {
                     this.igTrinarySentiment = 0;
                     if (this.options.bgExplainClassification) {
                        this.sgClassificationRationale = this.sgClassificationRationale + "[trinary result 0 as pos=1, neg=-1]";
                     }
                  }
               } else {
                  if ((float)this.igPositiveSentiment > this.options.fgNegativeSentimentMultiplier * (float)(-this.igNegativeSentiment)) {
                     this.igTrinarySentiment = 1;
                     if (this.options.bgExplainClassification) {
                        this.sgClassificationRationale = this.sgClassificationRationale + "[overall result 1 as pos > -neg * " + this.options.fgNegativeSentimentMultiplier + "]";
                     }

                     return;
                  }

                  if ((float)this.igPositiveSentiment < this.options.fgNegativeSentimentMultiplier * (float)(-this.igNegativeSentiment)) {
                     this.igTrinarySentiment = -1;
                     if (this.options.bgExplainClassification) {
                        this.sgClassificationRationale = this.sgClassificationRationale + "[overall result -1 as pos < -neg * " + this.options.fgNegativeSentimentMultiplier + "]";
                     }

                     return;
                  }

                  if (this.options.bgBinaryVersionOfTrinaryMode) {
                     this.igTrinarySentiment = this.options.igDefaultBinaryClassification;
                     if (this.options.bgExplainClassification) {
                        this.sgClassificationRationale = this.sgClassificationRationale + "[binary result = default value as pos = -neg * " + this.options.fgNegativeSentimentMultiplier + "]";
                     }
                  } else {
                     this.igTrinarySentiment = 0;
                     if (this.options.bgExplainClassification) {
                        this.sgClassificationRationale = this.sgClassificationRationale + "[trinary result = 0 as pos = -neg * " + this.options.fgNegativeSentimentMultiplier + "]";
                     }
                  }
               }
            } else {
               if (this.igPositiveSentiment == 1 && this.igNegativeSentiment == -1) {
                  if (this.options.bgBinaryVersionOfTrinaryMode) {
                     this.igTrinarySentiment = this.binarySelectionTieBreaker();
                     if (this.options.bgExplainClassification) {
                        this.sgClassificationRationale = this.sgClassificationRationale + "[binary result = default value as pos=1 neg=-1]";
                     }
                  } else {
                     this.igTrinarySentiment = 0;
                     if (this.options.bgExplainClassification) {
                        this.sgClassificationRationale = this.sgClassificationRationale + "[trinary result = 0 as pos=1 neg=-1]";
                     }
                  }

                  return;
               }

               if (this.igPositiveSentiment > -this.igNegativeSentiment) {
                  this.igTrinarySentiment = 1;
                  if (this.options.bgExplainClassification) {
                     this.sgClassificationRationale = this.sgClassificationRationale + "[overall result = 1 as pos>-neg]";
                  }

                  return;
               }

               if (this.igPositiveSentiment < -this.igNegativeSentiment) {
                  this.igTrinarySentiment = -1;
                  if (this.options.bgExplainClassification) {
                     this.sgClassificationRationale = this.sgClassificationRationale + "[overall result = -1 as pos<-neg]";
                  }

                  return;
               }

               iNegTot = 0;
               int iPosTot = 0;

               for(int iSentence = 1; iSentence <= this.igSentenceCount; ++iSentence) {
                  iNegTot += this.sentence[iSentence].getSentenceNegativeSentiment();
                  iPosTot = this.sentence[iSentence].getSentencePositiveSentiment();
               }

               if (this.options.bgBinaryVersionOfTrinaryMode && iPosTot == -iNegTot) {
                  this.igTrinarySentiment = this.binarySelectionTieBreaker();
                  if (this.options.bgExplainClassification) {
                     this.sgClassificationRationale = this.sgClassificationRationale + "[binary result = default as posSentenceTotal>-negSentenceTotal]";
                  }
               } else {
                  if (this.options.bgExplainClassification) {
                     this.sgClassificationRationale = this.sgClassificationRationale + "[overall result = largest of posSentenceTotal, negSentenceTotal]";
                  }

                  if (iPosTot > -iNegTot) {
                     this.igTrinarySentiment = 1;
                  } else {
                     this.igTrinarySentiment = -1;
                  }
               }
            }

         }
      }
   }

   /**
    * 二元分类平局情况最终决定正负
    * @return 返回1代表积极情绪，-1代表消极情绪
    */
   private int binarySelectionTieBreaker() {
      if (this.options.igDefaultBinaryClassification != 1 && this.options.igDefaultBinaryClassification != -1) {
         return this.generator.nextDouble() > 0.5D ? 1 : -1;
      } else {
         return this.options.igDefaultBinaryClassification != 1 && this.options.igDefaultBinaryClassification != -1 ? this.options.igDefaultBinaryClassification : this.options.igDefaultBinaryClassification;
      }
   }
}
