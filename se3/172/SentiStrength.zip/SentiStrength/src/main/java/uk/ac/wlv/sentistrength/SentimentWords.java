// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 
// Source File Name:   SentimentWords.java

package uk.ac.wlv.sentistrength;

import java.io.*;


import uk.ac.wlv.utilities.FileOps;
import uk.ac.wlv.utilities.Sort;

// Referenced classes of package uk.ac.wlv.sentistrength:
//            Corpus, ClassificationOptions

/**
 * 情绪单词列表，带有通配符的情绪单词列表
 * @author Mike Thelwall
 * @version 1.0.0
 */
public class SentimentWords
{

    /**
     * 情绪单词
     */
    private String sgSentimentWords[];
    /**
     * 情绪单词强度数值
     */
    private int igSentimentWordsStrengthTake1[];
    /**
     * 情绪单词数量
     */
    private int igSentimentWordsCount;
    /**
     * 开始位置带有通配符的情绪单词
     */
    private String sgSentimentWordsWithStarAtStart[];
    /**
     * 开始位置带有通配符的情绪单词的强度数值
     */
    private int igSentimentWordsWithStarAtStartStrengthTake1[];
    /**
     * 开始位置带有通配符的情绪单词数量
     */
    private int igSentimentWordsWithStarAtStartCount;
    /**
     * 开始位置带有通配符的情绪单词在结束位置是否有通配符
     */
    private boolean bgSentimentWordsWithStarAtStartHasStarAtEnd[];

    /**
     * SentimentWords构造函数
     */
    public SentimentWords()
    {
        igSentimentWordsCount = 0;
        igSentimentWordsWithStarAtStartCount = 0;
    }

    /**
     * 根据序号获取情绪单词
     * @param iWordID 单词序号
     * @return 情绪单词，如果查找失败返回空字符串
     */
    public String getSentimentWord(int iWordID)
    {
        if(iWordID > 0)
        {
            if(iWordID <= igSentimentWordsCount)
                return sgSentimentWords[iWordID];
            if(iWordID <= igSentimentWordsCount + igSentimentWordsWithStarAtStartCount)
                return sgSentimentWordsWithStarAtStart[iWordID - igSentimentWordsCount];
        }
        return "";
    }

    /**
     * 获取情绪单词的强度数值
     * @param sWord 情绪单词
     * @return 情绪强度数值，如果返回999表示该单词不存在于情绪词列表
     */
    public int getSentiment(String sWord)
    {
        int iWordID = Sort.i_FindStringPositionInSortedArrayWithWildcardsInArray(sWord.toLowerCase(), sgSentimentWords, 1, igSentimentWordsCount);
        if(iWordID >= 0)
            return igSentimentWordsStrengthTake1[iWordID];
        int iStarWordID = getMatchingStarAtStartRawWordID(sWord);
        if(iStarWordID >= 0)
            return igSentimentWordsWithStarAtStartStrengthTake1[iStarWordID];
        else
            return 999;
    }

    /**
     * 将情绪单词sWord的强度数值设为iNewSentiment，匹配支持通配符
     * @param sWord 情绪单词
     * @param iNewSentiment 新情绪强度数值
     * @return true表示操作成功，false表示sWord匹配不成功，操作失败
     */
    public boolean setSentiment(String sWord, int iNewSentiment)
    {
        int iWordID = Sort.i_FindStringPositionInSortedArrayWithWildcardsInArray(sWord.toLowerCase(), sgSentimentWords, 1, igSentimentWordsCount);
        if(iWordID >= 0)
        {
            if(iNewSentiment > 0)
                setSentiment(iWordID, iNewSentiment - 1);
            else
                setSentiment(iWordID, iNewSentiment + 1);
            return true;
        }
        if(sWord.indexOf("*") == 0)
        {
            sWord = sWord.substring(1);
            if(sWord.indexOf("*") > 0)
                sWord.substring(0, sWord.length() - 1);
        }
        if(igSentimentWordsWithStarAtStartCount > 0)
        {
            for(int i = 1; i <= igSentimentWordsWithStarAtStartCount; i++)
                if(sWord == sgSentimentWordsWithStarAtStart[i])
                {
                    if(iNewSentiment > 0)
                        setSentiment(igSentimentWordsCount + i, iNewSentiment - 1);
                    else
                        setSentiment(igSentimentWordsCount + i, iNewSentiment + 1);
                    return true;
                }
        }
        return false;
    }

    /**
     * 将全部SentimentList信息保存在文件sFilename中<br>
     * 信息包括情绪单词列表、带通配符的情绪单词列表和它们的强度数组
     * @param sFilename 存储信息的文件名
     * @param c 文本集合
     * @return true表示操作成功，false表示操作失败
     */
    public boolean saveSentimentList(String sFilename, Corpus c)
    {
        try
        {
            BufferedWriter wWriter = new BufferedWriter(new FileWriter(sFilename));
            for(int i = 1; i <= igSentimentWordsCount; i++)
            {
                int iSentimentStrength = igSentimentWordsStrengthTake1[i];
                if(iSentimentStrength < 0)
                    iSentimentStrength--;
                else
                    iSentimentStrength++;
                String sOutput = (new StringBuilder(String.valueOf(sgSentimentWords[i]))).append("\t").append(iSentimentStrength).append("\n").toString();
                if(c.options.bgForceUTF8)
                    try
                    {
                        sOutput = new String(sOutput.getBytes("UTF-8"), "UTF-8");
                    }
                    catch(UnsupportedEncodingException e)
                    {
                        System.out.println("UTF-8 not found on your system!");
                        e.printStackTrace();
                    }
                wWriter.write(sOutput);
            }

            for(int i = 1; i <= igSentimentWordsWithStarAtStartCount; i++)
            {
                int iSentimentStrength = igSentimentWordsWithStarAtStartStrengthTake1[i];
                if(iSentimentStrength < 0)
                    iSentimentStrength--;
                else
                    iSentimentStrength++;
                String sOutput = (new StringBuilder("*")).append(sgSentimentWordsWithStarAtStart[i]).toString();
                if(bgSentimentWordsWithStarAtStartHasStarAtEnd[i])
                    sOutput = (new StringBuilder(String.valueOf(sOutput))).append("*").toString();
                sOutput = (new StringBuilder(String.valueOf(sOutput))).append("\t").append(iSentimentStrength).append("\n").toString();
                if(c.options.bgForceUTF8)
                    try
                    {
                        sOutput = new String(sOutput.getBytes("UTF-8"), "UTF-8");
                    }
                    catch(UnsupportedEncodingException e)
                    {
                        System.out.println("UTF-8 not found on your system!");
                        e.printStackTrace();
                    }
                wWriter.write(sOutput);
            }

            wWriter.close();
        }
        catch(IOException e)
        {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 向输出流输出所有情绪单词和带通配符的情绪单词的强度数值，单行输出，使用Tab分隔各个数值
     * @param wWriter 输出流
     * @return 操作成功返回true，否则返回false
     */
    public boolean printSentimentValuesInSingleRow(BufferedWriter wWriter)
    {
        try
        {
            for(int i = 1; i <= igSentimentWordsCount; i++)
            {
                int iSentimentStrength = igSentimentWordsStrengthTake1[i];
                wWriter.write((new StringBuilder("\t")).append(iSentimentStrength).toString());
            }
            for(int i = 1; i <= igSentimentWordsWithStarAtStartCount; i++)
            {
                int iSentimentStrength = igSentimentWordsWithStarAtStartStrengthTake1[i];
                wWriter.write((new StringBuilder("\t")).append(iSentimentStrength).toString());
            }
            wWriter.write("\n");
        }
        catch(IOException e)
        {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 向输出流输出所有情绪单词和带通配符的情绪单词，单行输出，使用Tab分隔各个字符串
     * @param wWriter 输出流
     * @return 操作成功返回true，否则返回false
     */
    public boolean printSentimentTermsInSingleHeaderRow(BufferedWriter wWriter)
    {
        try
        {
            for(int i = 1; i <= igSentimentWordsCount; i++)
                wWriter.write((new StringBuilder("\t")).append(sgSentimentWords[i]).toString());
            for(int i = 1; i <= igSentimentWordsWithStarAtStartCount; i++)
            {
                wWriter.write((new StringBuilder("\t*")).append(sgSentimentWordsWithStarAtStart[i]).toString());
                if(bgSentimentWordsWithStarAtStartHasStarAtEnd[i])
                    wWriter.write("*");
            }
            wWriter.write("\n");
        }
        catch(IOException e)
        {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 根据单词序号获取单词的情感强度数值
     * @param iWordID 单词序号
     * @return 单词的情感强度数值，999表示列表中查找不到序号为iWordID的情绪单词
     */
    public int getSentiment(int iWordID)
    {
        if(iWordID > 0)
        {
            if(iWordID <= igSentimentWordsCount)
                return igSentimentWordsStrengthTake1[iWordID];
            else
                return igSentimentWordsWithStarAtStartStrengthTake1[iWordID - igSentimentWordsCount];
        } else
        {
            return 999;
        }
    }

    /**
     * 将序号为iWordID的情绪单词的强度数值设置为iNewSentiment
     * @param iWordID 情绪单词序号
     * @param iNewSentiment 新情感强度数值
     */
    public void setSentiment(int iWordID, int iNewSentiment)
    {
        if(iWordID <= igSentimentWordsCount)
            igSentimentWordsStrengthTake1[iWordID] = iNewSentiment;
        else
            igSentimentWordsWithStarAtStartStrengthTake1[iWordID - igSentimentWordsCount] = iNewSentiment;
    }

    /**
     * 获取情绪单词在情绪单词列表中的序号
     * @param sWord 单词
     * @return sWord在情绪单词列表中的序号，-1表示情绪单词列表中查找不到sWord
     */
    public int getSentimentID(String sWord)
    {
        int iWordID = Sort.i_FindStringPositionInSortedArrayWithWildcardsInArray(sWord.toLowerCase(), sgSentimentWords, 1, igSentimentWordsCount);
        if(iWordID >= 0)
            return iWordID;
        iWordID = getMatchingStarAtStartRawWordID(sWord);
        if(iWordID >= 0)
            return iWordID + igSentimentWordsCount;
        else
            return -1;
    }

    /**
     * 如果单词sWord能匹配带通配符情绪单词列表中的一项，返回该项序号
     * @param sWord 目标单词
     * @return 单词在带通配符情绪单词列表中的序号，-1表示该列表中未查找到该单词
     */
    private int getMatchingStarAtStartRawWordID(String sWord)
    {
        int iSubStringPos = 0;
        if(igSentimentWordsWithStarAtStartCount > 0)
        {
            for(int i = 1; i <= igSentimentWordsWithStarAtStartCount; i++)
            {
                iSubStringPos = sWord.indexOf(sgSentimentWordsWithStarAtStart[i]);
                if(iSubStringPos >= 0 && (bgSentimentWordsWithStarAtStartHasStarAtEnd[i] || iSubStringPos + sgSentimentWordsWithStarAtStart[i].length() == sWord.length()))
                    return i;
            }

        }
        return -1;
    }

    /**
     * 获取情绪单词数量
     *
     * @return int 情绪单词数量
     */
    public int getSentimentWordCount()
    {
        return igSentimentWordsCount;
    }

    /**
     * 初始化情绪单词列表
     * @param sFilename 存储情绪单词文件的文件名
     * @param options 参数设置选项
     * @param iExtraBlankArrayEntriesToInclude 数组长度 = 情绪单词的数量 + 额外空项数量
     * @return true表示初始化成功，false表示初始化出错失败
     */
    public boolean initialise(String sFilename, ClassificationOptions options, int iExtraBlankArrayEntriesToInclude)
    {
        int iWordStrength = 0;
        int iWordsWithStarAtStart = 0;
        if(sFilename == "")
        {
            System.out.println("No sentiment file specified");
            return false;
        }
        File f = new File(sFilename);
        if(!f.exists())
        {
            System.out.println((new StringBuilder("Could not find sentiment file: ")).append(sFilename).toString());
            return false;
        }
        int iLinesInFile = FileOps.i_CountLinesInTextFile(sFilename);
        if(iLinesInFile < 2)
        {
            System.out.println((new StringBuilder("Less than 2 lines in sentiment file: ")).append(sFilename).toString());
            return false;
        }
        igSentimentWordsStrengthTake1 = new int[iLinesInFile + 1 + iExtraBlankArrayEntriesToInclude];
        sgSentimentWords = new String[iLinesInFile + 1 + iExtraBlankArrayEntriesToInclude];
        igSentimentWordsCount = 0;
        try
        {
            BufferedReader rReader;
            if(options.bgForceUTF8)
                rReader = new BufferedReader(new InputStreamReader(new FileInputStream(sFilename), "UTF8"));
            else
                rReader = new BufferedReader(new FileReader(sFilename));
            String sLine;
            while((sLine = rReader.readLine()) != null) 
                if(sLine != "")
                    if(sLine.indexOf("*") == 0)
                    {
                        iWordsWithStarAtStart++;
                    } else
                    {
                        int iFirstTabLocation = sLine.indexOf("\t");
                        if(iFirstTabLocation >= 0)
                        {
                            int iSecondTabLocation = sLine.indexOf("\t", iFirstTabLocation + 1);
                            try
                            {
                                if(iSecondTabLocation > 0)
                                    iWordStrength = Integer.parseInt(sLine.substring(iFirstTabLocation + 1, iSecondTabLocation).trim());
                                else
                                    iWordStrength = Integer.parseInt(sLine.substring(iFirstTabLocation + 1).trim());
                            }
                            catch(NumberFormatException e)
                            {
                                System.out.println((new StringBuilder("Failed to identify integer weight for sentiment word! Ignoring word\nLine: ")).append(sLine).toString());
                                iWordStrength = 0;
                            }
                            sLine = sLine.substring(0, iFirstTabLocation);
                            if(sLine.indexOf(" ") >= 0)
                                sLine = sLine.trim();
                            if(sLine != "")
                            {
                                sgSentimentWords[++igSentimentWordsCount] = sLine;
                                if(iWordStrength > 0)
                                    iWordStrength--;
                                else
                                if(iWordStrength < 0)
                                    iWordStrength++;
                                igSentimentWordsStrengthTake1[igSentimentWordsCount] = iWordStrength;
                            }
                        }
                    }
            rReader.close();
            Sort.quickSortStringsWithInt(sgSentimentWords, igSentimentWordsStrengthTake1, 1, igSentimentWordsCount);
        }
        catch(FileNotFoundException e)
        {
            System.out.println((new StringBuilder("Couldn't find sentiment file: ")).append(sFilename).toString());
            e.printStackTrace();
            return false;
        }
        catch(IOException e)
        {
            System.out.println((new StringBuilder("Found sentiment file but couldn't read from it: ")).append(sFilename).toString());
            e.printStackTrace();
            return false;
        }
        if(iWordsWithStarAtStart > 0)
            return initialiseWordsWithStarAtStart(sFilename, options, iWordsWithStarAtStart, iExtraBlankArrayEntriesToInclude);
        else
            return true;
    }

    /**
     * 初始化开始位置带通配符的情绪单词列表
     * @param sFilename 存储情绪单词的文件名
     * @param options 参数设置选项
     * @param iWordsWithStarAtStart 开始位置带通配符的情绪单词的数量
     * @param iExtraBlankArrayEntriesToInclude 数组长度 = 带通配符的情绪单词的数量 + 额外空项数量
     * @return true表示初始化成功，false表示初始化出错失败
     */
    public boolean initialiseWordsWithStarAtStart(String sFilename, ClassificationOptions options, int iWordsWithStarAtStart, int iExtraBlankArrayEntriesToInclude)
    {
        int iWordStrength = 0;
        File f = new File(sFilename);
        if(!f.exists())
        {
            System.out.println((new StringBuilder("Could not find sentiment file: ")).append(sFilename).toString());
            return false;
        }
        igSentimentWordsWithStarAtStartStrengthTake1 = new int[iWordsWithStarAtStart + 1 + iExtraBlankArrayEntriesToInclude];
        sgSentimentWordsWithStarAtStart = new String[iWordsWithStarAtStart + 1 + iExtraBlankArrayEntriesToInclude];
        bgSentimentWordsWithStarAtStartHasStarAtEnd = new boolean[iWordsWithStarAtStart + 1 + iExtraBlankArrayEntriesToInclude];
        igSentimentWordsWithStarAtStartCount = 0;
        try
        {
            BufferedReader rReader;
            if(options.bgForceUTF8)
                rReader = new BufferedReader(new InputStreamReader(new FileInputStream(sFilename), "UTF8"));
            else
                rReader = new BufferedReader(new FileReader(sFilename));
            while(rReader.ready()) 
            {
                String sLine = rReader.readLine();
                if(sLine != "" && sLine.indexOf("*") == 0)
                {
                    int iFirstTabLocation = sLine.indexOf("\t");
                    if(iFirstTabLocation >= 0)
                    {
                        int iSecondTabLocation = sLine.indexOf("\t", iFirstTabLocation + 1);
                        try
                        {
                            if(iSecondTabLocation > 0)
                                iWordStrength = Integer.parseInt(sLine.substring(iFirstTabLocation + 1, iSecondTabLocation));
                            else
                                iWordStrength = Integer.parseInt(sLine.substring(iFirstTabLocation + 1));
                        }
                        catch(NumberFormatException e)
                        {
                            System.out.println((new StringBuilder("Failed to identify integer weight for *sentiment* word! Ignoring word\nLine: ")).append(sLine).toString());
                            iWordStrength = 0;
                        }
                        sLine = sLine.substring(1, iFirstTabLocation);
                        if(sLine.indexOf("*") > 0)
                        {
                            sLine = sLine.substring(0, sLine.indexOf("*"));
                            bgSentimentWordsWithStarAtStartHasStarAtEnd[++igSentimentWordsWithStarAtStartCount] = true;
                        } else
                        {
                            bgSentimentWordsWithStarAtStartHasStarAtEnd[++igSentimentWordsWithStarAtStartCount] = false;
                        }
                        if(sLine.indexOf(" ") >= 0)
                            sLine = sLine.trim();
                        if(sLine != "")
                        {
                            sgSentimentWordsWithStarAtStart[igSentimentWordsWithStarAtStartCount] = sLine;
                            if(iWordStrength > 0)
                                iWordStrength--;
                            else
                            if(iWordStrength < 0)
                                iWordStrength++;
                            igSentimentWordsWithStarAtStartStrengthTake1[igSentimentWordsWithStarAtStartCount] = iWordStrength;
                        } else
                        {
                            igSentimentWordsWithStarAtStartCount--;
                        }
                    }
                }
            }
            rReader.close();
        }
        catch(FileNotFoundException e)
        {
            System.out.println((new StringBuilder("Couldn't find *sentiment file*: ")).append(sFilename).toString());
            e.printStackTrace();
            return false;
        }
        catch(IOException e)
        {
            System.out.println((new StringBuilder("Found *sentiment file* but couldn't read from it: ")).append(sFilename).toString());
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 添加或修改情绪单词
     * <p>如果情绪词列表中不存在sTerm，则添加sTerm，再根据iTermStrength添加或修改sTerm强度数值
     * @param sTerm 情绪词
     * @param iTermStrength 情绪单词强度数值
     * @param bSortSentimentListAfterAddingTerm 添加或新单词后，情绪单词表是否重新排序
     * @return 操作成功返回true，出现异常操作失败返回false
     */
    public boolean addOrModifySentimentTerm(String sTerm, int iTermStrength, boolean bSortSentimentListAfterAddingTerm)
    {
        int iTermPosition = getSentimentID(sTerm);
        if(iTermPosition > 0)
        {
            if(iTermStrength > 0)
                iTermStrength--;
            else
            if(iTermStrength < 0)
                iTermStrength++;
            igSentimentWordsStrengthTake1[iTermPosition] = iTermStrength;
        } else
        {
            try
            {
                sgSentimentWords[++igSentimentWordsCount] = sTerm;
                if(iTermStrength > 0)
                    iTermStrength--;
                else
                if(iTermStrength < 0)
                    iTermStrength++;
                igSentimentWordsStrengthTake1[igSentimentWordsCount] = iTermStrength;
                if(bSortSentimentListAfterAddingTerm)
                    Sort.quickSortStringsWithInt(sgSentimentWords, igSentimentWordsStrengthTake1, 1, igSentimentWordsCount);
            }
            catch(Exception e)
            {
                System.out.println((new StringBuilder("Could not add extra sentiment term: ")).append(sTerm).toString());
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }

    /**
     * 情绪单词列表按字典序排序，情绪强度数组中的项也跟随进行同步位置移动
     */
    public void sortSentimentList()
    {
        Sort.quickSortStringsWithInt(sgSentimentWords, igSentimentWordsStrengthTake1, 1, igSentimentWordsCount);
    }
}
