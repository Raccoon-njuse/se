// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 
// Source File Name:   BoosterWordsList.java

package uk.ac.wlv.sentistrength;
import java.io.*;

import uk.ac.wlv.utilities.FileOps;
import uk.ac.wlv.utilities.Sort;

// Referenced classes of package uk.ac.wlv.sentistrength:
//            ClassificationOptions

/**
 * 加强词列表
 * @author Mike Thelwall
 * @version 1.0.0
 */
public class BoosterWordsList
{

    /**
     * 加强词
     */
    private String sgBoosterWords[];
    /**
     * 加强词强度数值
     */
    private int igBoosterWordStrength[];
    /**
     * 加强词数量
     */
    private int igBoosterWordsCount;

    /**
     * BoosterWordsList构造函数
     */
    public BoosterWordsList()
    {
        igBoosterWordsCount = 0;
    }

    /**
     * 初始化BoosterWordsList
     * @param sFilename 存储加强单词的文件名
     * @param options 参数设置选项
     * @param iExtraBlankArrayEntriesToInclude 加强词数组长度 = 文件中加强词数量 + iExtraBlankArrayEntriesToInclude
     * @return true表示初始化成功，false表示初始化出错失败
     */
    public boolean initialise(String sFilename, ClassificationOptions options, int iExtraBlankArrayEntriesToInclude)
    {
        int iLinesInFile = 0;
        int iWordStrength = 0;
        if(sFilename == "")
        {
            System.out.println("No booster words file specified");
            return false;
        }
        File f = new File(sFilename);
        if(!f.exists())
        {
            System.out.println((new StringBuilder("Could not find booster words file: ")).append(sFilename).toString());
            return false;
        }
        iLinesInFile = FileOps.i_CountLinesInTextFile(sFilename);
        if(iLinesInFile < 1)
        {
            System.out.println("No booster words specified");
            return false;
        }
        sgBoosterWords = new String[iLinesInFile + 1 + iExtraBlankArrayEntriesToInclude];
        igBoosterWordStrength = new int[iLinesInFile + 1 + iExtraBlankArrayEntriesToInclude];
        igBoosterWordsCount = 0;
        try
        {
            BufferedReader rReader;
            if(options.bgForceUTF8)
                rReader = new BufferedReader(new InputStreamReader(new FileInputStream(sFilename), "UTF8"));
            else
                rReader = new BufferedReader(new FileReader(sFilename));
            String sLine;
            while((sLine = rReader.readLine()) != null) 
                if(sLine != "")
                {
                    int iFirstTabLocation = sLine.indexOf("\t");
                    if(iFirstTabLocation >= 0)
                    {
                        int iSecondTabLocation = sLine.indexOf("\t", iFirstTabLocation + 1);
                        try
                        {
                            if(iSecondTabLocation > 0)
                                iWordStrength = Integer.parseInt(sLine.substring(iFirstTabLocation + 1, iSecondTabLocation));
                            else
                                iWordStrength = Integer.parseInt(sLine.substring(iFirstTabLocation + 1).trim());
                        }
                        catch(NumberFormatException e)
                        {
                            System.out.println("Failed to identify integer weight for booster word! Assuming it is zero");
                            System.out.println((new StringBuilder("Line: ")).append(sLine).toString());
                            iWordStrength = 0;
                        }
                        sLine = sLine.substring(0, iFirstTabLocation);
                        if(sLine.indexOf(" ") >= 0)
                            sLine = sLine.trim();
                        if(sLine != "")
                        {
                            igBoosterWordsCount++;
                            sgBoosterWords[igBoosterWordsCount] = sLine;
                            igBoosterWordStrength[igBoosterWordsCount] = iWordStrength;
                        }
                    }
                }
            Sort.quickSortStringsWithInt(sgBoosterWords, igBoosterWordStrength, 1, igBoosterWordsCount);
            rReader.close();
        }
        catch(FileNotFoundException e)
        {
            System.out.println((new StringBuilder("Could not find booster words file: ")).append(sFilename).toString());
            e.printStackTrace();
            return false;
        }
        catch(IOException e)
        {
            System.out.println((new StringBuilder("Found booster words file but could not read from it: ")).append(sFilename).toString());
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 添加额外加强单词
     * @param sText 加强词
     * @param iWordStrength 加强词强度数值
     * @param bSortBoosterListAfterAddingTerm 添加新单词后，BoosterList是否进行重新排序
     * @return true表示添加成功，false表示出现异常操作失败
     */
    public boolean addExtraTerm(String sText, int iWordStrength, boolean bSortBoosterListAfterAddingTerm)
    {
        try
        {
            igBoosterWordsCount++;
            sgBoosterWords[igBoosterWordsCount] = sText;
            igBoosterWordStrength[igBoosterWordsCount] = iWordStrength;
            if(bSortBoosterListAfterAddingTerm)
                Sort.quickSortStringsWithInt(sgBoosterWords, igBoosterWordStrength, 1, igBoosterWordsCount);
        }
        catch(Exception e)
        {
            System.out.println((new StringBuilder("Could not add extra booster word: ")).append(sText).toString());
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 加强词字符串数组按字典序排序，加强词强度数组中的项进行同步位置改变
     */
    public void sortBoosterWordList()
    {
        Sort.quickSortStringsWithInt(sgBoosterWords, igBoosterWordStrength, 1, igBoosterWordsCount);
    }

    /**
     * 获取加强词强度
     * @param sWord 单词
     * @return 单词强度数值，返回0表示sWord不是加强词
     */
    public int getBoosterStrength(String sWord)
    {
        int iWordID = Sort.i_FindStringPositionInSortedArray(sWord.toLowerCase(), sgBoosterWords, 1, igBoosterWordsCount);
        if(iWordID >= 0)
            return igBoosterWordStrength[iWordID];
        else
            return 0;
    }
}
