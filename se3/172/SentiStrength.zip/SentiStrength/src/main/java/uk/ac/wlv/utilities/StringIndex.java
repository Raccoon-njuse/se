package uk.ac.wlv.utilities;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

/**
 * 字符串索引(StringIndex)
 * <p>提供类似单词词典的作用，管理文本中的大量单词、单词在字典序下索引、单词计数、单词注解等信息
 * @author Mike Thelwall
 * @version 1.0.0
 */
public class StringIndex {
   /**
    * 文本单词数最大值
    */
   private int igTextMax = 10000000;
   /**
    * 文本字符串数组，该数组中的每项是一个单词
    */
   public String[] sgText;
   /**
    * 注解字符串数组，该数组中的每项对应一个单词
    */
   public String[] sgTextComment;
   /**
    * 指针数组，指向每个字符串的字典序的前一项字符串在数组sgText中的位置
    */
   private int[] igTextLessPtr;
   /**
    * 指针数组，指向每个字符串的字典序的后一项字符串在数组sgText中的位置
    */
   private int[] igTextMorePtr;
   /**
    * 文本中每个单词的计数
    */
   private int[] igTextCount;
   /**
    * 文本最后一个单词在数组中的索引
    */
   private int igTextLast = -1;
   /**
    * 是否包含计数
    */
   private boolean bgIncludeCounts = false;

   /**
    * 初始化StringIndex对象
    * @param iVocabMaxIfOverrideDefault 设置词汇数量最大值，如果小于等于0则对应属性使用默认值
    * @param bIncludeCounts 设置是否包含计数
    * @param bIncludeComments 设置是否包含注解
    */
   public void initialise(int iVocabMaxIfOverrideDefault, boolean bIncludeCounts, boolean bIncludeComments) {
      this.bgIncludeCounts = bIncludeCounts;
      if (iVocabMaxIfOverrideDefault > 0) {
         this.igTextMax = iVocabMaxIfOverrideDefault;
      }

      // 数组长度为igTextMax
      this.sgText = new String[this.igTextMax];
      this.igTextLessPtr = new int[this.igTextMax];
      this.igTextMorePtr = new int[this.igTextMax];
      this.igTextLast = -1;
      int i;
      if (this.bgIncludeCounts) {
         this.igTextCount = new int[this.igTextMax];
         for(i = 0; i < this.igTextMax; ++i) {
            this.igTextCount[i] = 0;
         }
      }

      if (bIncludeComments) {
         this.sgTextComment = new String[this.igTextMax];
         // TODO 好像有bug
         for(i = 0; i < this.igTextMax; ++i) {
            this.igTextCount[i] = 0;
         }
      }
   }

   /**
    * 载入词汇指针计数文件的内容至{@code StringIndex}对象
    * <p>词汇指针计数文件含有多行，每行的格式是 "word lessPtr morePtr count"，将这四项信息加入StringIndex对象对应的成员变量数组中
    * @param sVocabTermPtrsCountFileName 词汇指针计数文件的文件名字符串
    * @return 操作失败（文件不存在或IO异常）则返回false，操作成功则返回true
    */
   public boolean load(String sVocabTermPtrsCountFileName) {
      File f = new File(sVocabTermPtrsCountFileName);
      if (!f.exists()) {
         System.out.println("Could not find the vocab file: " + sVocabTermPtrsCountFileName);
         return false;
      } else {
         try {
            BufferedReader rReader = new BufferedReader(new InputStreamReader(new FileInputStream(sVocabTermPtrsCountFileName), "UTF8"));
            String sLine = rReader.readLine();
            String[] sData = sLine.split("\t");
            this.igTextLast = -1;

            while(rReader.ready()) {
               sLine = rReader.readLine();
               if (sLine.length() > 0) {
                  sData = sLine.split("\t");
                  if (sData.length > 2) {
                     if (this.igTextLast == this.igTextMax - 1) {
                        this.increaseArraySizes(this.igTextMax * 2);
                     }
                     // sData内容：单词、lessPtr、morePtr、count
                     this.sgText[++this.igTextLast] = sData[0];
                     this.igTextLessPtr[this.igTextLast] = Integer.parseInt(sData[1]);
                     this.igTextMorePtr[this.igTextLast] = Integer.parseInt(sData[2]);
                     this.igTextCount[this.igTextLast] = Integer.parseInt(sData[3]);
                  }
               }
            }

            rReader.close();
            return true;
         } catch (IOException var7) {
            System.out.println("Could not open file for reading or read from file: " + sVocabTermPtrsCountFileName);
            var7.printStackTrace();
            return false;
         }
      }
   }

   /**
    * 获取文本数组中最后一个单词的序号（索引）
    * @return 文本最后一个单词的索引的值
    */
   public int getLastWordID() {
      return this.igTextLast;
   }

   /**
    * 将该{@code StringIndex}对象的信息保存在文件sVocabTermPtrsCountFileName中<br>
    * 文件中每个单词的信息占一行，每个单词信息的格式为 "word lessPtr morePtr count"
    * @param sVocabTermPtrsCountFileName 文件名
    * @return 操作成功则返回true，操作失败则返回false
    */
   public boolean save(String sVocabTermPtrsCountFileName) {
      if (!FileOps.backupFileAndDeleteOriginal(sVocabTermPtrsCountFileName, 10)) {
         System.out.println("Could not backup vocab! Perhaps no index exists yet.");
      }

      try {
         BufferedWriter wWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(sVocabTermPtrsCountFileName), "UTF8"));
         wWriter.write("Word\tLessPtr\tMorePtr\tAllTopics");

         for(int i = 0; i <= this.igTextLast; ++i) {
            wWriter.write(this.sgText[i] + "\t" + this.igTextLessPtr[i] + "\t" + this.igTextMorePtr[i] + "\t" + this.igTextCount[i] + "\n");
         }

         wWriter.close();
         return true;
      } catch (IOException var4) {
         System.out.println("Could not open file for writing or write to file: " + sVocabTermPtrsCountFileName);
         var4.printStackTrace();
         return false;
      }
   }

   /**
    * 向文本数组中添加新字符串
    * @param sText 字符串
    * @param bRecordCount 是否计数
    * @return 新加入的字符串在数组中的位置
    */
   public int addString(String sText, boolean bRecordCount) {
      boolean iPos = true;
      // 如果满了，数组扩容
      if (this.igTextLast == this.igTextMax - 1) {
         this.increaseArraySizes(this.igTextMax * 2);
      }

      int iPos1;
      if (bRecordCount) {
         iPos1 = Trie.i_GetTriePositionForStringAndAddCount(sText, this.sgText, this.igTextCount, this.igTextLessPtr, this.igTextMorePtr, 0, this.igTextLast, false, 1);
      } else {
         iPos1 = Trie.i_GetTriePositionForString(sText, this.sgText, this.igTextLessPtr, this.igTextMorePtr, 0, this.igTextLast, false);
      }

      if (iPos1 > this.igTextLast) {
         this.igTextLast = iPos1;
      }

      return iPos1;
   }

   /**
    * 查找字符串在数组中的位置索引
    * @param sText 目标字符串
    * @return 字符串在数组中的位置索引值，查找不到则为-1
    */
   public int findString(String sText) {
      return Trie.i_GetTriePositionForString(sText, this.sgText, this.igTextLessPtr, this.igTextMorePtr, 0, this.igTextLast, true);
   }

   /**
    * 指定单词的计数加1
    * @param iStringPos 单词的位置，在数组中的索引值
    */
   public void add1ToCount(int iStringPos) {
      int var10002 = this.igTextCount[iStringPos]++;
   }

   /**
    * 数组扩容
    * <p>将成员变量sgText，igTextLessPtr，igTextMorePtr数组的长度扩展到iNewArraySize<br>
    *     如果包含计数，igTextCount数组的长度也扩展到iNewArraySize
    * @param iNewArraySize 新数组容量
    */
   private void increaseArraySizes(int iNewArraySize) {
      if (iNewArraySize > this.igTextMax) {
         String[] sgTextTemp = new String[iNewArraySize];
         int[] iTextLessPtrTemp = new int[iNewArraySize];
         int[] iTextMorePtrTemp = new int[iNewArraySize];
         System.arraycopy(this.sgText, 0, sgTextTemp, 0, this.igTextMax);
         System.arraycopy(this.igTextLessPtr, 0, iTextLessPtrTemp, 0, this.igTextMax);
         System.arraycopy(this.igTextMorePtr, 0, iTextMorePtrTemp, 0, this.igTextMax);
         if (this.bgIncludeCounts) {
            int[] iVocabCountTemp = new int[iNewArraySize];
            System.arraycopy(this.igTextCount, 0, iVocabCountTemp, 0, this.igTextMax);

            for(int i = this.igTextMax; i < iNewArraySize; ++i) {
               this.igTextCount[i] = 0;
            }
            this.igTextCount = iVocabCountTemp;
         }
         this.igTextMax = iNewArraySize;
         this.igTextLessPtr = iTextLessPtrTemp;
         this.igTextMorePtr = iTextMorePtrTemp;
      }
   }

   /**
    * 字符串数组扩容
    * <p>将字符串数组sArray的长度扩展到iNewArraySize
    * @param sArray 需要进行扩容的字符串数组
    * @param iCurrentArraySize 字符串数组原长度
    * @param iNewArraySize 字符串数组新长度
    * @return 扩容后的字符串数组
    */
   private static String[] increaseArraySize(String[] sArray, int iCurrentArraySize, int iNewArraySize) {
      if (iNewArraySize <= iCurrentArraySize) {
         return sArray;
      } else {
         String[] sArrayTemp = new String[iNewArraySize];
         System.arraycopy(sArray, 0, sArrayTemp, 0, iCurrentArraySize);
         return sArrayTemp;
      }
   }

   /**
    * 整数数组扩容
    * <p>将整数数组sArray的长度扩展到iNewArraySize
    * @param iArray 需要进行扩容的整数数组
    * @param iCurrentArraySize 整数数组原长度
    * @param iNewArraySize 整数数组新长度
    * @return 扩容后的整数数组
    */
   private static int[] increaseArraySize(int[] iArray, int iCurrentArraySize, int iNewArraySize) {
      if (iNewArraySize <= iCurrentArraySize) {
         return iArray;
      } else {
         int[] iArrayTemp = new int[iNewArraySize];
         System.arraycopy(iArray, 0, iArrayTemp, 0, iCurrentArraySize);
         return iArrayTemp;
      }
   }

   /**
    * 获取指定位置的单词
    * @param iStringPos 单词的位置，在数组中的索引值
    * @return 该位置的单词字符串
    */
   public String getString(int iStringPos) {
      return this.sgText[iStringPos];
   }

   /**
    * 获取指定位置的单词
    * @param iStringPos 单词的位置，在数组中的索引值
    * @return 该位置的单词字符串
    */
   public String getComment(int iStringPos) {
      return this.sgTextComment[iStringPos] == null ? "" : this.sgTextComment[iStringPos];
   }

   /**
    * 添加指定位置的评论
    * @param iStringPos 在数组中的索引值
    * @param sComment 要添加的评论
    */
   public void addComment(int iStringPos, String sComment) {
      this.sgTextComment[iStringPos] = sComment;
   }

   /**
    * 获取指定位置的单词的计数值
    * @param iStringPos 单词的位置，在数组中的索引值
    * @return 该位置的计数
    */
   public int getCount(int iStringPos) {
      return this.igTextCount[iStringPos];
   }

   /**
    * 将指定位置的字符串计数设为0
    * @param iStringPos 单词的位置，在数组中的索引值
    */
   public void setCountToZero(int iStringPos) {
      this.igTextCount[iStringPos] = 0;
   }

   /**
    * 将计数数组每项设为0
    */
   public void setAllCountsToZero() {
      for(int i = 0; i <= this.igTextLast; ++i) {
         this.igTextCount[i] = 0;
      }

   }
}
